<?php
$activebar = "tasks";
?>

@include('worker.header')
    <div class="iq-top-navbar py-2 rtl-iq-top-navbar ">
        <div class="iq-navbar-custom">
            <nav class="navbar navbar-expand-lg navbar-light p-0 toSetNavBarAll w-100">
                <div class="iq-navbar-logo d-flex align-items-center justify-content-between">
                    <i class="ri-menu-line wrapper-menu"></i>
                    <!-- Mobile Logo -->
                </div>
                <div class="iq-search-bar device-search">
                    <h4 class="main_content_title">Task Management</h4>
                </div>
                @include('worker.tooltip')
                <!-- <div class="d-xxl-none d-xl-none d-lg-none d-md-block d-sm-block d-block">
                    <ul class="align-items-center d-flex gap-4 list-unstyled text-decoration-none m-0">
                        <li>
                            <button class="nav-AddNew-Button btn btn-primary" type="button" data-bs-toggle="modal" data-bs-target="#exampleModal">Create Task</button>
                        </li>
                    </ul>
                </div> -->
            </nav>
        </div>
    </div>



    <div class="content-page rtl-page">
        <div class="container-fluid mt-4">
            <div class="row">
                <div class="col-12">
                    <div class="row mt-4">
                        <div class="col-12 ">
                            <div class="bg-white p-3 index-TablePage">
                                <div class="mb-3">
                                    <div class="align-items-center d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column justify-content-between toSetFilterIcon">
                                        <h4 class="file-Heading">
                                            All Tasks
                                        </h4>
                                        <div class="TogiveFullWidth d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column gap-2 mt-xxl-0 mt-xl-0 mt-lg-0 mt-md-0 mt-sm-3 mt-3">

                                           <!-- <button  class="FilterButtonSetting btn btn-secondary d-flex gap-2 align-items-center" >
                                                Sort by <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M3.375 13.4995H7.3125M10.125 11.812L12.9375 14.6245M12.9375 14.6245L15.7499 11.8125M12.9375 14.6245L12.9375 7.87451M3.375 8.99951H8.43743M3.375 4.49951H12.9374"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                </svg>
                                            </button> -->

                                        </div>
                                    </div>
                                </div>
                                <div class="table-responsive">
                                    <table id="" class="dataTable table-responsive stripe w-100 ">
                                        <thead>
                                        <tr>
                                           <th>  S.No </th>
                                            <th>Date Created</th>
                                            <th class="text-start">Task Id</th>
                                            <th>Task Tittle</th>
                                            <th>Assigned To</th>
                                            <th>Start on</th>
                                            <th>End on</th>
                                            <th>Status</th>
                                            <th></th>
                                        </tr>
                                        </thead>
                                        <tbody id="appendAllTaks">
                                            @foreach ($task_data as $k=>$item)
                                                <tr>
                                                    <td>
                                                        <p class="table-MainHeading" > {{ $k+1 }} </p>
                                                    </td>
                                                    <td>
                                                        @php
                                                        $timestamp = (strtotime($item->created_at));
                                                        $date = date('j.n.Y', $timestamp);
                                                        $time = date('H:i:s', $timestamp);
                                                        @endphp
                                                        <p class="p-0 m-0 table-MainHeading" id="creted_date">
                                                            {{$date}}
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading" id="created_time">
                                                            {{$time}}
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading" id="taskid">
                                                            {{isset($item->task_id) ? $item->task_id : '-'}}
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading" id="task_title">
                                                            {{isset($item->task_name) ? $item->task_name : '-'}}
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            @if(!empty($item->users))
                                                        @foreach ($item->users as $worker)
                                                        <span class="badge badge-inactive">{{isset($worker->f_name) ? $worker->f_name : ''}}</span>
                                                        @endforeach
                                                        @endif

                                                        </p>
                                                    </td>
                                                    @php
                                                    $timestamp = (strtotime($item->start_datetime));
                                                    $date = date('j.n.Y', $timestamp);
                                                    $time = date('H:i:s', $timestamp);
                                                    @endphp
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading" id="strt_date">
                                                            {{$date}}
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading" id="strt_time">
                                                            {{$time}}
                                                        </p>
                                                    </td>
                                                    @php
                                                    $timestamp = (strtotime($item->end_datetime));
                                                    $date = date('j.n.Y', $timestamp);
                                                    $time = date('H:i:s', $timestamp);
                                                    @endphp
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading" id="end_date">
                                                            {{$date}}
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading" id="end_time">
                                                            {{$time}}
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <select name="status" id="status" disabled class="js-select2 tosetitas" onchange="checkTertiary(event)">
                                                                <option value="Select Option" disabled>Select Option</option>
                                                                <option value="Approved" {{ isset($item->status) && $item->status == 'Approved' ? 'selected' : '' }}>Approved</option>
                                                                  <option value="Completed" {{ isset($item->status) && $item->status == 'Completed' ? 'selected' : '' }}>Completed</option>
                                                                <option value="Submitted" {{ isset($item->status) && $item->status == 'Submitted' ? 'selected' : '' }}>Submitted</option>
                                                                <option value="Active" {{ isset($item->status) && $item->status == 'Active' ? 'selected' : '' }}>Active</option>
                                                                <option value="Expired" {{ isset($item->status) && $item->status == 'Expired' ? 'selected' : '' }}>Expired</option>
                                                        </select>
                                                    </td>
                                                    <td>
                                                        <div class="tableButtonSetting">
                                                            <div class="btn-group dropstart">
                                                                <a href="#" class="dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false" >
                                                                    <img src="{{asset('public/assets/icons/DotsThreeOutline.svg')}}" alt="">
                                                                </a>
                                                                <ul class="dropdown-menu tosetWidh-Dropdown">
                                                                    <li><a class="dropdown-item  togivepaddingLeft" href="{{route('worker.taskView' , ['id' => $item->id])}}" onclick="read_task_msg('{{ $item->id }}')">View</a></li>

                                                                </ul>
                                                            </div>
                                                        </div>
                                                        @if(isset($item->chats) && count($item->chats) > 0)
                                                        <a href="{{ route('worker.taskView', ['id' => $item->id]) }}" onclick="read_task_msg('{{ $item->id }}')" class="text-danger">
                                                            {{ count($item->chats) }}
                                                        </a>
                                                        @endif

                                                    </td>
                                                </tr>
                                                @endforeach


                                        </tbody>

                                    </table>

                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>


    <script>
        function read_task_msg(id){
            console.log(id);
            $.ajax({
                url : "{{route('worker.read_msg')}}",
                method : "POST",
                data : {
                    read_id : id,
                    _token : "{{csrf_token()}}",
                },
                success : function(res){
                    console.log(res)
                    Show_task_msg()


                }
            })
        }


        setInterval(() => {
        get_tasks();
    }, 2000);

function get_tasks(){
    $.ajax({
        url  : "{{route('worker.get_tasks')}}",
        type : "POST",
        data:{
            _token:'{{ csrf_token() }}',
        },
        success : function(res){
            console.log(res);
            if(res.data) {
                $('#appendAllTaks').html(res.data);
                setTimeout(() => {
                    $('select.js-select2').each(function() {
                        $(this).select2({
                            selectOnClose: true
                        });
                    });
                    applyColor();
                }, 2000);
            }

        }
    })
}
get_tasks();
    </script>

@include('worker.footer')
