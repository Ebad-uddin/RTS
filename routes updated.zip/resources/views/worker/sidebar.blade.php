
<style>

    @media only screen and (max-width: 991px)  {
        .mobile_nav {
            display: block;
        }
    }


    @media only screen and (min-width: 990px)  {
        .mobile_nav {
            display: none;
        }

    }
    #show_counter{
        position: absolute;
    top: 9px;
    right: 40px;
    font-size: 15px !important;
    }
</style>
<div class="iq-sidebar  rtl-iq-sidebar sidebar-default ">
    <div class="iq-sidebar-logo d-flex align-items-center justify-content-between justify-content-sm-between  justify-content-md-between justify-content-lg-center justify-content-xl-center">
        <a href="{{route('worker.index')}}" class="header-logo">
            <div class="NavBar-Logo">
                <img src="{{asset('public/assets/images/main_logo.png')}}" class="w-100" alt="">
            </div>
        </a>
        <div class="iq-menu-bt-sidebar d-block d-sm-block d-md-block d-lg-none d-xl-none">
            <i class="fi fi-rr-angle-left wrapper-menu wrapper-menu-lg"></i>
        </div>
    </div>
    <div class="Main-Nav-Height d-flex flex-column justify-content-between">
        <nav class="iq-sidebar-menu">
            <div class="d-flex flex-column gap-2">
                <ul id="iq-sidebar-toggle" class="iq-menu mt-3">
                    <li class="">
                        <a href="{{route('worker.index')}}"
                            class="menu-link d-flex align-items-center gap-2 <?= (isset($activebar) && $activebar == 'index') ? 'activenav' : '' ?>">
                            <small><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"> <path d="M1.5 20.25H22.5M20.25 20.25V10.8317C20.25 10.7272 20.2282 10.6239 20.1859 10.5283C20.1436 10.4328 20.0818 10.3471 20.0045 10.2768L12.504 3.45787C12.3659 3.33236 12.186 3.26281 11.9995 3.26282C11.8129 3.26282 11.633 3.33238 11.4949 3.45791L3.99545 10.2768C3.91814 10.3471 3.85637 10.4328 3.8141 10.5283C3.77183 10.6239 3.75 10.7272 3.75 10.8317V20.25M14.2495 20.2492V14.9992C14.2495 14.8003 14.1704 14.6095 14.0298 14.4688C13.8891 14.3282 13.6984 14.2492 13.4995 14.2492H10.4995C10.3005 14.2492 10.1098 14.3282 9.96912 14.4688C9.82847 14.6095 9.74945 14.8003 9.74945 14.9992V20.2492"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/> </svg></small><span>Dashboard</span>
                        </a>
                    </li>
                    <li class="">
                        <a href="{{route('worker.taskmanagement')}}"
                           class="menu-link d-flex align-items-center gap-2 <?= (isset($activebar) && $activebar == 'tasks') ? 'activenav' : '' ?>">
                            <small><svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"> <path d="M16.875 14.25V19.5M19.5 16.875H14.25M10.5 16.875C10.5 18.739 8.98896 20.25 7.125 20.25C5.26104 20.25 3.75 18.739 3.75 16.875C3.75 15.011 5.26104 13.5 7.125 13.5C8.98896 13.5 10.5 15.011 10.5 16.875ZM20.25 7.125C20.25 8.98896 18.739 10.5 16.875 10.5C15.011 10.5 13.5 8.98896 13.5 7.125C13.5 5.26104 15.011 3.75 16.875 3.75C18.739 3.75 20.25 5.26104 20.25 7.125ZM10.5 7.125C10.5 8.98896 8.98896 10.5 7.125 10.5C5.26104 10.5 3.75 8.98896 3.75 7.125C3.75 5.26104 5.26104 3.75 7.125 3.75C8.98896 3.75 10.5 5.26104 10.5 7.125Z"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/> </svg></small><span>Tasks Management</span>
                            <small id="show_task_counter"></small>

                        </a>
                    </li>
                    <li class="">
                        <a href="{{route('worker.chat')}}"
                           class="menu-link d-flex align-items-center gap-2 <?= (isset($activebar) && $activebar == 'chat') ? 'activenav' : '' ?>">
                            <small><svg width="19" height="19" viewBox="0 0 19 19" fill="none" xmlns="http://www.w3.org/2000/svg"> <path d="M9.37502 18.2493H1.46875C1.27813 18.2493 1.09531 18.1735 0.960517 18.0388C0.825725 17.904 0.75 17.7211 0.75 17.5305V9.62425C0.75 8.4916 0.973092 7.37004 1.40654 6.32361C1.83998 5.27718 2.4753 4.32637 3.2762 3.52547C4.0771 2.72456 5.02791 2.08925 6.07435 1.6558C7.12078 1.22236 8.24233 0.999267 9.37498 0.999268H9.375C10.5077 0.999268 11.6292 1.22236 12.6756 1.65581C13.7221 2.08925 14.6729 2.72457 15.4738 3.52547C16.2747 4.32638 16.91 5.27719 17.3435 6.32362C17.7769 7.37006 18 8.49162 18 9.62427V9.62428C18 11.9118 17.0913 14.1056 15.4738 15.7231C13.8563 17.3406 11.6625 18.2493 9.37502 18.2493Z"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/> <path d="M13.875 11.125C14.4963 11.125 15 10.6213 15 10C15 9.37868 14.4963 8.875 13.875 8.875C13.2537 8.875 12.75 9.37868 12.75 10C12.75 10.6213 13.2537 11.125 13.875 11.125Z" fill="#88909F"/> <path d="M9.375 11.125C9.99632 11.125 10.5 10.6213 10.5 10C10.5 9.37868 9.99632 8.875 9.375 8.875C8.75368 8.875 8.25 9.37868 8.25 10C8.25 10.6213 8.75368 11.125 9.375 11.125Z" fill="#88909F"/> <path d="M4.875 11.125C5.49632 11.125 6 10.6213 6 10C6 9.37868 5.49632 8.875 4.875 8.875C4.25368 8.875 3.75 9.37868 3.75 10C3.75 10.6213 4.25368 11.125 4.875 11.125Z" fill="#88909F"/> </svg></small><span>Chat</span>
                            <small id="show_counter"></small>
                        </a>
                    </li>
                    <li class="">
                        <a href="{{route('worker.reports')}}"
                        class="menu-link d-flex align-items-center gap-2 <?= (isset($activebar) && $activebar == 'reports') ? 'activenav' : '' ?>">

                            <small>
                                <!-- <svg class="userSvgNav" width="25" height="24" viewBox="0 0 25 24" fill="none" xmlns="http://www.w3.org/2000/svg"> <path d="M14.8666 4.70959C14.468 4.82193 14.2358 5.23619 14.3481 5.63488C14.4605 6.03357 14.8747 6.26571 15.2734 6.15338L14.8666 4.70959ZM16.3928 14.9999L16.3923 14.2499C15.9781 14.2502 15.6426 14.5861 15.6428 15.0002C15.643 15.4143 15.9788 15.7499 16.3929 15.7499L16.3928 14.9999ZM22.529 18.9363C22.767 19.2753 23.2348 19.3572 23.5738 19.1192C23.9128 18.8811 23.9947 18.4134 23.7567 18.0744L22.529 18.9363ZM1.3862 18.0745C1.14798 18.4133 1.22956 18.8812 1.56841 19.1194C1.90727 19.3576 2.37508 19.276 2.61331 18.9372L1.3862 18.0745ZM14.8867 18.9367C15.1249 19.2755 15.5927 19.3571 15.9316 19.1188C16.2704 18.8806 16.3519 18.4128 16.1137 18.0739L14.8867 18.9367ZM12.8751 10.1249C12.8751 12.4031 11.0283 14.2499 8.75015 14.2499V15.7499C11.8568 15.7499 14.3751 13.2315 14.3751 10.1249H12.8751ZM8.75015 14.2499C6.47197 14.2499 4.62515 12.4031 4.62515 10.1249H3.12515C3.12515 13.2315 5.64355 15.7499 8.75015 15.7499V14.2499ZM4.62515 10.1249C4.62515 7.84672 6.47197 5.9999 8.75015 5.9999V4.4999C5.64355 4.4999 3.12515 7.01829 3.12515 10.1249H4.62515ZM8.75015 5.9999C11.0283 5.9999 12.8751 7.84672 12.8751 10.1249H14.3751C14.3751 7.01829 11.8568 4.4999 8.75015 4.4999V5.9999ZM15.2734 6.15338C15.8408 5.99353 16.4359 5.95711 17.0185 6.04659L17.2462 4.56397C16.4517 4.44196 15.6403 4.49162 14.8666 4.70959L15.2734 6.15338ZM17.0185 6.04659C17.6011 6.13606 18.1578 6.34936 18.6511 6.6721L19.4723 5.41691C18.7997 4.97682 18.0406 4.68598 17.2462 4.56397L17.0185 6.04659ZM18.6511 6.6721C19.1443 6.99484 19.5627 7.41954 19.878 7.91759L21.1454 7.11524C20.7154 6.43611 20.145 5.857 19.4723 5.41691L18.6511 6.6721ZM19.878 7.91759C20.1933 8.41564 20.3982 8.97547 20.4789 9.55938L21.9648 9.35396C21.8547 8.55775 21.5753 7.79437 21.1454 7.11524L19.878 7.91759ZM20.4789 9.55938C20.5597 10.1433 20.5143 10.7377 20.346 11.3026L21.7835 11.731C22.0131 10.9607 22.0749 10.1502 21.9648 9.35396L20.4789 9.55938ZM20.346 11.3026C20.1776 11.8675 19.8902 12.3898 19.503 12.8343L20.634 13.8196C21.1619 13.2135 21.5539 12.5013 21.7835 11.731L20.346 11.3026ZM19.503 12.8343C19.1158 13.2787 18.6378 13.6351 18.1013 13.8793L18.7227 15.2445C19.4543 14.9115 20.106 14.4256 20.634 13.8196L19.503 12.8343ZM18.1013 13.8793C17.5648 14.1234 16.9822 14.2498 16.3927 14.2499L16.3929 15.7499C17.1967 15.7498 17.9911 15.5775 18.7227 15.2445L18.1013 13.8793ZM16.3934 15.7499C17.5968 15.749 18.7828 16.0382 19.8508 16.5928L20.5421 15.2616C19.2602 14.5959 17.8368 14.2488 16.3923 14.2499L16.3934 15.7499ZM19.8508 16.5928C20.9189 17.1475 21.8375 17.9513 22.529 18.9363L23.7567 18.0744C22.9267 16.8922 21.8241 15.9273 20.5421 15.2616L19.8508 16.5928ZM2.61331 18.9372C3.30548 17.9526 4.22438 17.149 5.29244 16.5943L4.60104 15.2631C3.31943 15.9288 2.21678 16.8931 1.3862 18.0745L2.61331 18.9372ZM5.29244 16.5943C6.36046 16.0396 7.54662 15.7499 8.75018 15.7499L8.75012 14.2499C7.30597 14.25 5.88269 14.5975 4.60104 15.2631L5.29244 16.5943ZM8.75018 15.7499C9.95367 15.7498 11.1392 16.0394 12.2074 16.594L12.8986 15.2628C11.617 14.5973 10.1943 14.2498 8.75012 14.2499L8.75018 15.7499ZM12.2074 16.594C13.2754 17.1487 14.1944 17.9522 14.8867 18.9367L16.1137 18.0739C15.283 16.8926 14.1803 15.9284 12.8986 15.2628L12.2074 16.594Z" fill="#8897AE"/> </svg> -->
                                <!-- <svg fill="#8897AE" width="25" height="24" viewBox="0 0 32 32" id="icon" xmlns="http://www.w3.org/2000/svg" ><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"><defs><style>.cls-1{fill:none;}</style></defs><title>report</title><rect x="15" y="20" width="2" height="4"></rect><rect x="20" y="18" width="2" height="6"></rect><rect x="10" y="14" width="2" height="10"></rect><path d="M25,5H22V4a2,2,0,0,0-2-2H12a2,2,0,0,0-2,2V5H7A2,2,0,0,0,5,7V28a2,2,0,0,0,2,2H25a2,2,0,0,0,2-2V7A2,2,0,0,0,25,5ZM12,4h8V8H12ZM25,28H7V7h3v3H22V7h3Z"></path><rect id="_Transparent_Rectangle_" data-name="<Transparent Rectangle>" class="cls-1" width="32" height="32"></rect></g></svg> -->
                                <svg fill="#8897AE" width="25" height="24" viewBox="0 0 32 32" id="icon" xmlns="http://www.w3.org/2000/svg" stroke="#8897AE" stroke-width="0.00032"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"><defs><style>.cls-1{fill:none;}</style></defs><title>report</title><rect x="15" y="20" width="2" height="4"></rect><rect x="20" y="18" width="2" height="6"></rect><rect x="10" y="14" width="2" height="10"></rect><path d="M25,5H22V4a2,2,0,0,0-2-2H12a2,2,0,0,0-2,2V5H7A2,2,0,0,0,5,7V28a2,2,0,0,0,2,2H25a2,2,0,0,0,2-2V7A2,2,0,0,0,25,5ZM12,4h8V8H12ZM25,28H7V7h3v3H22V7h3Z"></path><rect id="_Transparent_Rectangle_" data-name="<Transparent Rectangle>" class="cls-1" width="32" height="32"></rect></g></svg>
                            </small><span>Reports</span>
                        </a>
                    </li>


                    <!-- <li class="">
                        <a href="workGroups.php"
                        class="menu-link d-flex align-items-center gap-2 <?= (isset($activebar) && $activebar == 'groups') ? 'activenav' : '' ?>">

                            <small><svg width="22" height="20" viewBox="0 0 22 20" fill="none" xmlns="http://www.w3.org/2000/svg"> <path d="M16.625 18.875C18.6961 18.875 20.375 17.1961 20.375 15.125C20.375 13.0539 18.6961 11.375 16.625 11.375C14.5539 11.375 12.875 13.0539 12.875 15.125C12.875 17.1961 14.5539 18.875 16.625 18.875Z"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/> <path d="M5.375 18.875C7.44607 18.875 9.125 17.1961 9.125 15.125C9.125 13.0539 7.44607 11.375 5.375 11.375C3.30393 11.375 1.625 13.0539 1.625 15.125C1.625 17.1961 3.30393 18.875 5.375 18.875Z"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/> <path d="M11 9.125C13.0711 9.125 14.75 7.44607 14.75 5.375C14.75 3.30393 13.0711 1.625 11 1.625C8.92893 1.625 7.25 3.30393 7.25 5.375C7.25 7.44607 8.92893 9.125 11 9.125Z"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/> </svg></small><span>Work Groups</span>
                        </a>
                    </li> -->
                    <li class="">
                        <a href="{{route('worker.settings')}}"
                        class="menu-link d-flex align-items-center gap-2 <?= (isset($activebar) && $activebar == 'settings') ? 'activenav' : '' ?>">

                            <small><svg width="25" height="24" viewBox="0 0 25 24" fill="none" xmlns="http://www.w3.org/2000/svg"> <path d="M5.4031 8.58739C5.57185 8.23114 5.76872 7.89364 5.99372 7.56551L5.95622 5.12801C5.95622 4.90301 6.04997 4.68739 6.2281 4.53739C7.09997 3.80614 8.09372 3.21551 9.1906 2.82176C9.40622 2.74676 9.6406 2.76551 9.8281 2.88739L11.9187 4.14364C12.3125 4.11551 12.7062 4.11551 13.1 4.14364L15.1906 2.88739C15.3875 2.77489 15.6218 2.74676 15.8375 2.82176C16.9062 3.20614 17.9093 3.77801 18.8 4.52801C18.9687 4.66864 19.0718 4.89364 19.0625 5.11864L19.025 7.55614C19.25 7.88426 19.4468 8.22176 19.6156 8.57801L21.7437 9.75926C21.9406 9.87176 22.0812 10.0593 22.1187 10.2843C22.3156 11.3999 22.325 12.5624 22.1187 13.6968C22.0812 13.9218 21.9406 14.1093 21.7437 14.2218L19.6156 15.403C19.4468 15.7593 19.25 16.0968 19.025 16.4249L19.0625 18.8624C19.0625 19.0874 18.9687 19.303 18.7906 19.453C17.9187 20.1843 16.925 20.7749 15.8281 21.1686C15.6125 21.2436 15.3781 21.2249 15.1906 21.103L13.1 19.8468C12.7062 19.8749 12.3125 19.8749 11.9187 19.8468L9.8281 21.103C9.63122 21.2155 9.39685 21.2436 9.18122 21.1686C8.11247 20.7843 7.10935 20.2124 6.21872 19.4624C6.04997 19.3218 5.94685 19.0968 5.95622 18.8718L5.99372 16.4343C5.76872 16.1061 5.57185 15.7686 5.4031 15.4124L3.27497 14.2311C3.0781 14.1186 2.93747 13.9311 2.89997 13.7061C2.7031 12.5905 2.69372 11.428 2.89997 10.2936C2.93747 10.0686 3.0781 9.88114 3.27497 9.76864L5.4031 8.58739Z"  stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/> <path d="M12.4999 16.4999C14.9852 16.4999 16.9999 14.4852 16.9999 11.9999C16.9999 9.51463 14.9852 7.49991 12.4999 7.49991C10.0146 7.49991 7.99988 9.51463 7.99988 11.9999C7.99988 14.4852 10.0146 16.4999 12.4999 16.4999Z"  stroke-width="1.5" stroke-miterlimit="10" stroke-linecap="round" stroke-linejoin="round"/> </svg></small><span>Settings</span>
                        </a>
                    </li>
                    <li class="mobile_nav">
                        <a href="../login.php"
                        class="menu-link d-flex align-items-center gap-2 <?= (isset($activebar) && $activebar == 'settings') ? 'activenav' : '' ?>">

                            <small>
                            <img  src="{{asset('public/assets/icons/SignOut.svg')}}" alt="">

                        </small><span>Logout</span>
                        </a>
                    </li>
                </ul>
            </div>
        </nav>
    </div>
</div>
<script>
     setInterval(() => {
        Show_task_msg()
        Show_msg()
    }, 3000);
     function Show_msg(){
        $.ajax({
            url : "{{route('worker.msg_counter')}}",
            type : "POST",
            data : {
                _token : "{{csrf_token()}}"
            },
            success : function(res){
                console.log(res);
                $('#show_counter').text(res.length);


            }
        })
    }
    Show_msg();
</script>

<script>
    function Show_task_msg(){
        $.ajax({
            url : "{{route('worker.task_msg_counter')}}",
            type : "POST",
            data : {
                _token : "{{csrf_token()}}"
            },
            success : function(res){
                sum = 0
                res.forEach(e => {
                    console.log(e.chat);
                    if(e.chat !== null)
                    sum += e.chat.length
            });
            console.log(sum);

                $('#show_task_counter').text(sum);


            }
        })
    }
    Show_task_msg();
</script>
