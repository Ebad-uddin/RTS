<?php
$activebar = "users";
?>
@include('worker.header')
    <div class="iq-top-navbar py-2 rtl-iq-top-navbar ">
        <div class="iq-navbar-custom">
            <nav class="navbar navbar-expand-lg navbar-light p-0 toSetNavBarAll w-100">
                <div class="iq-navbar-logo d-flex align-items-center justify-content-between">
                    <i class="ri-menu-line wrapper-menu"></i>
                    <!-- Mobile Logo -->
                </div>
                <div class="iq-search-bar device-search">
                    <h4 class="main_content_title">User View</h4>
                </div>
                @include('worker.tooltip')
            </nav>
        </div>
    </div>



    <div class="content-page rtl-page">
        <div class="container-fluid mt-4">
            <div class="row">
                <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12">
                    <div class="mt-4">
                        <div class="toSetSettingsBackground">
                            <div class="row">
                                <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12 sections_change">
                                    <div class="mb-4 d-flex align-items-center justify-content-between">
                                        <h3 class="userview_head3">Member Details</h3>
                                        <button class="btn btn-primary" > Update Profile </button>
                                    </div>
                                </div>
                                <div class="col-sm-12 col-md-4 col-lg-3 col-xl-3 col-xxl-3 col-12">
                                    <div class="d-flex align-items-center flex-column justify-content-center position-relative h-100">
                                        <div class="d-flex ">
                                            <div class="avatar-upload">
                                                <div class="avatar-edit">
                                                    <label for="imageUpload"></label>
                                                </div>
                                                <div class="avatar-preview">
                                                    <div style="background-image: url('./assets/images/Userimage.png')" class="imagePreview" id="imagePreview">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="d-flex align-items-center position-absolute">
                                            <label for="imageUpload" class="upload_picture">
                                                <div class="avatar-edit d-flex justify-content-center align-items-center">
                                                    <i class="fi fi-rr-upload mt-1"></i>
                                                    Upload Picture
                                                </div>
                                            </label>
                                            <input type="file" id="imageUpload" accept=".png, .jpg, .jpeg" style="display: none;">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-12 col-md-8 col-lg-4 col-xl-4 col-xxl-4 col-12">
                                    <div class="row">
                                        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12">
                                            <div class="mb-3">
                                                <label class="userview_label">First Name</label>
                                                <input type="text" class="form-control w-100" placeholder="Please enter your first name">
                                            </div>
                                        </div>
                                        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12">
                                            <div class="mb-3">
                                                <label class="userview_label">Last Name</label>
                                                <input type="text" class="form-control w-100" placeholder="Please enter your last name">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-12 col-md-12 col-lg-5 col-xl-5 col-xxl-5 col-12">
                                    <div class="mb-3">
                                        <label class="userview_label">Email Address</label>
                                        <input type="text" class="form-control w-100" placeholder="Please enter your email">
                                    </div>
                                    <div class="mb-3">
                                        <label class="userview_label">Main Phone</label>
                                        <input type="number" class="form-control w-100" placeholder="Please enter your number">
                                    </div>
                                </div>
                            </div>
                            <div class="row mt-2 mb-2 auto_row">
                                <div class="col-sm-12 col-md-12 col-lg-6 col-xl-6 col-xxl-6 col-12 auto_pad">
                                    <div class="row">
                                        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12">
                                            <div class="mb-3">
                                                <div>
                                                    <label class="userview_label">Residential Address</label>
                                                </div>
                                                <input type="text" class="form-control w-100" placeholder="Please enter your residential address">
                                            </div>
                                        </div>
                                        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12">
                                            <div class="mb-3">
                                                <label class="userview_label">Training Level</label>
                                                <input type="text" class="form-control w-100" placeholder="Please enter your training level" value="Basic Level">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-12 col-md-12 col-lg-6 col-xl-6 col-xxl-6 col-12 auto_pad">
                                    <div class="row">
                                        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12">
                                            <div class="mb-3">
                                                <div class="mb-3">
                                                    <div>
                                                        <label class="userview_label">Role</label>
                                                    </div>
                                                    <select class="js-select2" data-minimum-results-for-search="Infinity">
                                                        <option value="">Site Manager</option>
                                                        <option value="">Group Manager</option>
                                                        <option value="">Worker</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12">
                                            <div class="mb-3">
                                                <label class="userview_label">Status</label>
                                                <input type="text" class="form-control w-100" placeholder="" value="">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12 auto_pad">
                                    <div class="mb-3">
                                        <label class="userview_label">Comments</label>
                                        <textarea type="text" class="form-control w-100 form_textarea" placeholder="Please enter some comments" value="New member"></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

@include('worker.footer')