<?php
$activebar = 'reports';
?>
<style>

    .index-TablePage {
        height: 80vh !important;
    }
</style>

@include('worker.header')
<div class="iq-top-navbar py-2 rtl-iq-top-navbar ">
    <div class="iq-navbar-custom">
        <nav class="navbar navbar-expand-lg navbar-light p-0 toSetNavBarAll w-100">
            <div class="iq-navbar-logo d-flex align-items-center justify-content-between">
                <i class="ri-menu-line wrapper-menu"></i>
                <!-- Mobile Logo -->
            </div>
            <div class="iq-search-bar device-search">
                <h4 class="main_content_title ps-3">Reports</h4>
            </div>
            @include('worker.tooltip')
        </nav>
    </div>
</div>



<div class="content-page rtl-page">
    <div class="container-fluid mt-4">
        <div class="row">
            <div class="col-12">
                <div class="row mt-4">
                    <div class="col-12 ">
                        <div class="bg-white p-3 index-TablePage">
                            <div class="mb-3 h-100">
                                <div
                                    class="align-items-center d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column h-100 flex-column justify-content-between toSetFilterIcon">
                                   
                                   <div class="d-flex align-items-center justify-content-center w-100 h-100 gap-4" >
                                   <svg width="35px" height="35px" viewBox="-1 0 32 32" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" fill="#000000" stroke="#000000" stroke-width="0.192"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <g id="icomoon-ignore"> </g> <path d="M29.867 8.96l-10.667-7.253v4h-19.2v24.533h24.533v-17.707l5.333-3.573zM20.267 3.733l7.68 5.173-7.68 5.227v-2.827c0 0 0 0 0 0v-1.067h-1.92c-0.053 0-0.053 0-0.107 0-1.92 0-5.867 0.373-8.907 2.88 1.44-3.52 4.747-6.293 9.76-6.293v0c0 0 0.053 0 0.053 0s0 0 0.053 0h1.067v-1.013c0 0 0 0 0-0.053v-2.027zM23.467 29.227h-22.4v-22.4h12.96c-4.267 1.867-6.56 6.133-6.56 10.56 2.453-5.44 8.16-6.133 10.773-6.133 0.373 0 0.693 0 0.96 0.053v4.8l4.267-2.88v16z" fill="#000000"> </path> </g></svg>
                                    <h4 class="file-Heading mx-2 text-muted">
                                      To be Decided in the Version 2
                                    </h4>
                                    
                                   </div>

                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@include('worker.footer')
