<?php
$activebar = "groups";
?>
@include('worker.header')
    <div class="iq-top-navbar py-2 rtl-iq-top-navbar ">
        <div class="iq-navbar-custom">
            <nav class="navbar navbar-expand-lg navbar-light p-0 toSetNavBarAll w-100">
                <div class="iq-navbar-logo d-flex align-items-center justify-content-between">
                    <i class="ri-menu-line wrapper-menu"></i>
                    <!-- Mobile Logo -->
                </div>
                <div class="iq-search-bar device-search">
                    <h4 class="main_content_title">Group View</h4>
                </div>
                @include('worker.tooltip')
            </nav>
        </div>
    </div>



    <div class="content-page rtl-page">
        <div class="container-fluid mt-4">
            <div class="row">
                <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12">
                    <div class="mt-4">
                        <div class="toSetSettingsBackground">
                            <div class="row">
                                <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12 sections_change">
                                    <div class="mb-4 d-flex justify-content-between align-items-center">
                                        <h3 class="userview_head3">Group Details</h3>
                                    </div>
                                </div>
                                <div class="col-sm-12 col-md-12 col-lg-6 col-xl-6 col-xxl-6 col-12">
                                    <div class="row">
                                        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12">
                                            <div class="mb-3">
                                                <label class="userview_label">Group Name</label>
                                                <p>Group Name</p>
                                            </div>
                                        </div>
                                        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12">
                                            <div class="mb-3">
                                                <label class="userview_label">Address</label>
                                                <p>Address</p>

                                                <!-- <input type="text" class="form-control w-100" placeholder="Please enter your address"> -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-12 col-md-12 col-lg-6 col-xl-6 col-xxl-6 col-12">
                                    <div class="mb-3">
                                        <label class="userview_label">Email Address</label>
                                        <p>group@mail.com</p>

                                        <!-- <input type="text" class="form-control w-100" placeholder="Please enter your email"> -->
                                    </div>
                                    <div class="mb-3">
                                        <label class="userview_label">Main Phone</label>
                                        <p>+1-342-4455</p>
                                        <!-- <input type="number" class="form-control w-100" placeholder="Please enter your number"> -->
                                    </div>
                                </div>
                            </div>
                            <div class="row mt-2 mb-2 auto_row">
                                <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12 auto_pad">
                                    <div class="mb-4">
                                        <label class="userview_label">Comments</label>
                                        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. In accusamus doloremque optio explicabo, ducimus maiores itaque! Labore dolores, cumque numquam quisquam in veritatis nihil magnam, quis illum autem, inventore iste!</p>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12 sections_change">
                                    <div class="mb-4 d-flex align-items-center justify-content-between">
                                        <div class="d-flex align-items-center gap-3">
                                            <h3 class="userview_head3">Group Members</h3>
                                           
                                        </div>
                                        <!-- <div class="d-flex align-items-center gap-3">
                                            <button type="button" class="btn btn-secondary">Sort by <img alt="" src="../assets/icons/f_sort.svg"></button>
                                            <div class="position-relative">
                                                <input type="search" class="form-control w-100 search_input" placeholder="Search">
                                                <img alt="" src="../assets/icons/f_search.svg" class="position-absolute search_svg">
                                            </div>
                                        </div> -->
                                    </div>
                                </div>
                                <div class="col-sm-6 col-md-6 col-lg-3 col-xl-3 col-xxl-3 col-12">
                                    <div class="card member-card">
                                        <div class="card-body member-card-body">
                                            <div class="h-100 w-100 d-flex justify-content-center align-items-center mb-3">
                                                <img src="../assets/images/Groupmember1.png" class="member-image">
                                            </div>
                                            <div class="mb-2">
                                                <h5 class="member_name text-center">Theresa Webb</h5>
                                                <h6 class="member_type text-center">Worker</h6>
                                            </div>
                                            <div class="mb-2 d-flex justify-content-center gap-1">
                                                <a class="btn btn-secondary member_link" href="chat.php">Chat</a>
                                                <a class="btn btn-secondary member_link" href="user-view.php">View</a>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6 col-md-6 col-lg-3 col-xl-3 col-xxl-3 col-12">
                                    <div class="card member-card">
                                        <div class="card-body member-card-body">
                                            <div class="h-100 w-100 d-flex justify-content-center align-items-center mb-3">
                                                <img src="../assets/images/Groupmember2.png" class="member-image">
                                            </div>
                                            <div class="mb-2">
                                                <h5 class="member_name text-center">Robert Fox</h5>
                                                <h6 class="member_type text-center">Worker</h6>
                                            </div>
                                            <div class="mb-2 d-flex justify-content-center gap-1">
                                                <a class="btn btn-secondary member_link" href="chat.php">Chat</a>
                                                <a class="btn btn-secondary member_link" href="user-view.php">View</a>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6 col-md-6 col-lg-3 col-xl-3 col-xxl-3 col-12">
                                    <div class="card member-card">
                                        <div class="card-body member-card-body">
                                            <div class="h-100 w-100 d-flex justify-content-center align-items-center mb-3">
                                                <img src="../assets/images/Groupmember3.png" class="member-image">
                                            </div>
                                            <div class="mb-2">
                                                <h5 class="member_name text-center">Kristin Watson</h5>
                                                <h6 class="member_type text-center">Worker</h6>
                                            </div>
                                            <div class="mb-2 d-flex justify-content-center gap-1">
                                                <a class="btn btn-secondary member_link" href="chat.php">Chat</a>
                                                <a class="btn btn-secondary member_link" href="user-view.php">View</a>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6 col-md-6 col-lg-3 col-xl-3 col-xxl-3 col-12">
                                    <div class="card member-card">
                                        <div class="card-body member-card-body">
                                            <div class="h-100 w-100 d-flex justify-content-center align-items-center mb-3">
                                                <img src="../assets/images/Groupmember1.png" class="member-image">
                                            </div>
                                            <div class="mb-2">
                                                <h5 class="member_name text-center">Theresa Webb</h5>
                                                <h6 class="member_type text-center">Worker</h6>
                                            </div>
                                            <div class="mb-2 d-flex justify-content-center gap-1">
                                                <a class="btn btn-secondary member_link" href="chat.php">Chat</a>
                                                <a class="btn btn-secondary member_link" href="user-view.php">View</a>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6 col-md-6 col-lg-3 col-xl-3 col-xxl-3 col-12">
                                    <div class="card member-card">
                                        <div class="card-body member-card-body">
                                            <div class="h-100 w-100 d-flex justify-content-center align-items-center mb-3">
                                                <img src="../assets/images/Groupmember2.png" class="member-image">
                                            </div>
                                            <div class="mb-2">
                                                <h5 class="member_name text-center">Robert Fox</h5>
                                                <h6 class="member_type text-center">Worker</h6>
                                            </div>
                                            <div class="mb-2 d-flex justify-content-center gap-1">
                                                <a class="btn btn-secondary member_link" href="chat.php">Chat</a>
                                                <a class="btn btn-secondary member_link" href="user-view.php">View</a>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6 col-md-6 col-lg-3 col-xl-3 col-xxl-3 col-12">
                                    <div class="card member-card">
                                        <div class="card-body member-card-body">
                                            <div class="h-100 w-100 d-flex justify-content-center align-items-center mb-3">
                                                <img src="../assets/images/Groupmember3.png" class="member-image">
                                            </div>
                                            <div class="mb-2">
                                                <h5 class="member_name text-center">Kristin Watson</h5>
                                                <h6 class="member_type text-center">Worker</h6>
                                            </div>
                                            <div class="mb-2 d-flex justify-content-center gap-1">
                                                <a class="btn btn-secondary member_link" href="chat.php">Chat</a>
                                                <a class="btn btn-secondary member_link" href="user-view.php">View</a>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6 col-md-6 col-lg-3 col-xl-3 col-xxl-3 col-12">
                                    <div class="card member-card">
                                        <div class="card-body member-card-body">
                                            <div class="h-100 w-100 d-flex justify-content-center align-items-center mb-3">
                                                <img src="../assets/images/Groupmember1.png" class="member-image">
                                            </div>
                                            <div class="mb-2">
                                                <h5 class="member_name text-center">Theresa Webb</h5>
                                                <h6 class="member_type text-center">Worker</h6>
                                            </div>
                                            <div class="mb-2 d-flex justify-content-center gap-1">
                                                <a class="btn btn-secondary member_link" href="chat.php">Chat</a>
                                                <a class="btn btn-secondary member_link" href="user-view.php">View</a>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6 col-md-6 col-lg-3 col-xl-3 col-xxl-3 col-12">
                                    <div class="card member-card">
                                        <div class="card-body member-card-body">
                                            <div class="h-100 w-100 d-flex justify-content-center align-items-center mb-3">
                                                <img src="../assets/images/Groupmember2.png" class="member-image">
                                            </div>
                                            <div class="mb-2">
                                                <h5 class="member_name text-center">Robert Fox</h5>
                                                <h6 class="member_type text-center">Worker</h6>
                                            </div>
                                            <div class="mb-2 d-flex justify-content-center gap-1">
                                                <a class="btn btn-secondary member_link" href="chat.php">Chat</a>
                                                <a class="btn btn-secondary member_link" href="user-view.php">View</a>
                                                
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

@include('worker.footer')