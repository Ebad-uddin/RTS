<?php
$activebar = "index";
?>

@include('worker.header')
<div class="iq-top-navbar py-2 rtl-iq-top-navbar ">
    <div class="iq-navbar-custom">
        <nav class="navbar navbar-expand-lg navbar-light p-0 toSetNavBarAll w-100">
            <div class="iq-navbar-logo d-flex align-items-center justify-content-between">
                <i class="ri-menu-line wrapper-menu"></i>
                <!-- Mobile Logo -->
            </div>
            <div class="iq-search-bar device-search">
                <h4 class="main_content_title ps-3">Dashboard</h4>
            </div>
            @include('worker.tooltip')
            <div class="d-xxl-none d-xl-none d-lg-none d-md-block d-sm-block d-block">
                <ul class="align-items-center d-flex gap-4 list-unstyled text-decoration-none m-0">
                    <li>
                    <button class="nav-AddNew-Button btn btn-primary" type="button" data-bs-toggle="modal" data-bs-target="#create_task_modal">Create Task</button>
                    </li>
                </ul>
            </div>
        </nav>
    </div>
</div>


<div class="content-page rtl-page">
    <div class="container-fluid mt-4">
        <div class="row">
            <div class="col-12">
                <div class="row">
                    <div class="col-12 indexpageSetting pe-0">
                        <nav>
                            <div class="nav nav-tabs" id="nav-tab" role="tablist">
                                <div class="row w-100">
                                    <div class="col-xl col-xxl col-lg-12 col-md-12 col-sm-12 mt-3 pe-0">
                                        <button class="nav-link active w-100" id="nav-home-tab" data-bs-toggle="tab"
                                            data-bs-target="#nav-home" type="button" role="tab" aria-controls="nav-home"
                                            aria-selected="true">
                                            <div class="Dashboard-Card">
                                                <div class="d-flex align-items-center justify-content-between">
                                                    <div>
                                                        <div>
                                                            <p class="p-0 m-0 card-Status">All Tasks</p>
                                                        </div>
                                                        <div>
                                                            <h1 class="p-0 m-0 Card-Number">{{count($task_data)}}</h1>
                                                        </div>
                                                    </div>
                                                    <div
                                                        class="Dashboard-Card-Icon d-flex align-items-center justify-content-center">

                                                        <svg fill="none" width="30px" height="30px" viewBox="0 0 32 32"
                                                            version="1.1" xmlns="http://www.w3.org/2000/svg">
                                                            <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                                                            <g id="SVGRepo_tracerCarrier" stroke-linecap="round"
                                                                stroke-linejoin="round"></g>
                                                            <g id="SVGRepo_iconCarrier">
                                                                <title>clipboard</title>
                                                                <path
                                                                    d="M26 5.25h-2c-0.414 0-0.75 0.336-0.75 0.75s0.336 0.75 0.75 0.75v0h1.25v22.5h-18.5v-22.5h1.25c0.414 0 0.75-0.336 0.75-0.75s-0.336-0.75-0.75-0.75v0h-2c-0.414 0-0.75 0.336-0.75 0.75v0 24c0 0.414 0.336 0.75 0.75 0.75h20c0.414-0 0.75-0.336 0.75-0.75v0-24c-0-0.414-0.336-0.75-0.75-0.75v0zM11 8.749h10c0.414 0 0.75-0.336 0.75-0.75s-0.336-0.75-0.75-0.75v0h-2.019c0.477-0.616 0.766-1.398 0.769-2.248v-0.001c0-2.071-1.679-3.75-3.75-3.75s-3.75 1.679-3.75 3.75v0c0.003 0.851 0.292 1.633 0.775 2.258l-0.006-0.009h-2.019c-0.414 0-0.75 0.336-0.75 0.75s0.336 0.75 0.75 0.75v0zM13.75 5c0-0 0-0.001 0-0.001 0-1.243 1.007-2.25 2.25-2.25s2.25 1.007 2.25 2.25c0 1.243-1.007 2.25-2.25 2.25v0c-1.242-0.002-2.248-1.008-2.25-2.249v-0z">
                                                                </path>
                                                            </g>
                                                        </svg>

                                                    </div>
                                                </div>
                                                {{-- <div class="mt-2">
                                                    <p class="card-Pargraph p-0 m-0 text-start">
                                                        <span class="PercentageSetting">


                                                            8.5%
                                                        </span>
                                                        Up from yesterday
                                                    </p>
                                                </div> --}}
                                            </div>
                                        </button>

                                    </div>

                                    {{-- <div class="col-xl col-xxl col-lg-12 col-md-12 col-sm-12 mt-3 pe-0">
                                        <button class="nav-link w-100" id="nav-contact-tab" data-bs-toggle="tab"
                                            data-bs-target="#nav-contact" type="button" role="tab"
                                            aria-controls="nav-contact" aria-selected="false">
                                            <div class="Dashboard-Card">
                                                <div class="d-flex align-items-center justify-content-between">
                                                    <div>
                                                        <div>
                                                            <p class="p-0 m-0 card-Status text-start">Tasks
                                                                Approved</p>
                                                        </div>
                                                        <div>
                                                            <h1 class="p-0 m-0 Card-Number text-start">456</h1>
                                                        </div>
                                                    </div>
                                                    <div
                                                        class="Dashboard-Card-Icon d-flex align-items-center justify-content-center">
                                                        <svg fill="none" width="30px" height="30px" viewBox="0 0 32 32"
                                                            version="1.1" xmlns="http://www.w3.org/2000/svg">
                                                            <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                                                            <g id="SVGRepo_tracerCarrier" stroke-linecap="round"
                                                                stroke-linejoin="round"></g>
                                                            <g id="SVGRepo_iconCarrier">
                                                                <title>clipboard-check</title>
                                                                <path
                                                                    d="M26 5.25h-2c-0.414 0-0.75 0.336-0.75 0.75s0.336 0.75 0.75 0.75v0h1.25v22.5h-18.5v-22.5h1.25c0.414 0 0.75-0.336 0.75-0.75s-0.336-0.75-0.75-0.75v0h-2c-0.414 0-0.75 0.336-0.75 0.75v0 24c0 0.414 0.336 0.75 0.75 0.75h20c0.414-0 0.75-0.336 0.75-0.75v0-24c-0-0.414-0.336-0.75-0.75-0.75v0zM11 8.749h10c0.414 0 0.75-0.336 0.75-0.75s-0.336-0.75-0.75-0.75v0h-2.019c0.477-0.616 0.766-1.398 0.769-2.248v-0.001c0-2.071-1.679-3.75-3.75-3.75s-3.75 1.679-3.75 3.75v0c0.003 0.851 0.292 1.633 0.775 2.258l-0.006-0.009h-2.019c-0.414 0-0.75 0.336-0.75 0.75s0.336 0.75 0.75 0.75v0zM13.75 5c0-0 0-0.001 0-0.001 0-1.243 1.007-2.25 2.25-2.25s2.25 1.007 2.25 2.25c0 1.243-1.007 2.25-2.25 2.25v0c-1.242-0.002-2.248-1.008-2.25-2.249v-0zM20.326 13.494l-6.792 7.424-1.886-1.873c-0.136-0.136-0.323-0.22-0.531-0.22-0.414 0-0.749 0.335-0.749 0.749 0 0.209 0.085 0.398 0.223 0.534l0 0 2.44 2.424 0.015 0.006 0.007 0.015c0.13 0.122 0.306 0.197 0.499 0.197 0.199 0 0.38-0.080 0.512-0.21l-0 0 0.027-0.011 0.005-0.011 0.017-0.012 7.317-8c0.122-0.133 0.197-0.311 0.197-0.506 0-0.414-0.335-0.749-0.749-0.749-0.219 0-0.415 0.094-0.552 0.243l-0 0.001z">
                                                                </path>
                                                            </g>
                                                        </svg>
                                                    </div>
                                                </div>
                                                <div class="mt-2">
                                                    <p class="card-Pargraph p-0 m-0 text-start">
                                                        <span class="PercentageSetting">

                                                            8.5%</span>
                                                        Up from yesterday
                                                    </p>
                                                </div>
                                            </div>
                                        </button>

                                    </div> --}}
                                    <div class="col-xl col-xxl col-lg-12 col-md-12 col-sm-12 mt-3 pe-0">
                                        <button class="nav-link w-100" id="nav-contact2-tab" data-bs-toggle="tab"
                                            data-bs-target="#nav-contact2" type="button" role="tab"
                                            aria-controls="nav-contact" aria-selected="false">
                                            <div class="Dashboard-Card">
                                                <div class="d-flex align-items-center justify-content-between">
                                                    <div>
                                                        <div>
                                                            <p class="p-0 m-0 card-Status text-start">Tasks
                                                                Active</p>
                                                        </div>
                                                        <div>
                                                            <h1 class="p-0 m-0 Card-Number text-start" id="appndActive">{{count($active_tasks)}}</h1>
                                                        </div>
                                                    </div>
                                                    <div
                                                        class="Dashboard-Card-Icon d-flex align-items-center justify-content-center">
                                                        <svg fill="none" width="30px" height="30px" viewBox="0 0 32 32"
                                                            version="1.1" xmlns="http://www.w3.org/2000/svg">
                                                            <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                                                            <g id="SVGRepo_tracerCarrier" stroke-linecap="round"
                                                                stroke-linejoin="round"></g>
                                                            <g id="SVGRepo_iconCarrier">
                                                                <title>clipboard-list-check</title>
                                                                <path
                                                                    d="M26 5.25h-2c-0.414 0-0.75 0.336-0.75 0.75s0.336 0.75 0.75 0.75v0h1.25v22.5h-18.5v-22.5h1.25c0.414 0 0.75-0.336 0.75-0.75s-0.336-0.75-0.75-0.75v0h-2c-0.414 0-0.75 0.336-0.75 0.75v0 24c0 0.414 0.336 0.75 0.75 0.75h20c0.414-0 0.75-0.336 0.75-0.75v0-24c-0-0.414-0.336-0.75-0.75-0.75v0zM23.1 15.3h-7.133c-0.414 0-0.75 0.336-0.75 0.75s0.336 0.75 0.75 0.75h7.133c0.414 0 0.75-0.336 0.75-0.75s-0.336-0.75-0.75-0.75v0zM8.438 17.234l1.010 1.002 0.015 0.006 0.007 0.015c0.131 0.122 0.306 0.197 0.5 0.197 0.202 0 0.385-0.082 0.517-0.214v0l0.021-0.009 0.004-0.009 0.018-0.013 3.028-3.311c0.123-0.133 0.199-0.312 0.199-0.508 0-0.414-0.336-0.75-0.75-0.75-0.22 0-0.418 0.095-0.555 0.246l-0.001 0.001-2.501 2.733-0.455-0.452c-0.135-0.13-0.318-0.21-0.521-0.21-0.414 0-0.75 0.336-0.75 0.75 0 0.204 0.082 0.39 0.214 0.525l-0-0zM16.033 22.145c-0.414 0-0.75 0.336-0.75 0.75s0.336 0.75 0.75 0.75v0h7.133c0.414 0 0.75-0.336 0.75-0.75s-0.336-0.75-0.75-0.75v0zM8.283 22.895c0 0 0 0 0 0 0 1.157 0.938 2.094 2.094 2.094s2.094-0.938 2.094-2.094c0-1.157-0.938-2.094-2.094-2.094-0 0-0 0-0.001 0h0c-1.156 0.002-2.092 0.938-2.094 2.094v0zM11 8.749h10c0.414 0 0.75-0.336 0.75-0.75s-0.336-0.75-0.75-0.75v0h-2.019c0.477-0.616 0.766-1.398 0.769-2.248v-0.001c0-2.071-1.679-3.75-3.75-3.75s-3.75 1.679-3.75 3.75v0c0.003 0.851 0.292 1.633 0.775 2.258l-0.006-0.009h-2.019c-0.414 0-0.75 0.336-0.75 0.75s0.336 0.75 0.75 0.75v0zM16 2.75c1.242 0 2.249 1.007 2.249 2.25s-1.007 2.25-2.25 2.25c-1.242 0-2.249-1.007-2.25-2.249v-0c0.002-1.242 1.008-2.248 2.25-2.25h0z">
                                                                </path>
                                                            </g>
                                                        </svg>
                                                    </div>
                                                </div>
                                                {{-- <div class="mt-2">
                                                    <p class="card-Pargraph p-0 m-0 text-start">
                                                        <span class="PercentageSetting"><svg width="14" height="8"
                                                                class="dashboardper" viewBox="0 0 14 8" fill="none"
                                                                xmlns="http://www.w3.org/2000/svg">
                                                                <path
                                                                    d="M9.86654 0L11.3932 1.52667L8.13987 4.78L5.4732 2.11333L0.533203 7.06L1.4732 8L5.4732 4L8.13987 6.66667L12.3399 2.47333L13.8665 4V0H9.86654Z" />
                                                            </svg>
                                                            8.5%</span>
                                                        Up from yesterday
                                                    </p>
                                                </div> --}}
                                            </div>
                                        </button>

                                    </div>
                                    <div class="col-xl col-xxl col-lg-12 col-md-12 col-sm-12 mt-3 pe-0">
                                        <button class="nav-link w-100" id="nav-contact3-tab" data-bs-toggle="tab"
                                            data-bs-target="#nav-contact3" type="button" role="tab"
                                            aria-controls="nav-contact" aria-selected="false">
                                            <div class="Dashboard-Card">
                                                <div class="d-flex align-items-center justify-content-between">
                                                    <div>
                                                        <div>
                                                            <p class="p-0 m-0 card-Status text-start">Tasks
                                                                Expired</p>
                                                        </div>
                                                        <div>
                                                            <h1 class="p-0 m-0 Card-Number text-start" id="appndExpire">{{count($expired_tasks)}}</h1>
                                                        </div>
                                                    </div>
                                                    <div
                                                        class="Dashboard-Card-Icon d-flex align-items-center justify-content-center">
                                                        <!-- <svg width="24" height="24" viewBox="0 0 24 24" fill="none"
                                                            xmlns="http://www.w3.org/2000/svg">
                                                            <path
                                                                d="M16.3135 8.0625L20.25 12L16.3135 15.9375M9.75 12H20.2472M9.75 20.25H4.5C4.30109 20.25 4.11032 20.171 3.96967 20.0303C3.82902 19.8897 3.75 19.6989 3.75 19.5V4.5C3.75 4.30109 3.82902 4.11032 3.96967 3.96967C4.11032 3.82902 4.30109 3.75 4.5 3.75H9.75"
                                                                stroke-width="1.5" stroke-linecap="round"
                                                                stroke-linejoin="round" />
                                                        </svg> -->
                                                        <svg width="30px" height="30px" fill="none" viewBox="0 0 24 24"
                                                            xmlns="http://www.w3.org/2000/svg" fill="#000000">
                                                            <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                                                            <g id="SVGRepo_tracerCarrier" stroke-linecap="round"
                                                                stroke-linejoin="round"></g>
                                                            <g id="SVGRepo_iconCarrier">
                                                                <path
                                                                    d="M20 4h-3V3h-3a2 2 0 0 0-4 0H7v1H4v18h16zM8 4h3V2.615A.615.615 0 0 1 11.614 2h.771a.615.615 0 0 1 .615.615V4h3v2H8zm11 17H5V5h2v2h10V5h2zM7 18h5v1H7zm0-8h10v1H7zm0 4h10v1H7z">
                                                                </path>
                                                                <path fill="none" d="M0 0h24v24H0z"></path>
                                                            </g>
                                                        </svg>
                                                        <!-- <svg width="30px"  height="30px" fill="none" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" fill="#000000" class="bi bi-clipboard-x"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <path fill-rule="evenodd" d="M6.146 7.146a.5.5 0 0 1 .708 0L8 8.293l1.146-1.147a.5.5 0 1 1 .708.708L8.707 9l1.147 1.146a.5.5 0 0 1-.708.708L8 9.707l-1.146 1.147a.5.5 0 0 1-.708-.708L7.293 9 6.146 7.854a.5.5 0 0 1 0-.708z"></path> <path d="M4 1.5H3a2 2 0 0 0-2 2V14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V3.5a2 2 0 0 0-2-2h-1v1h1a1 1 0 0 1 1 1V14a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V3.5a1 1 0 0 1 1-1h1v-1z"></path> <path d="M9.5 1a.5.5 0 0 1 .5.5v1a.5.5 0 0 1-.5.5h-3a.5.5 0 0 1-.5-.5v-1a.5.5 0 0 1 .5-.5h3zm-3-1A1.5 1.5 0 0 0 5 1.5v1A1.5 1.5 0 0 0 6.5 4h3A1.5 1.5 0 0 0 11 2.5v-1A1.5 1.5 0 0 0 9.5 0h-3z"></path> </g></svg> -->
                                                    </div>
                                                </div>
                                                {{-- <div class="mt-2">
                                                    <p class="card-Pargraph p-0 m-0 text-start">
                                                        <span class="PercentageSetting"><svg width="14" height="8"
                                                                class="dashboardper" viewBox="0 0 14 8" fill="none"
                                                                xmlns="http://www.w3.org/2000/svg">
                                                                <path
                                                                    d="M9.86654 0L11.3932 1.52667L8.13987 4.78L5.4732 2.11333L0.533203 7.06L1.4732 8L5.4732 4L8.13987 6.66667L12.3399 2.47333L13.8665 4V0H9.86654Z" />
                                                            </svg>
                                                            8.5%</span>
                                                        Up from yesterday
                                                    </p>
                                                </div> --}}
                                            </div>
                                        </button>

                                    </div>
                                </div>
                            </div>
                        </nav>
                    </div>
                </div>
                <div class="row mt-4">
                    <div class="col-12 ">
                        <div class="bg-white p-3 index-TablePage">

                            <div class="tab-content" id="nav-tabContent">
                                <div class="tab-pane fade show active" id="nav-home" role="tabpanel"
                                    aria-labelledby="nav-home-tab">
                                    <div class="mb-3">
                                        <div
                                            class="align-items-center d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column justify-content-between toSetFilterIcon">
                                            <h4 class="file-Heading">
                                                All Tasks
                                            </h4>
                                            <div
                                                class="mt-xxl-0 mt-xl-0 mt-lg-0 mt-md-0 mt-sm-3 mt-3 d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column gap-2">
                                               <!--   <button data-bs-toggle="dropdown" data-bs-auto-close="inside"
                                                    aria-expanded="false"
                                                    class="FilterButtonSetting btn btn-secondary dropdown-toggle d-flex gap-2 align-items-center">
                                                    Sort by
                                                    <svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path
                                                            d="M3.375 13.4995H7.3125M10.125 11.812L12.9375 14.6245M12.9375 14.6245L15.7499 11.8125M12.9375 14.6245L12.9375 7.87451M3.375 8.99951H8.43743M3.375 4.49951H12.9374"
                                                            stroke-width="1.5" stroke-linecap="round"
                                                            stroke-linejoin="round" />
                                                    </svg>
                                                </button> -->

                                                <div class="dropdown-menu dropdown-menu-end filter_dropdown"
                                                    data-popper-placement="bottom-end">
                                                    <div class="filter-con-div">
                                                        <ul
                                                            class="timeline ddflx mmy d-flex gap-1 m-2 flex-column list-unstyled">



                                                            <li>
                                                                <div class="form-group">
                                                                    <label class="text-label">Status</label> <br />
                                                                    <select disabled name="" class="js-select2 ">
                                                                        <option value="Select Option" disabled>Select
                                                                            Option
                                                                        </option>
                                                                        <option value="Approved">Approved</option>
                                                                        <option value="Submitted" selected>Submitted
                                                                        </option>
                                                                        <option value="Active">Active</option>
                                                                        <option value="Expired">Expired</option>
                                                                    </select>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="form-group">
                                                                    <label class="text-label">Task Id</label> <br />
                                                                    <select disabled name="" class="js-select2 ">
                                                                        <option value="Select Option" disabled>Select
                                                                            Option
                                                                        </option>
                                                                        <option value="6056">6056</option>
                                                                        <option value="3792" selected>3792</option>
                                                                        <option value="3820">3820</option>
                                                                        <option value="5045">5045</option>
                                                                    </select>
                                                                </div>
                                                            </li>





                                                        </ul>
                                                        <div class="d-flex gap-3 flx-d-column">
                                                            <button type="button"
                                                                class="btn w-100 btn-danger light cancelbtn-m"
                                                                data-bs-dismiss="modal">Clear Filters
                                                            </button>
                                                            <button type="button"
                                                                class="ad-n-blk btn btn-primary bg-r-l  w-100 gr-b">Apply
                                                                Filters</button>
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                    <div class="table-responsive">
                                        <table id="" class="dataTable table-responsive stripe w-100 ">
                                            <thead>
                                                <tr>
                                                    <th>
                                                        S.No
                                                    </th>
                                                    <th>Date Created</th>
                                                    <th class="text-start">Task Id</th>
                                                    <th>Task Tittle</th>
                                                    <th>Assigned To</th>
                                                    <th>Start on</th>
                                                    <th>End on</th>
                                                    <th>Status</th>
                                                    <th></th>
                                                </tr>
                                            </thead>
                                            <tbody id="appendAllTaks">
                                             @foreach ($task_data as $k=>$item)
                                                <tr>
                                                    <td>
                                                       <p class="table-MainHeading" > {{$k+1}} </p>
                                                    </td>
                                                    <td>
                                                        @php
                                                        $timestamp = (strtotime($item->created_at));
                                                        $date = date('j.n.Y', $timestamp);
                                                        $time = date('H:i:s', $timestamp);
                                                        @endphp
                                                        <p class="p-0 m-0 table-MainHeading" id="creted_date">
                                                            {{$date}}
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading" id="created_time">
                                                            {{$time}}
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading" id="taskid">
                                                            {{isset($item->task_id) ? $item->task_id : '-'}}
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading" id="task_title">
                                                            {{isset($item->task_name) ? $item->task_name : '-'}}
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            @if(!empty($item->users))
                                                        @foreach ($item->users as $worker)
                                                        <span class="badge badge-inactive">{{isset($worker->f_name) ? $worker->f_name : ''}}</span>
                                                        @endforeach
                                                        @endif
                                                            
                                                        </p>
                                                    </td>
                                                    @php
                                                    $timestamp = (strtotime($item->start_datetime));
                                                    $date = date('j.n.Y', $timestamp);
                                                    $time = date('H:i:s', $timestamp);
                                                    @endphp
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading" id="strt_date">
                                                            {{$date}}
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading" id="strt_time">
                                                            {{$time}}
                                                        </p>
                                                    </td>
                                                    @php
                                                    $timestamp = (strtotime($item->end_datetime));
                                                    $date = date('j.n.Y', $timestamp);
                                                    $time = date('H:i:s', $timestamp);
                                                    @endphp
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading" id="end_date">
                                                            {{$date}}
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading" id="end_time">
                                                            {{$time}}
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <select name="status"  class="js-select2 tosetitas status-select-{{ $k }}" disabled class="js-select2 tosetitas" onchange="checkTertiary(event)">
                                                                <option value="Select Option" disabled>Select Option</option>
                                                                <option value="Approved" {{ isset($item->status) && $item->status == 'Approved' ? 'selected' : '' }}>Approved</option>
                                                                <option value="Submitted" {{ isset($item->status) && $item->status == 'Submitted' ? 'selected' : '' }}>Submitted</option>
                                                                <option value="Active" {{ isset($item->status) && $item->status == 'Active' ? 'selected' : '' }}>Active</option>
                                                                <option value="Expired" {{ isset($item->status) && $item->status == 'Expired' ? 'selected' : '' }}>Expired</option>
                                                                  <option value="Completed" {{ isset($item->status) && $item->status == 'Completed' ? 'selected' : '' }}>Completed</option>
                                                        </select>
                                                    </td>
                                                    <td>
                                                        <div class="tableButtonSetting">
                                                            <div class="btn-group dropstart">
                                                                <a href="#" class="dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false" >
                                                                    <img src="{{asset('public/assets/icons/DotsThreeOutline.svg')}}" alt="">
                                                                </a>
                                                                <ul class="dropdown-menu tosetWidh-Dropdown">
                                                                    <li><a class="dropdown-item  togivepaddingLeft" href="{{route('worker.taskView' , ['id' => $item->id])}}">View</a></li>
                                                                    
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                                @endforeach

                                            </tbody>

                                        </table>

                                    </div>
                                </div>
                                <div class="tab-pane fade" id="nav-profile" role="tabpanel"
                                    aria-labelledby="nav-profile-tab">
                                    <div class="mb-3">
                                        <div
                                            class="align-items-center d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column justify-content-between toSetFilterIcon">
                                            <h4 class="file-Heading">
                                                Task Submitted
                                            </h4>
                                            <!-- <div
                                                class="mt-xxl-0 mt-xl-0 mt-lg-0 mt-md-0 mt-sm-3 mt-3 d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column gap-2">
                                                <button
                                                    class="FilterButtonSetting btn btn-secondary d-flex gap-2 align-items-center">
                                                    Sort by
                                                    <svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path
                                                            d="M3.375 13.4995H7.3125M10.125 11.812L12.9375 14.6245M12.9375 14.6245L15.7499 11.8125M12.9375 14.6245L12.9375 7.87451M3.375 8.99951H8.43743M3.375 4.49951H12.9374"
                                                            stroke-width="1.5" stroke-linecap="round"
                                                            stroke-linejoin="round" />
                                                    </svg>
                                                </button>

                                            </div> -->
                                            <div
                                                class="mt-xxl-0 mt-xl-0 mt-lg-0 mt-md-0 mt-sm-3 mt-3 d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column gap-2">
                                               <!--   <button data-bs-toggle="dropdown" data-bs-auto-close="inside"
                                                    aria-expanded="false"
                                                    class="FilterButtonSetting btn btn-secondary dropdown-toggle d-flex gap-2 align-items-center">
                                                    Sort by
                                                    <svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path
                                                            d="M3.375 13.4995H7.3125M10.125 11.812L12.9375 14.6245M12.9375 14.6245L15.7499 11.8125M12.9375 14.6245L12.9375 7.87451M3.375 8.99951H8.43743M3.375 4.49951H12.9374"
                                                            stroke-width="1.5" stroke-linecap="round"
                                                            stroke-linejoin="round" />
                                                    </svg>
                                                </button> -->

                                                <div class="dropdown-menu dropdown-menu-end filter_dropdown"
                                                    data-popper-placement="bottom-end">
                                                    <div class="filter-con-div">
                                                        <ul
                                                            class="timeline ddflx mmy d-flex gap-1 m-2 flex-column list-unstyled">



                                                            <li>
                                                                <div class="form-group">
                                                                    <label class="text-label">Assigned To</label> <br />
                                                                    <select disabled name="" class="js-select2 ">
                                                                        <option value="Select Option" disabled>Select
                                                                            Option
                                                                        </option>
                                                                        <option value="John Doe">John Doe</option>
                                                                        <option value="Henry Clark" selected>Henry Clark
                                                                        </option>
                                                                        <option value="Methew Henry">Methew Henry</option>
                                                                        <option value="Richard Hord">Richard Hord</option>
                                                                    </select>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="form-group">
                                                                    <label class="text-label">Task Id</label> <br />
                                                                    <select disabled name="" class="js-select2 ">
                                                                        <option value="Select Option" disabled>Select
                                                                            Option
                                                                        </option>
                                                                        <option value="6056">6056</option>
                                                                        <option value="3792" selected>3792</option>
                                                                        <option value="3820">3820</option>
                                                                        <option value="5045">5045</option>
                                                                    </select>
                                                                </div>
                                                            </li>





                                                        </ul>
                                                        <div class="d-flex gap-3 flx-d-column">
                                                            <button type="button"
                                                                class="btn w-100 btn-danger light cancelbtn-m"
                                                                data-bs-dismiss="modal">Clear Filters
                                                            </button>
                                                            <button type="button"
                                                                class="ad-n-blk btn btn-primary bg-r-l  w-100 gr-b">Apply
                                                                Filters</button>
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                    <div class="table-responsive">
                                        <table id="" class="dataTable table-responsive stripe w-100 ">
                                            <thead>
                                                <tr>
                                                    <th>
                                                        <div class="custom-Radio-Button">
                                                            <label class="custom-radio m-0" for="ex_bth">
                                                                <input type="checkbox" class="customme"
                                                                    name="customRadio" id="ex_bth">
                                                                <span class="radio-btn"></span>

                                                            </label>
                                                        </div>
                                                    </th>
                                                    <th>Date Created</th>
                                                    <th class="text-start">Task Id</th>
                                                    <th>Task Tittle</th>
                                                    <th>Assigned To</th>
                                                    <th>Start on</th>
                                                    <th>End on</th>
                                                    <th>Status</th>
                                                    <th></th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>
                                                        <div class="custom-Radio-Button">
                                                            <label class="custom-radio m-0" for="tablec1">
                                                                <input type="checkbox" class="customme"
                                                                    name="customRadio" id="tablec1">
                                                                <span class="radio-btn"></span>

                                                            </label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            03:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            5045
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Check-up Assignment
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            <span class="badge badge-inactive">Greg</span>
                                                            <span class="badge badge-inactive">Gladys</span>
                                                            
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <select disabled name="" class="js-select2 tosetitas"
                                                            onchange="checkTertiary(event)">
                                                            <option value="Select Option" disabled>Select Option
                                                            </option>
                                                            <option value="Approved">Approved</option>
                                                            <option selected value="Submitted">Submitted</option>
                                                            <option value="Active">Active</option>
                                                            <option value="Expired">Expired</option>
                                                        </select>
                                                    </td>
                                                    <td>
                                                        <div class="tableButtonSetting">
                                                            <div class="btn-group dropstart">
                                                                <a href="#" class="dropdown-toggle" type="button"
                                                                    data-bs-toggle="dropdown" aria-expanded="false">
                                                                    <img src="../assets/icons/DotsThreeOutline.svg" alt="">
                                                                </a>
                                                                <ul class="dropdown-menu tosetWidh-Dropdown">
                                                                    <li><a class="dropdown-item  togivepaddingLeft"
                                                                            href="taskView.php">View</a></li>
                                                                    <li><a class="dropdown-item  togivepaddingLeft"
                                                                            href="#" data-bs-toggle="modal"
                                                                            data-bs-target="#DeleteModal"
                                                                            type="button">Delete</a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <div class="custom-Radio-Button">
                                                            <label class="custom-radio m-0" for="tablec2">
                                                                <input type="checkbox" class="customme"
                                                                    name="customRadio" id="tablec2">
                                                                <span class="radio-btn"></span>

                                                            </label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            6065
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Check-up Assignment
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            <span class="badge badge-inactive">Angel</span>
                                                            <span class="badge badge-inactive">Aubrey</span>
                                                            
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <select disabled name="" class="js-select2 tosetitas"
                                                            onchange="checkTertiary(event)">
                                                            <option value="Select Option" disabled>Select Option
                                                            </option>
                                                            <option value="Approved">Approved</option>
                                                            <option selected value="Submitted">Submitted</option>
                                                            <option value="Active">Active</option>
                                                            <option value="Expired">Expired</option>
                                                        </select>
                                                    </td>
                                                    <td>
                                                        <div class="tableButtonSetting">
                                                            <div class="btn-group dropstart">
                                                                <a href="#" class="dropdown-toggle" type="button"
                                                                    data-bs-toggle="dropdown" aria-expanded="false">
                                                                    <img src="../assets/icons/DotsThreeOutline.svg" alt="">
                                                                </a>
                                                                <ul class="dropdown-menu tosetWidh-Dropdown">
                                                                    <li><a class="dropdown-item  togivepaddingLeft"
                                                                            href="taskView.php">View</a></li>
                                                                    <li><a class="dropdown-item  togivepaddingLeft"
                                                                            href="#" data-bs-toggle="modal"
                                                                            data-bs-target="#DeleteModal"
                                                                            type="button">Delete</a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <div class="custom-Radio-Button">
                                                            <label class="custom-radio m-0" for="tablec3">
                                                                <input type="checkbox" class="customme"
                                                                    name="customRadio" id="tablec3">
                                                                <span class="radio-btn"></span>

                                                            </label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            6690
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Check-up Assignment
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            <span class="badge badge-inactive">Arlene</span>
                                                            <span class="badge badge-inactive">Darrell</span>
                                                            
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <select disabled name="" class="js-select2 tosetitas"
                                                            onchange="checkTertiary(event)">
                                                            <option value="Select Option" disabled>Select Option
                                                            </option>
                                                            <option value="Approved">Approved</option>
                                                            <option selected value="Submitted">Submitted</option>
                                                            <option value="Active">Active</option>
                                                            <option value="Expired">Expired</option>
                                                        </select>
                                                    </td>
                                                    <td>
                                                        <div class="tableButtonSetting">
                                                            <div class="btn-group dropstart">
                                                                <a href="#" class="dropdown-toggle" type="button"
                                                                    data-bs-toggle="dropdown" aria-expanded="false">
                                                                    <img src="../assets/icons/DotsThreeOutline.svg" alt="">
                                                                </a>
                                                                <ul class="dropdown-menu tosetWidh-Dropdown">
                                                                    <li><a class="dropdown-item  togivepaddingLeft"
                                                                            href="taskView.php">View</a></li>
                                                                    <li><a class="dropdown-item  togivepaddingLeft"
                                                                            href="#" data-bs-toggle="modal"
                                                                            data-bs-target="#DeleteModal"
                                                                            type="button">Delete</a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <div class="custom-Radio-Button">
                                                            <label class="custom-radio m-0" for="tablec4">
                                                                <input type="checkbox" class="customme"
                                                                    name="customRadio" id="tablec4">
                                                                <span class="radio-btn"></span>

                                                            </label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            5560
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Check-up Assignment
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            <span class="badge badge-inactive">Philip</span>
                                                            <span class="badge badge-inactive">Esther</span>
                                                            
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <select disabled name="" class="js-select2 tosetitas"
                                                            onchange="checkTertiary(event)">
                                                            <option value="Select Option" disabled>Select Option
                                                            </option>
                                                            <option value="Approved">Approved</option>
                                                            <option selected value="Submitted">Submitted</option>
                                                            <option value="Active">Active</option>
                                                            <option value="Expired">Expired</option>
                                                        </select>
                                                    </td>
                                                    <td>
                                                        <div class="tableButtonSetting">
                                                            <div class="btn-group dropstart">
                                                                <a href="#" class="dropdown-toggle" type="button"
                                                                    data-bs-toggle="dropdown" aria-expanded="false">
                                                                    <img src="../assets/icons/DotsThreeOutline.svg" alt="">
                                                                </a>
                                                                <ul class="dropdown-menu tosetWidh-Dropdown">
                                                                    <li><a class="dropdown-item  togivepaddingLeft"
                                                                            href="taskView.php">View</a></li>
                                                                    <li><a class="dropdown-item  togivepaddingLeft"
                                                                            href="#" data-bs-toggle="modal"
                                                                            data-bs-target="#DeleteModal"
                                                                            type="button">Delete</a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                            </tbody>

                                        </table>

                                    </div>
                                </div>
                                <div class="tab-pane fade" id="nav-contact" role="tabpanel"
                                    aria-labelledby="nav-contact-tab">
                                    <div class="mb-3">
                                        <div
                                            class="align-items-center d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column justify-content-between toSetFilterIcon">
                                            <h4 class="file-Heading">
                                                Tasks Approved
                                            </h4>
                                            <div
                                                class="mt-xxl-0 mt-xl-0 mt-lg-0 mt-md-0 mt-sm-3 mt-3 d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column gap-2">
                                               <!--   <button data-bs-toggle="dropdown" data-bs-auto-close="inside"
                                                    aria-expanded="false"
                                                    class="FilterButtonSetting btn btn-secondary dropdown-toggle d-flex gap-2 align-items-center">
                                                    Sort by
                                                    <svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path
                                                            d="M3.375 13.4995H7.3125M10.125 11.812L12.9375 14.6245M12.9375 14.6245L15.7499 11.8125M12.9375 14.6245L12.9375 7.87451M3.375 8.99951H8.43743M3.375 4.49951H12.9374"
                                                            stroke-width="1.5" stroke-linecap="round"
                                                            stroke-linejoin="round" />
                                                    </svg>
                                                </button> -->

                                                <div class="dropdown-menu dropdown-menu-end filter_dropdown"
                                                    data-popper-placement="bottom-end">
                                                    <div class="filter-con-div">
                                                        <ul
                                                            class="timeline ddflx mmy d-flex gap-1 m-2 flex-column list-unstyled">



                                                            <li>
                                                                <div class="form-group">
                                                                    <label class="text-label">Assigned To</label> <br />
                                                                    <select disabled name="" class="js-select2 ">
                                                                        <option value="Select Option" disabled>Select
                                                                            Option
                                                                        </option>
                                                                        <option value="John Doe">John Doe</option>
                                                                        <option value="Henry Clark" selected>Henry Clark
                                                                        </option>
                                                                        <option value="Methew Henry">Methew Henry</option>
                                                                        <option value="Richard Hord">Richard Hord</option>
                                                                    </select>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="form-group">
                                                                    <label class="text-label">Task Id</label> <br />
                                                                    <select disabled name="" class="js-select2 ">
                                                                        <option value="Select Option" disabled>Select
                                                                            Option
                                                                        </option>
                                                                        <option value="6056">6056</option>
                                                                        <option value="3792" selected>3792</option>
                                                                        <option value="3820">3820</option>
                                                                        <option value="5045">5045</option>
                                                                    </select>
                                                                </div>
                                                            </li>





                                                        </ul>
                                                        <div class="d-flex gap-3 flx-d-column">
                                                            <button type="button"
                                                                class="btn w-100 btn-danger light cancelbtn-m"
                                                                data-bs-dismiss="modal">Clear Filters
                                                            </button>
                                                            <button type="button"
                                                                class="ad-n-blk btn btn-primary bg-r-l  w-100 gr-b">Apply
                                                                Filters</button>
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                    <div class="table-responsive">
                                        <table id="" class="dataTable table-responsive stripe w-100 ">
                                            <thead>
                                                <tr>
                                                    <th>
                                                        <div class="custom-Radio-Button">
                                                            <label class="custom-radio m-0" for="ex_bth">
                                                                <input type="checkbox" class="customme"
                                                                    name="customRadio" id="ex_bth">
                                                                <span class="radio-btn"></span>

                                                            </label>
                                                        </div>
                                                    </th>
                                                    <th>Date Created</th>
                                                    <th class="text-start">Task Id</th>
                                                    <th>Task Tittle</th>
                                                    <th>Assigned To</th>
                                                    <th>Start on</th>
                                                    <th>End on</th>
                                                    <th>Status</th>
                                                    <th></th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>
                                                        <div class="custom-Radio-Button">
                                                            <label class="custom-radio m-0" for="tablec1">
                                                                <input type="checkbox" class="customme"
                                                                    name="customRadio" id="tablec1">
                                                                <span class="radio-btn"></span>

                                                            </label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            03:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            5045
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Check-up Assignment
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            <span class="badge badge-inactive">Greg</span>
                                                            <span class="badge badge-inactive">Gladys</span>
                                                            
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <select disabled name="" class="js-select2 tosetitas"
                                                            onchange="checkTertiary(event)">
                                                            <option value="Select Option" disabled>Select Option
                                                            </option>
                                                            <option value="Approved" selected>Approved</option>
                                                            <option value="Submitted">Submitted</option>
                                                            <option value="Active">Active</option>
                                                            <option value="Expired">Expired</option>
                                                        </select>
                                                    </td>
                                                    <td>
                                                        <div class="tableButtonSetting">
                                                            <div class="btn-group dropstart">
                                                                <a href="#" class="dropdown-toggle" type="button"
                                                                    data-bs-toggle="dropdown" aria-expanded="false">
                                                                    <img src="../assets/icons/DotsThreeOutline.svg" alt="">
                                                                </a>
                                                                <ul class="dropdown-menu tosetWidh-Dropdown">
                                                                    <li><a class="dropdown-item  togivepaddingLeft"
                                                                            href="taskView.php">View</a></li>
                                                                    <li><a class="dropdown-item  togivepaddingLeft"
                                                                            href="#" data-bs-toggle="modal"
                                                                            data-bs-target="#DeleteModal"
                                                                            type="button">Delete</a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <div class="custom-Radio-Button">
                                                            <label class="custom-radio m-0" for="tablec2">
                                                                <input type="checkbox" class="customme"
                                                                    name="customRadio" id="tablec2">
                                                                <span class="radio-btn"></span>

                                                            </label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            6065
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Check-up Assignment
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            <span class="badge badge-inactive">Angel</span>
                                                            <span class="badge badge-inactive">Aubrey</span>
                                                            
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <select disabled name="" class="js-select2 tosetitas"
                                                            onchange="checkTertiary(event)">
                                                            <option value="Select Option" disabled>Select Option
                                                            </option>
                                                            <option value="Approved" selected>Approved</option>
                                                            <option value="Submitted">Submitted</option>
                                                            <option value="Active">Active</option>
                                                            <option value="Expired">Expired</option>
                                                        </select>
                                                    </td>
                                                    <td>
                                                        <div class="tableButtonSetting">
                                                            <div class="btn-group dropstart">
                                                                <a href="#" class="dropdown-toggle" type="button"
                                                                    data-bs-toggle="dropdown" aria-expanded="false">
                                                                    <img src="../assets/icons/DotsThreeOutline.svg" alt="">
                                                                </a>
                                                                <ul class="dropdown-menu tosetWidh-Dropdown">
                                                                    <li><a class="dropdown-item  togivepaddingLeft"
                                                                            href="taskView.php">View</a></li>
                                                                    <li><a class="dropdown-item  togivepaddingLeft"
                                                                            href="#" type="button"
                                                                            data-bs-toggle="modal"
                                                                            data-bs-target="#DeleteModal">Delete</a>
                                                                    </li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <div class="custom-Radio-Button">
                                                            <label class="custom-radio m-0" for="tablec3">
                                                                <input type="checkbox" class="customme"
                                                                    name="customRadio" id="tablec3">
                                                                <span class="radio-btn"></span>

                                                            </label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            6690
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Check-up Assignment
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            <span class="badge badge-inactive">Arlene</span>
                                                            <span class="badge badge-inactive">Darrell</span>
                                                            
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <select disabled name="" class="js-select2 tosetitas"
                                                            onchange="checkTertiary(event)">
                                                            <option value="Select Option" disabled>Select Option
                                                            </option>
                                                            <option value="Approved" selected>Approved</option>
                                                            <option value="Submitted">Submitted</option>
                                                            <option value="Active">Active</option>
                                                            <option value="Expired">Expired</option>
                                                        </select>
                                                    </td>
                                                    <td>
                                                        <div class="tableButtonSetting">
                                                            <div class="btn-group dropstart">
                                                                <a href="#" class="dropdown-toggle" type="button"
                                                                    data-bs-toggle="dropdown" aria-expanded="false">
                                                                    <img src="../assets/icons/DotsThreeOutline.svg" alt="">
                                                                </a>
                                                                <ul class="dropdown-menu tosetWidh-Dropdown">
                                                                    <li><a class="dropdown-item  togivepaddingLeft"
                                                                            href="taskView.php">View</a></li>
                                                                    <li><a class="dropdown-item  togivepaddingLeft"
                                                                            href="#" data-bs-toggle="modal"
                                                                            data-bs-target="#DeleteModal"
                                                                            type="button">Delete</a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <div class="custom-Radio-Button">
                                                            <label class="custom-radio m-0" for="tablec4">
                                                                <input type="checkbox" class="customme"
                                                                    name="customRadio" id="tablec4">
                                                                <span class="radio-btn"></span>

                                                            </label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            5560
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Check-up Assignment
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            <span class="badge badge-inactive">Philip</span>
                                                            <span class="badge badge-inactive">Esther</span>
                                                            
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <select disabled name="" class="js-select2 tosetitas"
                                                            onchange="checkTertiary(event)">
                                                            <option value="Select Option" disabled>Select Option
                                                            </option>
                                                            <option value="Approved" selected>Approved</option>
                                                            <option value="Submitted">Submitted</option>
                                                            <option value="Active">Active</option>
                                                            <option value="Expired">Expired</option>
                                                        </select>
                                                    </td>
                                                    <td>
                                                        <div class="tableButtonSetting">
                                                            <div class="btn-group dropstart">
                                                                <a href="#" class="dropdown-toggle" type="button"
                                                                    data-bs-toggle="dropdown" aria-expanded="false">
                                                                    <img src="../assets/icons/DotsThreeOutline.svg" alt="">
                                                                </a>
                                                                <ul class="dropdown-menu tosetWidh-Dropdown">
                                                                    <li><a class="dropdown-item  togivepaddingLeft"
                                                                            href="taskView.php">View</a></li>
                                                                    <li><a class="dropdown-item  togivepaddingLeft"
                                                                            href="#" data-bs-toggle="modal"
                                                                            data-bs-target="#DeleteModal"
                                                                            type="button">Delete</a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                            </tbody>

                                        </table>

                                    </div>
                                </div>
                                <div class="tab-pane fade" id="nav-contact2" role="tabpanel"
                                    aria-labelledby="nav-contact2-tab">
                                    <div class="mb-3">
                                        <div
                                            class="align-items-center d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column justify-content-between toSetFilterIcon">
                                            <h4 class="file-Heading">
                                                Tasks Active
                                            </h4>
                                            <div
                                                class="mt-xxl-0 mt-xl-0 mt-lg-0 mt-md-0 mt-sm-3 mt-3 d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column gap-2">
                                               <!--   <button data-bs-toggle="dropdown" data-bs-auto-close="inside"
                                                    aria-expanded="false"
                                                    class="FilterButtonSetting btn btn-secondary dropdown-toggle d-flex gap-2 align-items-center">
                                                    Sort by
                                                    <svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path
                                                            d="M3.375 13.4995H7.3125M10.125 11.812L12.9375 14.6245M12.9375 14.6245L15.7499 11.8125M12.9375 14.6245L12.9375 7.87451M3.375 8.99951H8.43743M3.375 4.49951H12.9374"
                                                            stroke-width="1.5" stroke-linecap="round"
                                                            stroke-linejoin="round" />
                                                    </svg>
                                                </button> -->

                                                <div class="dropdown-menu dropdown-menu-end filter_dropdown"
                                                    data-popper-placement="bottom-end">
                                                    <div class="filter-con-div">
                                                        <ul
                                                            class="timeline ddflx mmy d-flex gap-1 m-2 flex-column list-unstyled">



                                                            <li>
                                                                <div class="form-group">
                                                                    <label class="text-label">Assigned To</label> <br />
                                                                    <select disabled name="" class="js-select2 ">
                                                                        <option value="Select Option" disabled>Select
                                                                            Option
                                                                        </option>
                                                                        <option value="John Doe">John Doe</option>
                                                                        <option value="Henry Clark" selected>Henry Clark
                                                                        </option>
                                                                        <option value="Methew Henry">Methew Henry</option>
                                                                        <option value="Richard Hord">Richard Hord</option>
                                                                    </select>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="form-group">
                                                                    <label class="text-label">Task Id</label> <br />
                                                                    <select disabled name="" class="js-select2 ">
                                                                        <option value="Select Option" disabled>Select
                                                                            Option
                                                                        </option>
                                                                        <option value="6056">6056</option>
                                                                        <option value="3792" selected>3792</option>
                                                                        <option value="3820">3820</option>
                                                                        <option value="5045">5045</option>
                                                                    </select>
                                                                </div>
                                                            </li>





                                                        </ul>
                                                        <div class="d-flex gap-3 flx-d-column">
                                                            <button type="button"
                                                                class="btn w-100 btn-danger light cancelbtn-m"
                                                                data-bs-dismiss="modal">Clear Filters
                                                            </button>
                                                            <button type="button"
                                                                class="ad-n-blk btn btn-primary bg-r-l  w-100 gr-b">Apply
                                                                Filters</button>
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                    <div class="table-responsive">
                                        <table id="" class="dataTable table-responsive stripe w-100 ">
                                            <thead>
                                                <tr>
                                                    <th>
                                                        S.No
                                                    </th>
                                                    <th>Date Created</th>
                                                    <th class="text-start">Task Id</th>
                                                    <th>Task Tittle</th>
                                                    <th>Assigned To</th>
                                                    <th>Start on</th>
                                                    <th>End on</th>
                                                    <th>Status</th>
                                                    <th></th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @foreach ($active_tasks as $k=>$item)
                                                <tr>
                                                    <td>
                                                        <!-- <div class="custom-Radio-Button">
                                                            <label class="custom-radio m-0" for="tablec1">
                                                                <input type="checkbox" class="customme" name="customRadio" id="tablec1">
                                                                <span class="radio-btn"></span>

                                                            </label>
                                                        </div> -->
                                                        <p class="table-MainHeading" >
                                                    {{$k+1}}
                                                    </p>
                                                    </td>
                                                    <td>
                                                        @php
                                                        $timestamp = (strtotime($item->created_at));
                                                        $date = date('j.n.Y', $timestamp);
                                                        $time = date('H:i:s', $timestamp);
                                                        @endphp
                                                        <p class="p-0 m-0 table-MainHeading" id="creted_date">
                                                            {{$date}}
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading" id="created_time">
                                                            {{$time}}
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading" id="taskid">
                                                            {{isset($item->task_id) ? $item->task_id : '-'}}
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading" id="task_title">
                                                            {{isset($item->task_name) ? $item->task_name : '-'}}
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            @if(!empty($item->users))
                                                        @foreach ($item->users as $worker)
                                                        <span class="badge badge-inactive">{{isset($worker->f_name) ? $worker->f_name : ''}}</span>
                                                        @endforeach
                                                        @endif
                                                            
                                                        </p>
                                                    </td>
                                                    @php
                                                    $timestamp = (strtotime($item->start_datetime));
                                                    $date = date('j.n.Y', $timestamp);
                                                    $time = date('H:i:s', $timestamp);
                                                    @endphp
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading" id="strt_date">
                                                            {{$date}}
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading" id="strt_time">
                                                            {{$time}}
                                                        </p>
                                                    </td>
                                                    @php
                                                    $timestamp = (strtotime($item->end_datetime));
                                                    $date = date('j.n.Y', $timestamp);
                                                    $time = date('H:i:s', $timestamp);
                                                    @endphp
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading" id="end_date">
                                                            {{$date}}
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading" id="end_time">
                                                            {{$time}}
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <select name="status"  class="js-select2 tosetitas status-select-{{ $k }}" disabled class="js-select2 tosetitas" onchange="checkTertiary(event)">
                                                                <option value="Select Option" disabled>Select Option</option>
                                                                <option value="Approved" {{ isset($item->status) && $item->status == 'Approved' ? 'selected' : '' }}>Approved</option>
                                                                <option value="Submitted" {{ isset($item->status) && $item->status == 'Submitted' ? 'selected' : '' }}>Submitted</option>
                                                                <option value="Active" {{ isset($item->status) && $item->status == 'Active' ? 'selected' : '' }}>Active</option>
                                                                <option value="Expired" {{ isset($item->status) && $item->status == 'Expired' ? 'selected' : '' }}>Expired</option>
                                                        </select>
                                                    </td>
                                                    <td>
                                                        <div class="tableButtonSetting">
                                                            <div class="btn-group dropstart">
                                                                <a href="#" class="dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false" >
                                                                    <img src="{{asset('public/assets/icons/DotsThreeOutline.svg')}}" alt="">
                                                                </a>
                                                                <ul class="dropdown-menu tosetWidh-Dropdown">
                                                                    <li><a class="dropdown-item  togivepaddingLeft" href="{{route('worker.taskView' , ['id' => $item->id])}}">View</a></li>
                                                                    
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                                @endforeach
                                            </tbody>

                                        </table>

                                    </div>
                                </div>
                                <div class="tab-pane fade" id="nav-contact3" role="tabpanel"
                                    aria-labelledby="nav-contact3-tab">
                                    <div class="mb-3">
                                        <div
                                            class="align-items-center d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column justify-content-between toSetFilterIcon">
                                            <h4 class="file-Heading">
                                                Task Expired
                                            </h4>
                                            <div
                                                class="mt-xxl-0 mt-xl-0 mt-lg-0 mt-md-0 mt-sm-3 mt-3 d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column gap-2">
                                                <button
                                                    class="FilterButtonSetting btn btn-secondary d-flex gap-2 align-items-center">
                                                    Sort by
                                                    <svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path
                                                            d="M3.375 13.4995H7.3125M10.125 11.812L12.9375 14.6245M12.9375 14.6245L15.7499 11.8125M12.9375 14.6245L12.9375 7.87451M3.375 8.99951H8.43743M3.375 4.49951H12.9374"
                                                            stroke-width="1.5" stroke-linecap="round"
                                                            stroke-linejoin="round" />
                                                    </svg>
                                                </button>

                                            </div>
                                        </div>
                                    </div>
                                    <div class="table-responsive">
                                        <table id="" class="dataTable table-responsive stripe w-100 ">
                                            <thead>
                                                <tr>
                                                    <th>
                                                     S.No
                                                    </th>
                                                    <th>Date Created</th>
                                                    <th class="text-start">Task Id</th>
                                                    <th>Task Tittle</th>
                                                    <th>Assigned To</th>
                                                    <th>Start on</th>
                                                    <th>End on</th>
                                                    <th>Status</th>
                                                    <th></th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                @foreach ($expired_tasks as $k=>$item)
                                                <tr>
                                                    <td>
                                                    <p class="table-MainHeading" >
                                                    {{$k+1}}
                                                    </p>
                                                    </td>
                                                    <td>
                                                        @php
                                                        $timestamp = (strtotime($item->created_at));
                                                        $date = date('j.n.Y', $timestamp);
                                                        $time = date('H:i:s', $timestamp);
                                                        @endphp
                                                        <p class="p-0 m-0 table-MainHeading" id="creted_date">
                                                            {{$date}}
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading" id="created_time">
                                                            {{$time}}
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading" id="taskid">
                                                            {{isset($item->task_id) ? $item->task_id : '-'}}
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading" id="task_title">
                                                            {{isset($item->task_name) ? $item->task_name : '-'}}
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            @if(!empty($item->users))
                                                        @foreach ($item->users as $worker)
                                                        <span class="badge badge-inactive">{{isset($worker->f_name) ? $worker->f_name : ''}}</span>
                                                        @endforeach
                                                        @endif
                                                            
                                                        </p>
                                                    </td>
                                                    @php
                                                    $timestamp = (strtotime($item->start_datetime));
                                                    $date = date('j.n.Y', $timestamp);
                                                    $time = date('H:i:s', $timestamp);
                                                    @endphp
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading" id="strt_date">
                                                            {{$date}}
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading" id="strt_time">
                                                            {{$time}}
                                                        </p>
                                                    </td>
                                                    @php
                                                    $timestamp = (strtotime($item->end_datetime));
                                                    $date = date('j.n.Y', $timestamp);
                                                    $time = date('H:i:s', $timestamp);
                                                    @endphp
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading" id="end_date">
                                                            {{$date}}
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading" id="end_time">
                                                            {{$time}}
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <select name="status" id="status-{{ $k }}" class="js-select2 tosetitas status-select-{{ $k }}" disabled class="js-select2 tosetitas" onchange="checkTertiary(event)">
                                                                <option value="Select Option" disabled>Select Option</option>
                                                                <option value="Approved" {{ isset($item->status) && $item->status == 'Approved' ? 'selected' : '' }}>Approved</option>
                                                                <option value="Submitted" {{ isset($item->status) && $item->status == 'Submitted' ? 'selected' : '' }}>Submitted</option>
                                                                <option value="Active" {{ isset($item->status) && $item->status == 'Active' ? 'selected' : '' }}>Active</option>
                                                                <option value="Expired" {{ isset($item->status) && $item->status == 'Expired' ? 'selected' : '' }}>Expired</option>
                                                        </select>
                                                    </td>
                                                    <td>
                                                        <div class="tableButtonSetting">
                                                            <div class="btn-group dropstart">
                                                                <a href="#" class="dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false" >
                                                                    <img src="{{asset('public/assets/icons/DotsThreeOutline.svg')}}" alt="">
                                                                </a>
                                                                <ul class="dropdown-menu tosetWidh-Dropdown">
                                                                    <li><a class="dropdown-item  togivepaddingLeft" href="{{route('worker.taskView' , ['id' => $item->id])}}">View</a></li>
                                                                    
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                                @endforeach
                                            </tbody>

                                        </table>

                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@include('worker.footer')
<script src="{{ asset('public/assets/js/select2.min.js') }}"></script>


<script>
    $(document).ready(function() {
        $('select.js-select2').each(function() {
            $(this).select2({
                selectOnClose: true
            });
        });
    });

    setInterval(() => {
        get_tasks();
    }, 2000);

function get_tasks(){
    $.ajax({
        url  : "{{route('worker.get_tasks')}}",
        type : "POST",
        data:{
            _token:'{{ csrf_token() }}',
        },
        success : function(res){
            console.log(res.active_tasks_count);
            if(res.data) {
                $('#appendAllTaks').html(res.data);
                $('#appndActive').html(res.active_tasks_count);
                $('#appndExpire').html(res.expired_tasks_count);
                setTimeout(() => {
                    $('select.js-select2').each(function() {
                        $(this).select2({
                            selectOnClose: true
                        });
                    });
                    applyColor();
                }, 2000);
            }

        }
    })
}
get_tasks();
</script>
