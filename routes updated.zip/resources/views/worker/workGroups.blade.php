<?php
$activebar = "groups";
?>
@include('worker.header')
    <div class="iq-top-navbar py-2 rtl-iq-top-navbar ">
        <div class="iq-navbar-custom">
            <nav class="navbar navbar-expand-lg navbar-light p-0 toSetNavBarAll w-100">
                <div class="iq-navbar-logo d-flex align-items-center justify-content-between">
                    <i class="ri-menu-line wrapper-menu"></i>
                    <!-- Mobile Logo -->
                </div>
                <div class="iq-search-bar device-search">
                    <h4 class="main_content_title ps-3">Work Groups</h4>
                </div>
                @include('worker.tooltip')
                <!-- <div class="d-xxl-none d-xl-none d-lg-none d-md-block d-sm-block d-block">
                    <ul class="align-items-center d-flex gap-4 list-unstyled text-decoration-none m-0">
                        <li>
                            <button class="nav-AddNew-Button btn btn-primary" type="button" data-bs-toggle="modal" data-bs-target="#exampleModal">Create Task</button>
                        </li>
                    </ul>
                </div> -->
            </nav>
        </div>
    </div>



    <div class="content-page rtl-page">
        <div class="container-fluid mt-4">
            <div class="row UserPage">
                <div class="col-12">
                    <div class="row mt-4">
                        <div class="col-12 ">
                            <div class="bg-white p-3 index-TablePage">
                                <div class="mb-3">
                                    <div class="align-items-center d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column justify-content-between toSetFilterIcon">
                                        <div class="d-flex align-items-center gap-3">
                                            <h4 class="file-Heading">
                                                All Groups
                                            </h4>
                                           
                                        </div>
                                        <div class="TogiveFullWidth d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column gap-2 mt-xxl-0 mt-xl-0 mt-lg-0 mt-md-0 mt-sm-3 mt-3">
<!--                                            <select name="" class="js-select2" data-minimum-results-for-search="Infinity" >-->
<!--                                                <option value="All Task">All Task</option>-->
<!--                                                <option value="Staff Task">Staff Task</option>-->
<!--                                                <option value="My Task">My Task</option>-->
<!--                                            </select>-->
                                           <!-- <button  class="FilterButtonSetting btn btn-secondary d-flex gap-2 align-items-center" >
                                                Sort by <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M3.375 13.4995H7.3125M10.125 11.812L12.9375 14.6245M12.9375 14.6245L15.7499 11.8125M12.9375 14.6245L12.9375 7.87451M3.375 8.99951H8.43743M3.375 4.49951H12.9374"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                </svg>
                                            </button> -->

                                            <!--                                                 <input type="text" class="form-control">-->
                                            <!--                                            <form action="" class="p-0 m-0 position-relative">-->
                                            <!--                                                <img style="" class="GlobalInputIconSetting position-absolute" src="../assets/icons/MagnifyingGlass.svg" alt="">-->
                                            <!--                                                <input style="" type="text" class="form-control GlobalInputSetting" placeholder="s">-->
                                            <!--                                            </form>-->
                                        </div>
                                    </div>
                                </div>
                                <div class="table-responsive">
                                    <table id="" class="dataTable table-responsive stripe w-100 ">
                                        <thead>
                                        <tr>
                                           <th>  S.No </th>  
                                            <th class="text-start">Created On</th>
                                            <th class="text-start">Group Name</th>
                                            <th class="text-start">Address</th>
                                            <th class="text-start">Group Members</th>
                                            <th></th>
                                        </tr>
                                        </thead>
                                        <tbody>

                                        <tr>
                                            <td>
                                                <div class="custom-Radio-Button">
                                                    <label class="custom-radio m-0" for="tablec1">
                                                        <input type="checkbox" class="customme" name="customRadio" id="tablec1">
                                                        <span class="radio-btn"></span>

                                                    </label>
                                                </div>
                                            </td>
                                            <td>
                                                <p class="p-0 m-0 table-MainHeading mb-1">
                                                    Jan 19, 2022
                                                </p>
                                                <p class="p-0 m-0 table-SubHeading">
                                                    03:45 pm
                                                </p>
                                            </td>
                                            <td>
                                                <p class="p-0 m-0 table-MainHeading mb-1">
                                                    Cameron Williamson
                                                </p>
                                                <p class="p-0 m-0 table-SubHeading">
                                                    janecooper@rts.com
                                                </p>
                                            </td>
                                            <td>
                                                <p class="p-0 m-0 table-MainHeading">
                                                    1901 Thornridge Cir. Shiloh, Hawaii 81063
                                                </p>
                                            </td>
                                            <td colspan="2">
                                              <div class="d-flex">
                                                  <div>
                                                      <div class="tale-small-image timage-1">
                                                          <img src="../assets/images/avatar1.png" alt="">
                                                      </div>
                                                  </div>
                                                  <div class="position-relative">
                                                      <div class="tale-small-image timage-2 position-absolute">
                                                          <img src="../assets/images/avatar2.png" alt="">
                                                      </div>
                                                  </div>
                                                  <div class="position-relative">
                                                      <div class="tale-small-image timage-3 position-absolute">
                                                          <img src="../assets/images/avatar3.png" alt="">
                                                      </div>
                                                  </div>
                                                  <div class="position-relative">
                                                      <div class="tale-small-image timage-4 position-absolute">
                                                          <img src="../assets/images/avatar4.png" alt="">
                                                      </div>
                                                  </div>
                                                  <div class="position-relative">
                                                      <div class="tale-small-image timage-5 position-absolute">
                                                          <img src="../assets/images/avatar1.png" alt="">
                                                      </div>
                                                  </div>
                                                  <div class="position-relative">
                                                      <div class="tale-small-image timage-6 position-absolute">
                                                          <img src="../assets/images/avatar1.png" alt="">
                                                      </div>
                                                  </div>
                                                  <div class="position-relative">
                                                      <div class="tale-small-image timage-7 position-absolute d-flex align-items-center justify-content-center">
                                                          <svg width="15" height="16" viewBox="0 0 15 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                              <path d="M2.47485 13.4994C3.02234 12.4354 3.80957 11.5519 4.75746 10.9376C5.70535 10.3234 6.78051 9.99999 7.87494 10C8.96937 10 10.0445 10.3234 10.9924 10.9377C11.9403 11.552 12.7275 12.4355 13.275 13.4995" stroke="#8897AE" stroke-linecap="round" stroke-linejoin="round"/>
                                                              <path d="M7.875 10C9.84251 10 11.4375 8.20914 11.4375 6C11.4375 3.79086 9.84251 2 7.875 2C5.90749 2 4.3125 3.79086 4.3125 6C4.3125 8.20914 5.90749 10 7.875 10Z" stroke="#8897AE" stroke-miterlimit="10"/>
                                                          </svg>
                                                      </div>
                                                  </div>
                                                  <div class="position-relative">
                                                      <div class="tale-small-image timage-8 position-absolute d-flex align-items-center justify-content-center">
                                                          <svg width="15" height="16" viewBox="0 0 15 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                              <path d="M2.47485 13.4994C3.02234 12.4354 3.80957 11.5519 4.75746 10.9376C5.70535 10.3234 6.78051 9.99999 7.87494 10C8.96937 10 10.0445 10.3234 10.9924 10.9377C11.9403 11.552 12.7275 12.4355 13.275 13.4995" stroke="#8897AE" stroke-linecap="round" stroke-linejoin="round"/>
                                                              <path d="M7.875 10C9.84251 10 11.4375 8.20914 11.4375 6C11.4375 3.79086 9.84251 2 7.875 2C5.90749 2 4.3125 3.79086 4.3125 6C4.3125 8.20914 5.90749 10 7.875 10Z" stroke="#8897AE" stroke-miterlimit="10"/>
                                                          </svg>
                                                      </div>
                                                  </div>
                                                  <div class="position-relative">
                                                      <div class="tale-small-image timage-9 position-absolute d-flex align-items-center justify-content-center">
                                                         <span>99+</span>
                                                      </div>
                                                  </div>
                                              </div>
                                            </td>
                                            <td>
                                                <div class="tableButtonSetting">
                                                    <div class="btn-group dropstart">
                                                        <a href="#" class="dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false" >
                                                            <img src="../assets/icons/DotsThreeOutline.svg" alt="">
                                                        </a>
                                                        <ul class="dropdown-menu tosetWidh-Dropdown">
                                                            <li><a class="dropdown-item  togivepaddingLeft" href="group-view.php">View</a></li>
                                                            <li><a class="dropdown-item  togivepaddingLeft" href="#" data-bs-toggle="modal" data-bs-target="#DeleteModal" type="button">Delete</a></li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                <div class="custom-Radio-Button">
                                                    <label class="custom-radio m-0" for="tablec2">
                                                        <input type="checkbox" class="customme" name="customRadio" id="tablec2">
                                                        <span class="radio-btn"></span>

                                                    </label>
                                                </div>
                                            </td>
                                            <td>
                                                <p class="p-0 m-0 table-MainHeading mb-1">
                                                    Jan 19, 2022
                                                </p>
                                                <p class="p-0 m-0 table-SubHeading">
                                                    03:45 pm
                                                </p>
                                            </td>
                                            <td>
                                                <p class="p-0 m-0 table-MainHeading mb-1">
                                                    Cameron Williamson
                                                </p>
                                                <p class="p-0 m-0 table-SubHeading">
                                                    janecooper@rts.com
                                                </p>
                                            </td>
                                            <td>
                                                <p class="p-0 m-0 table-MainHeading">
                                                    1901 Thornridge Cir. Shiloh, Hawaii 81063
                                                </p>
                                            </td>
                                            <td colspan="2">
                                                <div class="d-flex">
                                                    <div>
                                                        <div class="tale-small-image timage-1">
                                                            <img src="../assets/images/avatar1.png" alt="">
                                                        </div>
                                                    </div>
                                                    <div class="position-relative">
                                                        <div class="tale-small-image timage-2 position-absolute">
                                                            <img src="../assets/images/avatar1.png" alt="">
                                                        </div>
                                                    </div>
                                                    <div class="position-relative">
                                                        <div class="tale-small-image timage-3 position-absolute">
                                                            <img src="../assets/images/avatar1.png" alt="">
                                                        </div>
                                                    </div>
                                                    <div class="position-relative">
                                                        <div class="tale-small-image timage-4 position-absolute">
                                                            <img src="../assets/images/avatar1.png" alt="">
                                                        </div>
                                                    </div>
                                                    <div class="position-relative">
                                                        <div class="tale-small-image timage-5 position-absolute">
                                                            <img src="../assets/images/avatar1.png" alt="">
                                                        </div>
                                                    </div>
                                                    <div class="position-relative">
                                                        <div class="tale-small-image timage-6 position-absolute">
                                                            <img src="../assets/images/avatar1.png" alt="">
                                                        </div>
                                                    </div>
                                                    <div class="position-relative">
                                                        <div class="tale-small-image timage-7 position-absolute d-flex align-items-center justify-content-center">
                                                            <svg width="15" height="16" viewBox="0 0 15 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <path d="M2.47485 13.4994C3.02234 12.4354 3.80957 11.5519 4.75746 10.9376C5.70535 10.3234 6.78051 9.99999 7.87494 10C8.96937 10 10.0445 10.3234 10.9924 10.9377C11.9403 11.552 12.7275 12.4355 13.275 13.4995" stroke="#8897AE" stroke-linecap="round" stroke-linejoin="round"/>
                                                                <path d="M7.875 10C9.84251 10 11.4375 8.20914 11.4375 6C11.4375 3.79086 9.84251 2 7.875 2C5.90749 2 4.3125 3.79086 4.3125 6C4.3125 8.20914 5.90749 10 7.875 10Z" stroke="#8897AE" stroke-miterlimit="10"/>
                                                            </svg>
                                                        </div>
                                                    </div>
                                                    <div class="position-relative">
                                                        <div class="tale-small-image timage-8 position-absolute d-flex align-items-center justify-content-center">
                                                            <svg width="15" height="16" viewBox="0 0 15 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                                <path d="M2.47485 13.4994C3.02234 12.4354 3.80957 11.5519 4.75746 10.9376C5.70535 10.3234 6.78051 9.99999 7.87494 10C8.96937 10 10.0445 10.3234 10.9924 10.9377C11.9403 11.552 12.7275 12.4355 13.275 13.4995" stroke="#8897AE" stroke-linecap="round" stroke-linejoin="round"/>
                                                                <path d="M7.875 10C9.84251 10 11.4375 8.20914 11.4375 6C11.4375 3.79086 9.84251 2 7.875 2C5.90749 2 4.3125 3.79086 4.3125 6C4.3125 8.20914 5.90749 10 7.875 10Z" stroke="#8897AE" stroke-miterlimit="10"/>
                                                            </svg>
                                                        </div>
                                                    </div>
                                                    <div class="position-relative">
                                                        <div class="tale-small-image timage-9 position-absolute d-flex align-items-center justify-content-center">
                                                            <span>99+</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </td>
                                            <td>
                                                <div class="tableButtonSetting">
                                                    <div class="btn-group dropstart">
                                                        <a href="#" class="dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false" >
                                                            <img src="../assets/icons/DotsThreeOutline.svg" alt="">
                                                        </a>
                                                        <ul class="dropdown-menu tosetWidh-Dropdown">
                                                            <li><a class="dropdown-item  togivepaddingLeft" href="group-view.php">View</a></li>
                                                            <li><a class="dropdown-item  togivepaddingLeft" href="#" data-bs-toggle="modal" data-bs-target="#DeleteModal" type="button">Delete</a></li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                        </tbody>

                                    </table>

                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

@include('worker.footer')