<?php
$activebar = 'tasks';
?>
<style>
    #workers img{
        width:90px;
    }
    #workers{
        display: flex;
    align-items: center;
    gap: 27px;
    }
    #workers li{
        list-style:none;
    }
</style>

@include('superadmin.header')
<div class="iq-top-navbar py-2 rtl-iq-top-navbar ">
    <div class="iq-navbar-custom">
        <nav class="navbar navbar-expand-lg navbar-light p-0 toSetNavBarAll w-100">
            <div class="iq-navbar-logo d-flex align-items-center justify-content-between">
                <i class="ri-menu-line wrapper-menu"></i>
                <!-- Mobile Logo -->
            </div>
            <div class="iq-search-bar device-search">
                <h4 class="main_content_title ps-3">Task Management</h4>
            </div>
            @include('superadmin.tooltip')
            <div class="d-xxl-none d-xl-none d-lg-none d-md-block d-sm-block d-block">
                <ul class="align-items-center d-flex gap-4 list-unstyled text-decoration-none m-0">
                    <li>
                    <button class="nav-AddNew-Button btn btn-primary" type="button" data-bs-toggle="modal" data-bs-target="#create_task_modal">Create Task</button>
                    </li>
                </ul>
            </div>
        </nav>
    </div>
</div>


<div class="content-page rtl-page">
    <div class="container-fluid mt-4">
        <div class="row UserPage">
            <div class="col-12">
                <div class="PageViewTable px-3 py-4">
                    <div class="row mt-4">
                        <div
                            class="order-xxl-1 order-xl-1 order-lg-1 order-md-2 order-sm-2 order-2 col-xxl-8 col-xl-8 col-lg-8 col-md-12 col-sm-12 col-12 mt-xxl-0 mt-xl-0 mt-lg-0 mt-md-4 mt-sm-4 mt-4">
                            <div class="">
                                <div class="row TaskViewtogIveBorder">
                                    <div class="col-12">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div>
                                                <h4 class="fileViewTitle mb-1">Task ID:
                                                    {{ isset($Task[0]->task_id) ? $Task[0]->task_id : '-' }} </h4>
                                            </div>
                                            <div>
                                                <button type="button" onclick="Edit_task('{{ $Task[0]->id }}')"
                                                    class="btn btn-secondary fileViewTitlebtn">
                                                    <!-- <svg width="4"
                                                        height="12" viewBox="0 0 4 12" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path
                                                            d="M2 11.3438C2.46599 11.3438 2.84375 10.966 2.84375 10.5C2.84375 10.034 2.46599 9.65625 2 9.65625C1.53401 9.65625 1.15625 10.034 1.15625 10.5C1.15625 10.966 1.53401 11.3438 2 11.3438Z"
                                                            fill="black" />
                                                        <path
                                                            d="M2 6.84375C2.46599 6.84375 2.84375 6.46599 2.84375 6C2.84375 5.53401 2.46599 5.15625 2 5.15625C1.53401 5.15625 1.15625 5.53401 1.15625 6C1.15625 6.46599 1.53401 6.84375 2 6.84375Z"
                                                            fill="black" />
                                                        <path
                                                            d="M2 2.34375C2.46599 2.34375 2.84375 1.96599 2.84375 1.5C2.84375 1.03401 2.46599 0.65625 2 0.65625C1.53401 0.65625 1.15625 1.03401 1.15625 1.5C1.15625 1.96599 1.53401 2.34375 2 2.34375Z"
                                                            fill="black" />
                                                        <path
                                                            d="M2 11.3438C2.46599 11.3438 2.84375 10.966 2.84375 10.5C2.84375 10.034 2.46599 9.65625 2 9.65625C1.53401 9.65625 1.15625 10.034 1.15625 10.5C1.15625 10.966 1.53401 11.3438 2 11.3438Z" />
                                                        <path
                                                            d="M2 6.84375C2.46599 6.84375 2.84375 6.46599 2.84375 6C2.84375 5.53401 2.46599 5.15625 2 5.15625C1.53401 5.15625 1.15625 5.53401 1.15625 6C1.15625 6.46599 1.53401 6.84375 2 6.84375Z" />
                                                        <path
                                                            d="M2 2.34375C2.46599 2.34375 2.84375 1.96599 2.84375 1.5C2.84375 1.03401 2.46599 0.65625 2 0.65625C1.53401 0.65625 1.15625 1.03401 1.15625 1.5C1.15625 1.96599 1.53401 2.34375 2 2.34375Z" />
                                                    </svg> -->
                                                    <svg width="15px" height="15px" viewBox="0 0 24 24"
                                                        fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                                                        <g id="SVGRepo_tracerCarrier" stroke-linecap="round"
                                                            stroke-linejoin="round"></g>
                                                        <g id="SVGRepo_iconCarrier">
                                                            <path fill-rule="evenodd" clip-rule="evenodd"
                                                                d="m3.99 16.854-1.314 3.504a.75.75 0 0 0 .966.965l3.503-1.314a3 3 0 0 0 1.068-.687L18.36 9.175s-.354-1.061-1.414-2.122c-1.06-1.06-2.122-1.414-2.122-1.414L4.677 15.786a3 3 0 0 0-.687 1.068zm12.249-12.63 1.383-1.383c.248-.248.579-.406.925-.348.487.08 1.232.322 1.934 1.025.703.703.945 1.447 1.025 1.934.058.346-.1.677-.348.925L19.774 7.76s-.353-1.06-1.414-2.12c-1.06-1.062-2.121-1.415-2.121-1.415z"
                                                                fill="#000000"></path>
                                                        </g>
                                                    </svg>

                                                </button>

                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-xxl-8 col-xl-8 col-lg-8 col-md-6 col-sm-12 col-12 mt-4">
                                        <div
                                            class="TaskView-Left d-flex align-items-start justify-content-between flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-row flex-column">
                                            <div>
                                                <div>
                                                    <h4 class="Task-sub-Title">Account</h4>
                                                    <p class="Task-sub-text">
                                                        {{ isset($Task[0]->account) ? $Task[0]->account : '-' }}</p>
                                                </div>
                                                <div>
                                                    <h4 class="Task-sub-Title">Task Title</h4>
                                                    <p class="Task-sub-text">
                                                        {{ isset($Task[0]->task_name) ? $Task[0]->task_name : '-' }}</p>
                                                </div>
                                                <div>
                                                    <h4 class="Task-sub-Title">Company</h4>
                                                    <p class="Task-sub-text">
                                                        {{ isset($Task[0]->company) ? $Task[0]->company : '-' }}</p>
                                                </div>
                                            </div>
                                            <div>
                                                <div>
                                                    <h4 class="Task-sub-Title">Department</h4>
                                                    <p class="Task-sub-text">
                                                        {{ isset($Task[0]->department) ? $Task[0]->department : '-' }}
                                                    </p>
                                                </div>
                                                <div>
                                                    <h4 class="Task-sub-Title">Vehicle Category</h4>
                                                    <p class="Task-sub-text">
                                                        {{ isset($Task[0]->vehicle_category) ? $Task[0]->vehicle_category : '-' }}
                                                    </p>
                                                </div>
                                            </div>
                                            <div>
                                                <div>
                                                    <h4 class="Task-sub-Title">T-Level</h4>
                                                    <p class="Task-sub-text">
                                                        {{ isset($Task[0]->t_level) ? $Task[0]->t_level : '-' }}</p>
                                                </div>
                                                <div>
                                                    <h4 class="Task-sub-Title">Assigned Workers</h4>
                                                    <a href="#" onclick="show_members('{{$Task[0]->id}}')">
                                                        <p class="Task-sub-text textcolor">
                                                            @php

                                                                $total_members = json_decode($Task[0]->workers);
                                                                if (!empty($total_members)) {
                                                                    echo count($total_members);
                                                                } else {
                                                                    echo 'no members to show';
                                                                }
                                                            @endphp
                                                        </p>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                      {{-- members in task modal start --}}

                                      <div class="modal fade" id="assignedWorkersModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog">

                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="exampleModalLabel">Assigned Workers</h5>
                                                       <button style="border:none !important;" type="button" class="btn-secondary " data-bs-dismiss="modal" aria-label="Close"> <i class="fa-regular fa-x"></i> </button>
                                                    </div>
                                                    <div class="modal-body">
                                                     <div>
                                                     <ul id="workers">

</ul>
                                                     </div>
                                                    </div>

                                                </div>
                                        </div>
                                        </div>
                                    {{-- members in task modal end --}}

                                    <script>
                                        function show_members(id){
                                            console.log(id);
                                            $.ajax({
                                                url : "{{route('admin.assignedWorkers')}}",
                                                type : "POST",
                                                data : {
                                                    task_id : id,
                                                    _token : "{{csrf_token()}}"
                                                },
                                                success : function(res){
                                                    console.log(res);
                                                    $('#workers').html(' ');
                                                    res.workers.forEach(element => {
                                                        console.log(element.f_name);
                                                        $('#workers').append(`<div class="MainAddeddiv">
                                                            <div class="imagwithName">
                                                            <img src="{{ url('storage/app/uploads') }}/${element.image}"/>
                                                            <li>${element.f_name} ${element.l_name}</li>
                                                            <small>${element.role}</small>
                                                            </div>
                                                            <a class="btn btn-primary" href="{{url('superadmin/EditEmployee')}}/${element.id}">view</a>
                                                            </div>`);
                                                    });
                                                    res.managers.forEach(element => {
                                                        console.log(element.f_name);
                                                        $('#workers').append(`<div class="MainAddeddiv">
                                                            <div class="imagwithName"> <img src="{{ url('storage/app/uploads') }}/${element.image}"/>
                                                                <li>${element.f_name} ${element.l_name}</li>
                                                                <small>${element.role}</small>
                                                                </div>
                                                                <a class="btn btn-primary" href="{{ url('superadmin/EditEmployee') }}/${element.id}">view</a>
                                                            </div>`);
                                                        $('#assignedWorkersModal').modal('show');
                                                    });

                                                }
                                            })
                                        }
                                    </script>



                                    <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12 mt-4">
                                        <div
                                            class="d-flex align-items-end justify-content-xxl-end justify-content-xl-end justify-content-lg-end justify-content-md-start justify-content-sm-start justify-content-start h-100">
                                            <select name="status" id="status" onchange="changeStatus(event)"
                                                class="js-select2 change_status_task_view">
                                                <option value="Created"
                                                    {{ $Task[0]->status == 'Created' ? 'selected' : '' }}>Created
                                                </option>
                                                <option value="Submitted"
                                                    {{ $Task[0]->status == 'Submitted' ? 'selected' : '' }}>Submitted
                                                </option>
                                                <option value="Approved"
                                                    {{ $Task[0]->status == 'Approved' ? 'selected' : '' }}>Approved
                                                </option>
                                                <option value="Rejected"
                                                    {{ $Task[0]->status == 'Rejected' ? 'selected' : '' }}>Rejected
                                                </option>
                                                <option value="Active"
                                                    {{ $Task[0]->status == 'Active' ? 'selected' : '' }}>Active
                                                </option>
                                                <option value="Completed"
                                                    {{ $Task[0]->status == 'Completed' ? 'selected' : '' }}>Completed
                                                </option>
                                                <option value="Expired"
                                                    {{ $Task[0]->status == 'Expired' ? 'selected' : '' }}>Expired
                                                </option>
                                            </select>
                                        </div>
                                    </div>
                                    <script>
                                        function changeStatus(e) {
                                            console.log(e.target.value)
                                            let status = e.target.value
                                            let _token = '{{ csrf_token() }}';
                                            let task_id = '{{ $Task[0]->id }}';
                                            $.post('{{ route('admin.changeTaskStatus') }}', {
                                                _token,
                                                status,
                                                task_id
                                            }, function(resp) {
                                                console.log(resp)
                                            })
                                        }
                                    </script>
                                    <div class="col-12 mt-4 Document-Section">
                                        <div
                                            class="d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column align-items-xxl-center align-items-xl-center align-items-lg-center align-items-md-center align-items-sm-start align-items-start justify-content-between">
                                            <h2 class="p-0 m-0 document-heading">
                                                Documents
                                            </h2>
                                            <div
                                                class="d-flex gap-2 align-items-center mt-xxl-0 mt-xl-0 mt-lg-0 mt-md-0 mt-sm-3 mt-3">
                                                <button type="button" data-bs-toggle="modal" data-bs-target="#document"
                                                    class="btn btn-secondary">Upload Document</button>
                                                {{--  --}}
                                            </div>
                                        </div>

                                        {{-- upload document modal start --}}
                                        <div class="modal fade" id="document" tabindex="-1"
                                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog modal-lg">
                                                <form action="{{ route('admin.update_docments_task') }}" method="POST"
                                                    enctype="multipart/form-data">
                                                    @csrf
                                                    <div class="modal-content">
                                                        <div class="modal-header extendModal">
                                                            <h1 class="modal-title fs-5" id="exampleModalLabel">
                                                                Documents</h1>
                                                            <button type="button" class="btn-close"
                                                                data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body DocumentModal">
                                                            <div class="row">
                                                                <div class="col-12 mt-3">
                                                                    <div class="input-images-1m"
                                                                        style="padding-top: .5rem;"></div>
                                                                </div>
                                                                <div class="col-12 mt-3">
                                                                    <input type="hidden" value="{{ $Task[0]->id }}"
                                                                        name="task_id">
                                                                </div>

                                                            </div>

                                                        </div>
                                                        <div class="modal-footer">
                                                            <!--                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>-->
                                                            <button type="submit"
                                                                class="btn btn-secondary">Save</button>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                        {{-- upload document modal end --}}




                                        <div class="row">

                                            @if ($allFiles != null)
                                                @foreach ($allFiles['files'] as $file)
                                                    <div class="col-6 mt-3">
                                                        <div
                                                            class="DownloadIconSetting d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column align-items-xxl-center align-items-xl-center align-items-lg-center align-items-md-center align-items-sm-start align-items-start justify-content-between">
                                                            <div
                                                                class="d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column gap-3">
                                                                <div>
                                                                    @if(str_contains($file, '.docx'))
                                                                    <img style="height: 40px; width: 40px" src="{{url('storage/app/uploads/word.png')}}" width="50">
                                                                    @elseif(str_contains($file, '.pdf'))
                                                                    <img style="height: 40px; width: 40px" src="{{url('storage/app/uploads/pdf.png')}}" width="50">
                                                                    @elseif(str_contains($file, '.csv'))
                                                                    <img style="height: 40px; width: 40px" src="{{url('storage/app/uploads/excel.png')}}" width="50">
                                                                    @else
                                                                    <img style="height: 50px"
                                                                    src="{{ url('storage/app/uploads/' . $file) }}"
                                                                    alt="">
                                                                    @endif
                                                                </div>
                                                                <div>
                                                                    <p class="m-0 p-0 FileNameHeading">
                                                                        {{ $file }}
                                                                    </p>
                                                                    <small class="m-0 p-0">7 KB</small>
                                                                </div>
                                                            </div>
                                                            <div>
                                                                <a href="{{ asset('storage/app/uploads/' . $file) }}"
                                                                    download>
                                                                    <img src="{{ asset('public/assets/icons/DownloadSimple.svg') }}"
                                                                        alt="">
                                                                </a>
                                                                <a href="javascript:void(0)"
                                                                    onclick="Delete_doc('{{ $allFiles['id'] }}', '{{ $file }}')">
                                                                    <img src="{{ asset('public/assets/icons/trash.svg') }}"
                                                                        alt="">
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                @endforeach
                                            @else
                                                <div>
                                                    <p class="m-0 p-0 FileNameHeading">
                                                        No files to show
                                                    </p>
                                                    <small class="m-0 p-0">7 KB</small>
                                                </div>
                                            @endif



                                        </div>
                                    </div>
                                    <div class="col-12 my-2">
                                        <hr class="">
                                    </div>
                                    <div class="col-12 groupChat-Section">
                                        <div class="d-flex justify-content-between align-items-end">
                                            <div>
                                                <h3 class="groupchat-Heading">Group Chat</h3>
                                                {{-- <span class="d-flex align-items-center gap-2 online-sub"><img
                                                        src="{{ url('public/assets/icons/online.svg') }}"
                                                        alt="">{{ isset($count_online) ? $count_online : '' }}
                                                    Online</span> --}}
                                            </div>
                                            <div class="w-50">
                                                <div class="d-flex justify-content-end">
                                                    @if (!empty($Task))
                                                        @foreach ($Task as $item)
                                                            @if (!empty($item))
                                                                @foreach ($item->members as $users)
                                                                    @if ($loop->iteration == 4)
                                                                    @break
                                                                @endif
                                                                <div>
                                                                    <div class="tale-small-image">
                                                                        @if (!empty($users->image))
                                                                            <img src="{{ url('storage/app/uploads/' . $users->image) }}"
                                                                                alt="">
                                                                        @else
                                                                            <img src="{{ url('storage/app/uploads/placeholder.jpg') }}"
                                                                                alt="">
                                                                        @endif
                                                                    </div>
                                                                </div>
                                                            @endforeach
                                                        @endif
                                                    @endforeach
                                                @endif



                                                {{-- <div class="position-relative">
                                                    <div
                                                        class="tale-small-image task-img-6 position-absolute d-flex align-items-center justify-content-center">
                                                        <svg width="15" height="16" viewBox="0 0 15 16"
                                                            fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path
                                                                d="M2.47485 13.4994C3.02234 12.4354 3.80957 11.5519 4.75746 10.9376C5.70535 10.3234 6.78051 9.99999 7.87494 10C8.96937 10 10.0445 10.3234 10.9924 10.9377C11.9403 11.552 12.7275 12.4355 13.275 13.4995"
                                                                stroke="#8897AE" stroke-linecap="round"
                                                                stroke-linejoin="round" />
                                                            <path
                                                                d="M7.875 10C9.84251 10 11.4375 8.20914 11.4375 6C11.4375 3.79086 9.84251 2 7.875 2C5.90749 2 4.3125 3.79086 4.3125 6C4.3125 8.20914 5.90749 10 7.875 10Z"
                                                                stroke="#8897AE" stroke-miterlimit="10" />
                                                        </svg>
                                                    </div>
                                                </div>
                                                <div class="position-relative">
                                                    <div
                                                        class="tale-small-image task-img-7 position-absolute d-flex align-items-center justify-content-center">
                                                        <svg width="15" height="16" viewBox="0 0 15 16"
                                                            fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path
                                                                d="M2.47485 13.4994C3.02234 12.4354 3.80957 11.5519 4.75746 10.9376C5.70535 10.3234 6.78051 9.99999 7.87494 10C8.96937 10 10.0445 10.3234 10.9924 10.9377C11.9403 11.552 12.7275 12.4355 13.275 13.4995"
                                                                stroke="#8897AE" stroke-linecap="round"
                                                                stroke-linejoin="round" />
                                                            <path
                                                                d="M7.875 10C9.84251 10 11.4375 8.20914 11.4375 6C11.4375 3.79086 9.84251 2 7.875 2C5.90749 2 4.3125 3.79086 4.3125 6C4.3125 8.20914 5.90749 10 7.875 10Z"
                                                                stroke="#8897AE" stroke-miterlimit="10" />
                                                        </svg>
                                                    </div>
                                                </div> --}}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 my-2">
                                    <hr>
                                </div>
                                <div class="col-12 apndChats">

                                </div>
                                <div class="col-12 mt-3 d-flex align-items-center justify-content-between gap-3">


                                   <div class="w-100" >
                                   <input style="" id="sender_typed_msg" onkeyup="sendMessage(event)"
                                        type="text" class="form-control GlobalInputSetting w-100"
                                        placeholder="Type a message">
                                   </div>
                                        <div class="">
                                            <button class="btn-primary " onclick="sendMessage()"> Send  </button>
                                            </div>

                                    <input type="hidden" name="" id="recgroupId"
                                        value="{{ $Task[0]->id }}">

                                </div>
                            </div>

                        </div>
                    </div>
                    <div
                        class="order-xxl-2 order-xl-2 order-lg-2 order-md-1 order-sm-1 order-1 col-xxl-4 col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12">
                        <div class="taskView-Right">
                            <div class="row">
                                <div class="col-12">
                                    <h4 class="taskView-Heading">Time Tracking</h4>
                                </div>
                                @php
                                    $start = strtotime($Task[0]->start_datetime);
                                    $strt_date = date('Y.j.n', $start);
                                    $strt_time = date('H:i:s', $start);
                                    $endtime = strtotime($Task[0]->end_datetime);
                                    $end_date = date('Y.j.n', $endtime);
                                    $end_time = date('H:i:s', $endtime);
                                @endphp
                                <div class="col-12 mt-3">
                                    <h3 class="text-center Clock-Time" id="timerDisplay">00:00:00</h3>
                                    <span class="clock-Expire text-center d-block">Expires on
                                        {{ $end_date }}</span>
                                </div>
                                <div class="col-12 mt-3">
                                    <div class="Time-Card">
                                        <div class="d-flex justify-content-between">
                                            <a type="button" data-bs-toggle="modal"
                                                onclick="extend_date('{{ $Task[0]->id }}')"
                                                class="card-Border w-50">
                                                <div
                                                    class="d-flex gap-xxl-3 gap-xl-3 gap-lg-3 gap-md-3 gap-sm-1 gap-2 align-items-center w-50 ">
                                                    <span
                                                        class="TimerIconSetting p-2 d-flex align-items-center justify-content-center">
                                                        <svg width="24" height="24" viewBox="0 0 24 24"
                                                            fill="none" xmlns="http://www.w3.org/2000/svg">
                                                            <path
                                                                d="M12 12L15.7123 8.28769M9.75 0.75H14.25M20.25 12C20.25 16.5563 16.5563 20.25 12 20.25C7.44365 20.25 3.75 16.5563 3.75 12C3.75 7.44365 7.44365 3.75 12 3.75C16.5563 3.75 20.25 7.44365 20.25 12Z"
                                                                stroke="white" stroke-width="1.5"
                                                                stroke-linecap="round" />
                                                        </svg>
                                                    </span>
                                                    <p class="p-0 m-0 clock-card-text">Extend</p>
                                                </div>
                                            </a>
                                            <div
                                                class="d-flex align-items-center gap-xxl-3 gap-xl-3 gap-lg-3 gap-md-3 gap-sm-1 gap-2">

                                                <p class="btn btn-primary text-white p-0 m-0 clock-card-text"
                                                    onclick="Task_complete('{{ $Task[0]->id }}')"
                                                    id="completeOption">Mark Complete</p>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 mt-3">
                                    <div class="p-3 CheckboxSection">
                                        {{-- <div class="d-flex justify-content-between">
                                                <h4 class="Checkbox-Heading">Tasks</h4>
                                                <div class="d-flex">
                                                    <div class="custom-Radio-Button">
                                                        <label class="custom-radio m-0" for="modalcheck">
                                                            <input type="checkbox" class="customme"
                                                                name="customRadio" id="modalcheck">
                                                            <span class="radio-btn"></span>

                                                        </label>
                                                    </div>
                                                    <span class="textbox-option">Select All</span>
                                                </div>
                                            </div> --}}
                                            @php
                                            $subTasks = json_decode($Task[0]->task_abbreviation);
                                            // print_r($subTasks);
                                        @endphp
                                        <div class="d-flex align-items-start mt-4 gap-5 flex-column">
                                            <h4 class="mb-4" >To do's</h4>
                                            <ul
                                                class="list-unstyled text-decoration-none d-flex flex-column gap-4 pe-4" id="check_all_tasks">
                                                @if (!empty($task_list))
                                                    @foreach ($task_list as $k => $item)
                                                    <li>
                                                        <div class="d-flex">
                                                            <span
                                                                class="textbox-option m-2">
                                                                @if (array_search($item->id,array_column($task_status,'tasklist_id')) !== false)
                                                                {{-- @if((!empty($task_status[$k]) and $item->id == $task_status[$k]['tasklist_id'] and $task_status[$k]['status'] === 'completed')) --}}
                                                                <svg width="20px" height="20px" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" stroke="#00ff2a"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <path d="M4 12.6111L8.92308 17.5L20 6.5" stroke="#05a32d" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path> </g></svg>
                                                                {{ $item->task_abbreviation }}
                                                                @else
                                                                <svg fill="#ff0000" width="12px" height="12px" viewBox="0 0 16 16" xmlns="http://www.w3.org/2000/svg" stroke="#ff0000" stroke-width="0.00016"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <path d="M0 14.545L1.455 16 8 9.455 14.545 16 16 14.545 9.455 8 16 1.455 14.545 0 8 6.545 1.455 0 0 1.455 6.545 8z" fill-rule="evenodd"></path> </g></svg>
                                                                {{ $item->task_abbreviation }}</span>
                                                                @endif
                                                        </div>
                                                    </li>
                                                    @endforeach
                                                @else
                                                    {{ 'no tasks to show' }}
                                                @endif

                                        </div>
                                    </div>


                                    <script>
                                        $('.checkboxes').on('change', function() {
                                            console.log($('.checkboxes').checked)
                                        })
                                    </script>
                                    <div class="col-12 mt-3">
                                        <h1 class="Comment-Heading">Comments</h1>
                                        <p class="p-2 text-muted">
                                            {{ isset($Task[0]->comments) ? $Task[0]->comments : 'No comments to show' }}
                                        </p>
                                        <!-- <textarea name="" class="form-control mt-3 bg-transparent w-100"></textarea> -->

                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Button trigger modal -->


<!-- Modal -->
<div class="modal fade" id="extend" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <form action="{{ route('admin.task_date_update') }}" method="POST">
            @csrf
            <div class="modal-content">
                <div class="modal-header extendModal">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Extend Date</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                        aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-12 mt-3">
                            <div>
                                <input type="hidden" id="extend_taskid" name="task_id"
                                    class="datepicker d-none form-control bg-transparent w-100">
                                <label for="end-Date" class="d-block">
                                    Start Date
                                </label>
                                <input type="date" id="start_date" name="start_datetime"
                                    class="datepicker form-control bg-transparent w-100">
                            </div>
                        </div>
                        <div class="col-12 mt-3">
                            <div>
                                <label for="end-Date" class="d-block">
                                    End Date
                                </label>
                                <input type="date" id="end_date" name="end_datetime"
                                    class="datepicker form-control bg-transparent w-100">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <!--                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>-->
                    <button type="submit" class="btn btn-secondary">Save</button>
                </div>
            </div>
        </form>
    </div>
</div>
<!--MODAL EDN-->
<!--DOCUMENT MODAL-->
{{-- <div class="modal fade" id="document" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header extendModal">
                    <h1 class="modal-title fs-5" id="exampleModalLabel">Documents</h1>
                   <button style="border:none !important;" type="button" class="btn-secondary " data-bs-dismiss="modal" aria-label="Close"> <i class="fa-regular fa-x"></i> </button>
                </div>
                <div class="modal-body DocumentModal">
                    <div class="row">
                        <div class="col-12 mt-3">
                            <div class="input-images-1m" style="padding-top: .5rem;"></div>
                        </div>

                        <div class="col-12 mt-3">

                            <div class="DownloadIconSetting d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column align-items-xxl-center align-items-xl-center align-items-lg-center align-items-md-center align-items-sm-start align-items-start justify-content-between">
                                <div class="d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column  gap-3">
                                    <div>
                                        <img src="../assets/icons/Avatar%20Icon.svg" alt="">
                                    </div>
                                    <div>
                                        <p class="m-0 p-0 FileNameHeading">
                                            insurance agreement.pdf
                                        </p>
                                        <small class="m-0 p-0">7 KB</small>
                                    </div>
                                </div>
                                <div>
                                    <a href="#">  <img src="../assets/icons/DownloadSimple.svg" alt=""></a>
                                    <a href="#"><img src="../assets/icons/trash.svg" alt=""></a>
                                </div>
                            </div>

                        </div>
                        <div class="col-12 mt-3">

                            <div class="DownloadIconSetting d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column align-items-xxl-center align-items-xl-center align-items-lg-center align-items-md-center align-items-sm-start align-items-start justify-content-between">
                                <div class="d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column  gap-3">
                                    <div>
                                        <img src="../assets/icons/Avatar%20Icon.svg" alt="">
                                    </div>
                                    <div>
                                        <p class="m-0 p-0 FileNameHeading">
                                            insurance agreement.pdf
                                        </p>
                                        <small class="m-0 p-0">7 KB</small>
                                    </div>
                                </div>
                                <div>
                                    <a href="#">  <img src="../assets/icons/DownloadSimple.svg" alt=""></a>
                                    <a href="#"><img src="../assets/icons/trash.svg" alt=""></a>
                                </div>
                            </div>

                        </div>
                        <div class="col-12 mt-3">

                            <div class="DownloadIconSetting d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column align-items-xxl-center align-items-xl-center align-items-lg-center align-items-md-center align-items-sm-start align-items-start justify-content-between">
                                <div class="d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column  gap-3">
                                    <div>
                                        <img src="../assets/icons/Avatar%20Icon.svg" alt="">
                                    </div>
                                    <div>
                                        <p class="m-0 p-0 FileNameHeading">
                                            insurance agreement.pdf
                                        </p>
                                        <small class="m-0 p-0">7 KB</small>
                                    </div>
                                </div>
                                <div>
                                    <a href="#">  <img src="../assets/icons/DownloadSimple.svg" alt=""></a>
                                    <a href="#"><img src="../assets/icons/trash.svg" alt=""></a>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <!--                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>-->
                    <button type="button" class="btn btn-secondary">Save</button>
                </div>
            </div>
        </div>
    </div> --}}
<!--DOCUMENT MODALEND-->

{{-- Delete Confirmation Modal Start --}}
<div class="modal fade" id="DeleteModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <form action="{{ route('admin.delete_task_doc') }}" method="POST">
            @csrf
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Delete Confirmation</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                        aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Are you sure want to delete?</p>
                    <input type="hidden" id="doc_id" name="doc_id">
                    <input type="hidden" id="doc_name" name="doc_name">
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Yes</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div>
            </div>
        </form>
    </div>
</div>
{{-- Delete Confirmation Modal End --}}

{{-- edit task modal start --}}
{{-- <div class="modal fade Header-Modal" id="Edit_task_modal" tabindex="-1" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Create Task Assignment</h5>
               <button style="border:none !important;" type="button" class="btn-secondary " data-bs-dismiss="modal" aria-label="Close"> <i class="fa-regular fa-x"></i> </button>
            </div>
            <form action="{{ route('admin.Update_task') }}" method="POST" enctype="multipart/form-data"
            id="task_form">
            @csrf
            <div class="modal-body">
                    <div class="row">
                        <div class="col-xxl-4 col-xl-4 col-lg-12 col-md-12 col-sm-12 col-12 modal-leftSIde">
                            <div class="row">

                                <div class="col-12 mt-3">
                                    <div class="p-3 CheckboxSection">
                                        <div class="d-flex justify-content-between">
                                            <h4 class="Checkbox-Heading">Tasks</h4>
                                            <div class="d-flex">
                                                <div class="custom-Radio-Button">
                                                    <label class="custom-radio m-0" for="modalcheck">
                                                        <input type="checkbox" class="customme selectallCheckBox" name="task_abbreviation[]"
                                                            id="modalcheck">
                                                        <span class="radio-btn"></span>

                                                    </label>
                                                </div>
                                                <span class="textbox-option">Select All</span>
                                            </div>
                                        </div>
                                        <div class="d-flex align-items-start mt-4 gap-5">
                                            <ul class="list-unstyled text-decoration-none d-flex flex-column gap-4" id="tasks">
                                                @if (!empty($all_tasks))
                                                @php
                                                    for ($i = 0; $i < count($all_tasks) ; $i++){
                                                echo '<li>
                                                    <div class="d-flex">
                                                        <div class="custom-Radio-Button">
                                                            <label class="custom-radio m-0" for="modalcheck1'.$i.'">
                                                                <input type="checkbox" class="customme tomarkallcheckbox">
                                                                <input type="checkbox" class="customme tomarkallcheckbox"
                                                                    name="task_abbreviation[]" id="modalcheck1'.$i.'" value="'.$all_tasks[$i].'">
                                                                <span class="radio-btn"></span>
                                                            </label>
                                                        </div>
                                                        <span class="textbox-option">'.$all_tasks[$i].'</span>
                                                    </div>
                                                </li>';
                                                }
                                                @endphp
                                                @endif
                                            </ul>

                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <div class="col-xxl-8 col-xl-8 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="row">
                                <div class="col-12">
                                    <div>
                                        <label for="start-Date" class="d-block">
                                            Task Title
                                        </label>
                                        <input type="text" name="task_name" placeholder="Account"
                                            id="task_name" class="form-control bg-transparent w-100">
                                            <input type="hidden" id="task_id" name="task_id">
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div>
                                        <label for="start-Date" class="d-block">
                                            Account
                                        </label>
                                        <input type="number" name="account" placeholder="Account"
                                            id="account" class="form-control bg-transparent w-100">
                                    </div>
                                </div>
                                <div class="col-12 mt-3">
                                    <div>
                                        <label for="start-Date" class="d-block">
                                            Company
                                        </label>
                                        <input type="text" name="company" placeholder="ABC Ltd." id="company"
                                            class="form-control bg-transparent w-100">
                                    </div>
                                </div>
                                <div class="col-12 mt-3">
                                    <div>
                                        <label for="start-Date" class="d-block">
                                            Department
                                        </label>
                                        <input type="text" name="department" placeholder="Testing"
                                            id="department" class="form-control bg-transparent w-100">
                                    </div>
                                </div>
                                <div class="col-12 mt-3">
                                    <div>
                                        <label for="start-Date" class="d-block">
                                            Test
                                        </label>
                                        <input type="text" name="test" id="test"
                                            class="form-control bg-transparent w-100">
                                    </div>
                                </div>
                                <div class="col-12 mt-3">
                                    <div>
                                        <label for="start-Date" class="d-block">
                                            Workers
                                        </label>
                                        <select id="workers"
                                            class="js-example-basic-multiple-limit form-control w-100"
                                            name="workers[]" multiple="multiple">
                                            @if (!empty($task_workers))
                                            @foreach ($task_workers as $item)
                                            @foreach ($item->users as $user)
                                            <option selected value="{{ $user->id}}">{{ isset($user->f_name) && isset($user->l_name) ? $user->f_name . ' ' . $user->l_name : '-'  }}</option>
                                            @endforeach
                                            @endforeach
                                            @endif
                                        </select>
                                    </div>
                                </div>
                                <div class="col-12 mt-3">
                                    <div>
                                        <label for="vehiclec" class="d-block">
                                            Vehicle Category
                                        </label>
                                        <input type="text" name="vehicle_category" id="vehicle_category"
                                            class="form-control bg-transparent w-100">
                                    </div>
                                </div>
                                <div class="col-12 mt-3">
                                    <div>
                                        <label for="T-Level" class="d-block">
                                            T-Level
                                        </label>
                                        <select name="t_level" class="js-select2 w-100 form-control" id="t_level">
                                            <option value="T1">T1</option>
                                            <option value="T2">T2</option>
                                            <option value="T3">T3</option>

                                        </select>
                                        <!-- <input type="text"  id="T-Level" class="form-control bg-transparent w-100"> -->
                                    </div>
                                </div>
                                <div class="col-12 mt-3">
                                    <div>
                                        <label for="Status" class="d-block">
                                            Status
                                        </label>
                                        <select name="status" class="js-select2 w-100 form-control" id="status">
                                            <option value="Created">Created</option>
                                            <option value="Submitted">Submitted</option>
                                            <option value="Approved">Approved</option>
                                            <option value="Rejected">Rejected</option>
                                            <option value="Active">Active</option>
                                            <option value="Completed">Completed</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-12 mt-3">
                                    <div>
                                        <label for="T-Level" class="d-block">
                                            Comments
                                        </label>
                                        <textarea name="comments" class="form-control w-100 bg-transparent" id="comments" cols="30" rows="2"></textarea>
                                        <!--                                    <input type="text"  id="T-Level" class="form-control bg-transparent w-100">-->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" id="task_form_btn" class="btn btn-primary">Save changes</button>
            </div>
        </form>
        </div>
    </div>
</div> --}}
{{-- edit task modal End --}}
@php

    $startDateTime = strtotime($Task[0]->start_datetime);
    $currentDateTime = strtotime(date('Y-m-d'));

@endphp



<script src="{{ asset('public/assets/js/select2.min.js') }}"></script>


<script>
      $('.js-select22').select2({
        selectOnClose: true
    });

</script>


<script>


function Edit_task(id) {
    console.log(id);

    $.ajax({
        url: "{{ route('admin.Edit_task') }}",
        type: "POST",
        data: {
            task_id: id,
            _token: "{{ csrf_token() }}"
        },
        success: function(res) {
            console.log(res)
            setTimeout(() => {
            $('.js-example-basic-multiple-limit-modal').select2();
                    $('.js-select2').select2()
            },1000)
            $(res).modal('show')
        }
    })
}


</script>

{{-- task timer --}}
<script>
    let all_task_completed = true;
    $("#check_all_tasks input[type='checkbox']").each(function(i,v){
        if($(v).is(":checked") === false){
            all_task_completed =false
        }
        (all_task_completed === true) ? $("#completeOption").css('display','block') : $("#completeOption").css('display','none')
    })
    function markTaskComplete(event, task_list_id) {
        let _token = '{{ csrf_token() }}';
        let task_id = '{{ $Task[0]->id }}'
        let status = ($(event).is(":checked") === true) ? "completed" : "pending";
        $.post('{{ route('admin.mark_as_complete') }}', {
            _token,
            task_list_id,
            status,
            task_id
        }, function(resp) {
            location.reload()
            console.log(resp)
        })

    }


</script>


<script>
    document.addEventListener("DOMContentLoaded", function() {
    let startTime = new Date("{{ $Task[0]->start_datetime }}").getTime();
    let currentTime = new Date().getTime();
    console.log(startTime, currentTime)

    if (('{{ $Task[0]->status }}' == 'Approved' || '{{ $Task[0]->status }}' == 'Active') && currentTime >= startTime) {
        startTimer(new Date("{{ $Task[0]->end_datetime }}").getTime());
        MarkActive()
    }
    if (('{{ $Task[0]->status }}' == 'Expired') && currentTime >= startTime) {
        startTimer(new Date("{{ $Task[0]->end_datetime }}").getTime());
        MarkActive()
    }

    function MarkActive(){
        $.ajax({
            url: "{{ route('admin.task_active') }}",
            type: "post",
            data: {
                status: "Active",
                id: "{{ $Task[0]->id }}",
                _token: "{{ csrf_token() }}"
            },
            success: function(res) {
                console.log(res);
            }
        });
    }




    function startTimer(expiryTime) {
        let timerInterval = setInterval(function() {
            let now = Date.now();
            let distance = expiryTime - now;

            if (distance <= 0) {
                clearInterval(timerInterval);
                document.getElementById('timerDisplay').innerHTML = "Expired";
                $.ajax({
                    url: "{{ route('admin.task_expired') }}",
                    type: "post",
                    data: {
                        status: "Expired",
                        id: "{{ $Task[0]->id }}",
                        _token: "{{ csrf_token() }}"
                    },
                    success: function(res) {
                        console.log(res);
                    }
                });
                return;
            }

            let days = Math.floor(distance / (1000 * 60 * 60 * 24));
            let hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            let minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
            let seconds = Math.floor((distance % (1000 * 60)) / 1000);

            document.getElementById('timerDisplay').innerHTML =
                (days > 0 ? days + "d " : "") +
                (hours < 10 ? "0" + hours : hours) + ":" +
                (minutes < 10 ? "0" + minutes : minutes) + ":" +
                (seconds < 10 ? "0" + seconds : seconds);

        }, 1000);
    }
});

</script>

<script>
    function Task_complete(id) {
        console.log(id)
        $.ajax({
            url: "{{ route('admin.task_complete') }}",
            type: "POST",
            data: {
                task_id: id,
                status: 'Completed',
                _token: "{{ csrf_token() }}"
            },
            success: function(res) {
                console.log(res);
                toastr.success(res.success);
            }
        })
    }
</script>


<script>
    //delete a single document
    function Delete_doc(id, files) {
        console.log(id)
        console.log(files)
        $('#doc_id').val(id)
        $('#doc_name').val(files)
        $('#DeleteModal').modal('show');
    }

    function extend_date(id) {
        console.log(id);
        let taskid = document.getElementById('extend_taskid');
        let strtdate = document.getElementById('start_date');
        let enddate = document.getElementById('end_date');
        console.log(taskid, strtdate, enddate);
        $.ajax({
            url: "{{ route('admin.task_date_extend') }}",
            type: 'POST',
            data: {
                task_id: id,
                _token: "{{ csrf_token() }}"
            },
            success: function(res) {
                console.log(res.start_datetime);
                taskid.value = res.id;
                strtdate.value = res.start_datetime;
                enddate.value = res.end_datetime;
                $('#extend').modal('show');
            }
        });
    }



</script>

{{-- group chat --}}

{{-- chat script --}}
<script>
    let group_id = $('#recgroupId').val();
    setInterval(() => {
        Show_chat(group_id)
    }, 1000);

    function Show_chat(group_id) {
        $('#reciever_typed_id').val(group_id);
        $.ajax({
            url: "{{ route('admin.show_group_chat') }}",
            type: "POST",
            data: {
                group_id: group_id,
                _token: "{{ csrf_token() }}"
            },
            success: function(res) {
                console.log(res);
                $('.apndChats').html(res.view);

            }
        });
    }

        function sendMessage(event) {
    if (event && event.keyCode !== 13) {
        return;
    }
            if ($('#sender_typed_msg').val() !== '') {
                console.log($('#sender_typed_msg').val())
                let sender_msg = $('#sender_typed_msg').val();
                let reciever_typed_id = $('#recgroupId').val();

                $.ajax({
                    url: "{{ route('admin.send_grp_Msg') }}",
                    type: "POST",
                    data: {
                        sender_msg: sender_msg,
                        reciever_id: reciever_typed_id,
                        _token: "{{ csrf_token() }}"
                    },
                    success: function(res) {
                        console.log(res);
                        // Refresh chat section
                        Show_chat(group_id);
                        // Clear input field
                        $('#sender_typed_msg').val('');
                    }
                });
            } else {
                return false;
            }
        }
</script>


@include('superadmin.footer')



@include('superadmin.admin_script')
