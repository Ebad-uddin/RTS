</div>
</div>


<footer class="iq-footer rtl-footer">
    <div class="container-fluid">
        <div class="row">

            <div class="col-lg-12 text-center ">
                Copyright <span id="copyright">
                    <script>
                        document.getElementById('copyright').appendChild(document.createTextNode(new Date().getFullYear()))
                    </script>
                    Design & Developed by
                </span> <a target="_blank" href="https://www.jetnetix.com">Jetnetix Solutions</a> All Rights Reserved.
            </div>
        </div>
    </div>
</footer>


<!-- Button trigger modal -->


<!-- Create Task Modal Start -->
<div class="modal fade Header-Modal" id="create_task_modal" tabindex="-1" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Create Task Assignment</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="{{ route('admin.create_task') }}" method="POST" enctype="multipart/form-data" id="task_form">
                <div class="modal-body">

                    @csrf
                    <div class="row">
                        <div class="col-xxl-4 col-xl-4 col-lg-12 col-md-12 col-sm-12 col-12 modal-leftSIde">
                            <div class="row">
                                <div class="col-12">
                                    <div>
                                        <label for="start-Date" class="d-block">
                                            Start Date & Time
                                        </label>
                                        <input value="{{ date('Y-m-d') }}" type="date" id="start_datetime"
                                            name="start_datetime" class="datepicker form-control bg-transparent w-100">
                                    </div>
                                </div>
                                <div class="col-12 mt-3">
                                    <div>
                                        <label for="end-Date" class="d-block">
                                            End Date & Time
                                        </label>
                                        <input value="{{ date('Y-m-d') }}" type="date" id="end_datetime"
                                            name="end_datetime" class="datepicker form-control bg-transparent w-100">
                                    </div>
                                </div>
                                <div class="col-12 mt-3">
                                    <div class="p-3 CheckboxSection">
                                        <div class="d-flex justify-content-between">
                                            <h4 class="Checkbox-Heading">Tasks</h4>
                                            <div class="d-flex">
                                                <div class="custom-Radio-Button">
                                                    <label class="custom-radio m-0" for="modalcheck">
                                                        <input type="checkbox" class="customme selectallCheckBox"
                                                            name="task_abbreviation[]" id="modalcheck">
                                                        <span class="radio-btn"></span>

                                                    </label>
                                                </div>
                                                <span class="textbox-option">Select All</span>
                                            </div>
                                        </div>
                                        <div class="d-flex align-items-start mt-4 gap-5">
                                            <!-- <ul class="list-unstyled text-decoration-none d-flex flex-column gap-4">
                                                  @if (!empty($all_tasks))
                                                @foreach ($all_tasks as $k => $t)
<li>
                                                    <div class="d-flex">
                                                        <div class="custom-Radio-Button">
                                                            <label class="custom-radio m-0" for="task_edit{{ $k }}">
                                                                {{-- <input type="checkbox" class="customme tomarkallcheckbox"> --}}
                                                                <input type="checkbox"  class="customme tomarkallcheckbox"
                                                                    name="task_abbreviation[]" id="task_edit{{ $k }}" value="{{ $t['id'] }}">
                                                                <span class="radio-btn"></span>
                                                            </label>
                                                        </div>
                                                        <span class="textbox-option">{{ $t['task_abbreviation'] }}</span>
                                                    </div>
                                                </li>
@endforeach
                                                
                                                @endif
                                            </ul> -->
                                            @php $count = 0; @endphp
                                            @if (!empty($all_tasks))
                                                @foreach ($all_tasks as $k => $t)
                                                    @if ($count % 9 == 0)
                                                        @if ($count != 0)
                                                            </ul>
                                                        @endif
                                                        <ul
                                                            class="list-unstyled text-decoration-none d-flex flex-column gap-4">
                                                    @endif
                                                    <li>
                                                        <div class="d-flex">
                                                            <div class="custom-Radio-Button">
                                                                <label class="custom-radio m-0"
                                                                    for="task_edit{{ $k }}">
                                                                    {{-- <input type="checkbox" class="customme tomarkallcheckbox"> --}}
                                                                    <input type="checkbox"
                                                                        class="customme tomarkallcheckbox"
                                                                        name="task_abbreviation[]"
                                                                        id="task_edit{{ $k }}"
                                                                        value="{{ $t['id'] }}">
                                                                    <span class="radio-btn"></span>
                                                                </label>
                                                            </div>
                                                            <span
                                                                class="textbox-option">{{ $t['task_abbreviation'] }}</span>
                                                        </div>
                                                    </li>
                                                    @php $count++; @endphp
                                                @endforeach
                                                </ul>
                                            @endif


                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 mt-3">
                                    <div class="input-images-1" name="images[]" style="padding-top: .5rem;"></div>
                                </div>
                            </div>
                        </div>
                        <div class="col-xxl-8 col-xl-8 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="row">
                                <div class="col-12">
                                    <div>
                                        <label for="start-Date" class="d-block">
                                            Account
                                        </label>
                                        <input type="number" name="account" placeholder="Account" id="start-Date"
                                            class="form-control bg-transparent w-100">
                                    </div>
                                </div>
                                <div class="col-12 mt-3">
                                    <div>
                                        <label for="start-Date" class="d-block">
                                            Task Title
                                        </label>
                                        <input type="text" name="task_name" placeholder="Enter Title"
                                            id="task_name" class="form-control bg-transparent w-100">
                                    </div>
                                </div>
                                <div class="col-12 mt-3">
                                    <div>
                                        <label for="start-Date" class="d-block">
                                            Company
                                        </label>
                                        <input type="text" name="company" placeholder="ABC Ltd." id="start-Date"
                                            class="form-control bg-transparent w-100">
                                    </div>
                                </div>
                                <div class="col-12 mt-3">
                                    <div>
                                        <label for="start-Date" class="d-block">
                                            Department
                                        </label>
                                        <input type="text" name="department" placeholder="Testing"
                                            id="start-Date" class="form-control bg-transparent w-100">
                                    </div>
                                </div>
                                <div class="col-12 mt-3">
                                    <div>
                                        <label for="start-Date" class="d-block">
                                            Test
                                        </label>
                                        <input type="text" name="test" id="start-Date"
                                            class="form-control bg-transparent w-100">
                                    </div>
                                </div>
                                <div class="col-12 mt-3">
                                    <div>
                                        <label for="start-Date" class="d-block">
                                            Workers
                                        </label>
                                        <select id="workers"
                                            class="js-example-basic-multiple-limit form-control w-100"
                                            name="workers[]" multiple="multiple">
                                            @if (!empty($workers))
                                                @foreach ($workers as $worker)
                                                    <option value="{{ $worker->id }}">
                                                        {{ isset($worker->f_name) && isset($worker->l_name) ? $worker->f_name . ' ' . $worker->l_name : '-' }}
                                                    </option>
                                                @endforeach
                                            @endif
                                        </select>
                                    </div>
                                </div>
                                <div class="col-12 mt-3">
                                    <div>
                                        <label for="vehiclec" class="d-block">
                                            Vehicle Category
                                        </label>
                                        <input type="text" name="vehicle_category" id="vehiclec"
                                            class="form-control bg-transparent w-100">
                                    </div>
                                </div>
                                <div class="col-12 mt-3">
                                    <div>
                                        <label for="T-Level" class="d-block">
                                            T-Level
                                        </label>
                                        <select name="t_level" class="js-select22 w-100 form-control" id="">
                                            <option value="T1">T1</option>
                                            <option value="T2">T2</option>
                                            <option value="T3">T3</option>

                                        </select>
                                        <!-- <input type="text"  id="T-Level" class="form-control bg-transparent w-100"> -->
                                    </div>
                                </div>
                                <div class="col-12 mt-3">
                                    <div>
                                        <label for="Status" class="d-block">
                                            Status
                                        </label>
                                        <select name="status" class="js-select22 w-100 form-control" id="">
                                            <option value="Created">Created</option>
                                            <option value="Submitted">Submitted</option>
                                            <option value="Approved">Approved</option>
                                            <option value="Rejected">Rejected</option>
                                            <option value="Active">Active</option>
                                            <option value="Completed">Completed</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-12 mt-3">
                                    <div>
                                        <label for="T-Level" class="d-block">
                                            Comments
                                        </label>
                                        <textarea name="comments" class="form-control w-100 bg-transparent" id="" cols="30" rows="2"></textarea>
                                        <!--                                    <input type="text"  id="T-Level" class="form-control bg-transparent w-100">-->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" id="task_form_btn" class="btn btn-primary">Save changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Create Task Modal End -->





<div class="modal fade CreateGroup" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title group_title" id="exampleModalLabel">Create Group</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form action="{{ route('admin.create_group') }}" method="POST" id="add_worker">
                    @csrf
                    <div class="row">
                        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12">
                            <div class="mb-3">
                                <div>
                                    <label class="group_label">Group Manager</label>
                                </div>
                                <select name="group_manager[]"
                                    class="form-select w-100 js-example-basic-multiple-limit"
                                    data-minimum-results-for-search="Infinity" multiple="multiple">
                                    {{-- @foreach ($grp_manager as $item)
                                <option value="{{$item->id}}" selected>{{isset($item->f_name) && isset($item->l_name) ? $item->f_name . ' ' . $item->l_name : '-'}}</option>
                                @endforeach --}}

                                </select>
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-12 col-lg-6 col-xl-6 col-xxl-6 col-12">
                            <div class="mb-3">
                                <label class="group_label">Group Name</label>
                                <input class="form-control w-100" name="group_name"
                                    placeholder="Please enter your group name" type="text">
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-12 col-lg-6 col-xl-6 col-xxl-6 col-12">
                            <div class="mb-3">
                                <label class="group_label">Email Address</label>
                                <input class="form-control w-100" name="email"
                                    placeholder="Please enter your email address" type="email">
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-12 col-lg-6 col-xl-6 col-xxl-6 col-12">
                            <div class="mb-3">
                                <label class="group_label">Address</label>
                                <input type="text" class="form-control w-100" name="address"
                                    placeholder="Please enter your address">
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-12 col-lg-6 col-xl-6 col-xxl-6 col-12">
                            <div class="mb-3">
                                <label class="group_label">Main Phone</label>
                                <input type="number" class="form-control w-100" name="phone"
                                    placeholder="Please enter your number">
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12">
                            <div class="mb-3">
                                <div>
                                    <label class="group_label">Group Members</label>
                                </div>
                                <select name="group_mambers[]"
                                    class="form-select w-100 js-example-basic-multiple-limit"
                                    data-minimum-results-for-search="Infinity" multiple="multiple">
                                    @if (!empty($workers))
                                        @foreach ($workers as $item)
                                            <option value="{{ $item->id }}" selected>
                                                {{ isset($item->f_name) && isset($item->l_name) ? $item->f_name . ' ' . $item->l_name : '-' }}
                                            </option>
                                        @endforeach
                                    @endif
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12">
                            <div class="mb-3">
                                <label class="userview_label">Comments</label>
                                <textarea name="comments" type="text" class="form-control w-100 form_textarea"
                                    placeholder="Enter some description..."></textarea>
                            </div>
                        </div>
                    </div>
                </form>

            </div>
            <div class="modal-footer">
                <button type="submit" id="add_worker_btn" class="btn btn-secondary"
                    data-bs-dismiss="modal">Create</button>
            </div>
        </div>
    </div>
</div>

<div class="modal fade CreateGroup2" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-md">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title group_title" id="exampleModalLabel">Create Group</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12">
                        <div class="mb-3">
                            <div>
                                <label class="group_label">Group Manager</label>
                            </div>
                            <select class="form-select w-100 js-example-basic-multiple-limit w-100"
                                data-minimum-results-for-search="Infinity" multiple="multiple">
                                <option value="" selected>James</option>
                                <option value="">Gordon</option>
                                <option value="">James</option>
                                <option value="">Gordon</option>
                            </select>
                        </div>
                    </div>

                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Create</button>
            </div>
        </div>
    </div>
</div>



{{-- Add worker Modal --}}
<div class="modal fade AddWorkerModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Add User</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="{{ route('admin.addWorker') }}" id="addWorkerForm" method="POST"
                enctype="multipart/form-data">
                @csrf
                <div class="modal-body">
                    <div class="row">

                        <div class="col-sm-12 col-md-4 col-lg-3 col-xl-3 col-xxl-3 col-12">
                            <div
                                class="d-flex align-items-center flex-column justify-content-center position-relative h-100">
                                <div class="d-flex ">
                                    <div class="avatar-upload">
                                        <div class="avatar-edit">
                                            <label for="imageUploadUser"></label>
                                        </div>
                                        <div class="avatar-preview">
                                            <div   class="imagePreview" id="imagePreviewSetting">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="d-flex align-items-center position-absolute">
                                    <label for="imageUploadUser" class="upload_picture">
                                        <div name="image"
                                            class="avatar-edit d-flex justify-content-center align-items-center">
                                            <i class="fi fi-rr-upload mt-1"></i>
                                            Upload Picture
                                        </div>
                                    </label>
                                    <input type="file" id="imageUploadUser" name="image" accept=".png, .jpg, .jpeg"
                                        style="display: none;">
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-8 col-lg-4 col-xl-4 col-xxl-4 col-12">
                            <div class="row">
                                <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12">
                                    <div class="mb-3">
                                        <label class="userview_label">First Name</label>
                                        <input type="text" name="f_name" class="form-control w-100"
                                            placeholder="Please enter your first name">
                                    </div>
                                </div>
                                <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12">
                                    <div class="mb-3">
                                        <label class="userview_label">Last Name</label>
                                        <input type="text" name="l_name" class="form-control w-100"
                                            placeholder="Please enter your last name">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-12 col-lg-5 col-xl-5 col-xxl-5 col-12">
                            <div class="mb-3">
                                <label class="userview_label">Email Address</label>
                                <input type="text" name="email" id="useremail" class="form-control w-100"
                                    placeholder="Please enter your email">
                                    <span class="text-danger" id="emailerror"></span>
                            </div>
                            <div class="mb-3">
                                <label class="userview_label">Main Phone</label>
                                <input type="number" name="phone" class="form-control w-100"
                                    placeholder="Please enter your number">
                            </div>
                        </div>
                    </div>
                    <div class="row mt-2 mb-2 auto_row">
                        <div class="col-sm-12 col-md-12 col-lg-6 col-xl-6 col-xxl-6 col-12 auto_pad">
                            <div class="row">
                                <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12">
                                    <div class="mb-3">
                                        <div>
                                            <label class="userview_label">Residential Address</label>
                                        </div>
                                        <input type="text" name="address" class="form-control w-100"
                                            placeholder="Please enter your residential address">
                                    </div>
                                </div>
                                <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12">
                                    <div class="mb-3">
                                        <label class="userview_label">Training Level</label>
                                        <input type="text" name="training_level" class="form-control w-100"
                                            placeholder="Please enter your training level">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-12 col-lg-6 col-xl-6 col-xxl-6 col-12 auto_pad">
                            <div class="row">
                                <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12">
                                    <div class="mb-3">
                                        <div class="mb-3">
                                            <div>
                                                <label class="userview_label">Role</label>
                                            </div>
                                            <select name="role" class="js-select22 superadmin_role"
                                                data-minimum-results-for-search="Infinity">
                                                <option value="sitemanager">Site Manager</option>
                                                <option value="groupmanager">Group Manager</option>
                                                <option value="worker">Worker</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12">
                                    <div class="mb-3">
                                        <label class="userview_label">Status</label>
                                        <input type="text" name="status" class="form-control w-100"
                                            placeholder="" value="">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12 auto_pad">
                            <div class="mb-3">
                                <label class="userview_label">Comments</label>
                                <textarea type="text" name="comment" class="form-control w-100 form_textarea"
                                    placeholder="Please enter some comments"></textarea>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" id="addWorkerbtn" onclick="Check_Email()" class="btn btn-primary">Add</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!--DELETE MODAL START -->
<!-- Button trigger modal -->

<!-- Task Delete Modal Start -->
<div class="modal fade" id="task_delete_modal" tabindex="-1" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog">
        <form action="{{ route('admin.delete_task') }}" method="POST">
            @csrf
            <div class="modal-content">
                <div class="modal-header">
                    <input type="hidden" name="task_id" id="task">
                    <h5 class="modal-title" id="exampleModalLabel">Delete Confirmation</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Are you sure want to delete?</p>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Yes</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div>
            </div>
        </form>
    </div>
</div>
<!--Task Delete Modal End -->

<!-- Task Delete Modal Start -->
<div class="modal fade" id="Delete_worker" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <form action="{{ route('admin.delete_worker') }}" method="POST">
            @csrf
            <div class="modal-content">
                <div class="modal-header">
                    <input type="hidden" name="worker_id" id="worker_id">
                    <h5 class="modal-title" id="exampleModalLabel">Delete Confirmation</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Are you sure want to delete?</p>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Yes</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div>
            </div>
        </form>
    </div>
</div>
<!-- Task Delete Modal End -->

<!-- TaskList Delete Modal Start -->

<div class="modal fade" id="Delete_task_list" tabindex="-1" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog">
        <form action="{{ route('admin.del_task_list') }}" method="POST">
            @csrf
            <div class="modal-content">
                <div class="modal-header">
                    <input type="hidden" name="task_list" id="task_list_id">
                    <h5 class="modal-title" id="exampleModalLabel">Delete Confirmation</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Are you sure want to delete?</p>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Yes</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div>
            </div>
        </form>
    </div>
</div>
<!--TaskList Delete Modal End -->
<script>

    function Check_Email(){
      $('#emailerror').text(' ');
        let email  = $('#useremail').val();
        $.ajax({
          url : "{{route('admin.checkEmail')}}",
          type : "POST",
          data : {
              email : email,
              _token : "{{csrf_token()}}"
          },
          success : function(res){
              if(res  == true){
              $('#emailerror').text('Email already exist');
              }else{
                  $('#addWorkerForm').submit();
              }
          }
      })
  }
  </script>


<script src="{{ asset('public/assets/js/select2.min.js') }}"></script>


<script>
    $('.js-select22').select2({
        selectOnClose: true
    });
    $('.superadmin_role').select2({
        selectOnClose: true
    });

    $('.change_status_task_view').select2();

    $(".js-example-basic-multiple-limit").select2();
</script>



<script src="{{ asset('public/assets/js/bootstrap.min.js') }}"></script>

<!--<script src="../assets/js/bundle.min.js"></script>-->
<script src="{{ asset('public/assets/vendor/fullcalendar/core/main.js') }}"></script>
<script src="{{ asset('public/assets/vendor/fullcalendar/daygrid/main.js') }}"></script>
<script src="{{ asset('public/assets/vendor/fullcalendar/timegrid/main.js') }}"></script>
<script src="{{ asset('public/assets/vendor/fullcalendar/list/main.js') }}"></script>


<script src="{{ asset('public/assets/js/sweetalert.js') }}"></script>
<script src="{{ asset('public/assets/js/slider.js') }}"></script>
<script src="{{ asset('public/assets/js/app.js') }}"></script>
<script src="{{ asset('public/assets/js/calender.js') }}"></script>
<script src="{{ asset('public/assets/js/ckeditor.js') }}"></script>
<script src="{{ asset('public/assets/js/datatables.js') }}"></script>
<script src="https://kit.fontawesome.com/2ab38ab271.js" crossorigin="anonymous"></script>

{{-- jquery toastr --}}
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

<!-- <script src="../assets/js/chart-custom.js"></script> -->
<script src="{{ asset('public/assets/vendor/drag-drop-image-uploader/dist/image-uploader.min.js') }}"></script>



<script>
    //  Task delete modal

    function Del_task(id) {
        console.log(id);
        $('#task').val(id);
    }

    //  worker delete modal

    function Delete_worker(id) {
        console.log(id);
        $('#worker_id').val(id);
    }

    function Task_list_Del(id) {
        console.log(id)
        $('#task_list_id').val(id);
    }
</script>

{{-- jquery toastr --}}

<script>
    @if (session('success'))
        $(function() {
            toastr.success('{{ session('success') }}', '', {
                positionClass: 'toast-center',
            });
        });
    @endif

    @if (session('error'))
        $(function() {
            toastr.error('{{ session('error') }}', '', {
                positionClass: 'toast-center',
            });
        });
    @endif
</script>

{{-- update task --}}

<script>
    function changeStatusFunc(event, id) {
        checkTertiary(event)
        var status = event.target.value
        console.log(id, status);
        $.ajax({
            url: "{{ route('admin.updateStatus') }}",
            method: "POST",
            data: {
                task_id: id,
                status: status,
                _token: "{{ csrf_token() }}"
            },
            success: function(res) {
                console.log(res);
                $(function() {
                    toastr.success(res.success, '', {
                        positionClass: 'toast-center',
                    });
                });

            }
        })

    }
</script>

{{-- validations for task assignment modal --}}




<script>
    var _seed = 42;
    Math.random = function() {
        _seed = _seed * 16807 % 2147483647;
        return (_seed - 1) / 2147483646;
    };
</script>
<script>
    const selectallCheckBox = document.querySelector('.selectallCheckBox');
    const tomarkallcheckbox = document.querySelectorAll('.tomarkallcheckbox');

    selectallCheckBox.addEventListener('change', function() {
        if (selectallCheckBox.checked) {
            console.log(tomarkallcheckbox);
            tomarkallcheckbox.forEach(function(checkbox) {
                checkbox.checked = true;
            });

        } else {
            console.log(`Checkbox is unchecked.`);

            tomarkallcheckbox.forEach(function(checkbox) {
                checkbox.checked = false;
            });
        }
    });
</script>


<script>
    // select2 js
    $('.js-select22').select2({
        selectOnClose: true
    });


    $(".js-example-tokenizer").select2({
        tags: true,
        tokenSeparators: [',', ' ']
    })
</script>


<script>
    new DataTable('.dataTable', {
        ordering: false
    });
</script>

<!-- settings image uploader -->
<script>
    function readEditLogo(input) {
        console.log(input.files[0])
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {
                console.log(e.target.result)
                $('#imagePreview').css('background-image', 'url(' + e.target.result + ')');
                $('#imagePreview').hide();
                $('#imagePreview').fadeIn(650);
            }
            reader.readAsDataURL(input.files[0]);
        }
    }
    $("#imageUpload").change(function() {
        readEditLogo(this);
    });



    function readUserImg(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            reader.onload = function(e) {

                $('#imagePreviewSetting').css('background-image', 'url(' + e.target.result + ')');
                console.log($('#imagePreviewSetting'))
                $('#imagePreviewSetting').hide();
                $('#imagePreviewSetting').fadeIn(650);
            }
            reader.readAsDataURL(input.files[0]);
        }
    }
    $("#imageUploadUser").change(function() {
        readUserImg(this);
    });


    



    // hide/show password on settings page


    function password_show_hide() {
        var x = document.getElementById("CurrentPassword");
        var show_eye = document.getElementById("show_eye_current");
        var hide_eye = document.getElementById("hide_eye_current");
        hide_eye.classList.remove("d-none");
        if (x.type === "password") {
            x.type = "text";
            show_eye.style.display = "none";
            hide_eye.style.display = "block";
        } else {
            x.type = "password";
            show_eye.style.display = "block";
            hide_eye.style.display = "none";
        }
    }


    function password_showhide() {
        var x = document.getElementById("NewPassword");
        var show_eye = document.getElementById("show_eye_new");
        var hide_eye = document.getElementById("hide_eye_new");
   
        hide_eye.classList.remove("d-none");
        if (x.type === "password") {
            x.type = "text";
            show_eye.style.display = "none";
            hide_eye.style.display = "block";
            
            
        } else {
            x.type = "password";
            show_eye.style.display = "block";
            hide_eye.style.display = "none";
        }
    }
    function password_showhide2() {
        var x = document.getElementById("NewPassword2");
        var show_eye = document.getElementById("show_eye_new2");
        var hide_eye = document.getElementById("hide_eye_new2");
        hide_eye.classList.remove("d-none");
        if (x.type === "password") {
            x.type = "text";
            show_eye.style.display = "none";
            hide_eye.style.display = "block";
        } else {
            x.type = "password";
            show_eye.style.display = "block";
            hide_eye.style.display = "none";
        }
    }
</script>


<script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
<script>
    flatpickr(".datepicker", {
        enableTime: true,
        dateFormat: "Y-m-d H:i",
    });
</script>


<script>
    $(function() {

        $('.input-images-1').imageUploader({
        extensions: ['.pdf', '.doc', '.docx', '.xls', '.csv', '.jpg', '.jpeg', '.png'],
        mimes: ['application/pdf', 'application/msword',
            'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'application/vnd.ms-excel', 'text/csv', 'image/jpeg', 'image/png'
        ]
    });

        let preloaded = [{
                id: 1,
                src: 'https://picsum.photos/500/500?random=1'
            },
            {
                id: 2,
                src: 'https://picsum.photos/500/500?random=2'
            },
            {
                id: 3,
                src: 'https://picsum.photos/500/500?random=3'
            },
            {
                id: 4,
                src: 'https://picsum.photos/500/500?random=4'
            },
            {
                id: 5,
                src: 'https://picsum.photos/500/500?random=5'
            },
            {
                id: 6,
                src: 'https://picsum.photos/500/500?random=6'
            },
        ];

        $('.input-images-2').imageUploader({
            preloaded: preloaded,
            imagesInputName: 'photos',
            preloadedInputName: 'old',
            maxSize: 2 * 1024 * 1024,
            maxFiles: 10
        });



        // Input and label handler
        $('input').on('focus', function() {
            $(this).parent().find('label').addClass('active')
        }).on('blur', function() {
            if ($(this).val() == '') {
                $(this).parent().find('label').removeClass('active');
            }
        });

        // Sticky menu
        let $nav = $('nav'),
            $header = $('header'),
            offset = 4 * parseFloat($('body').css('font-size')),
            scrollTop = $(this).scrollTop();

        // Initial verification
        setNav();

        // Bind scroll
        $(window).on('scroll', function() {
            scrollTop = $(this).scrollTop();
            // Update nav
            setNav();
        });

        function setNav() {
            if (scrollTop > $header.outerHeight()) {
                $nav.css({
                    position: 'fixed',
                    'top': offset
                });
            } else {
                $nav.css({
                    position: '',
                    'top': ''
                });
            }
        }
    });
    $(function() {

        $('.input-images-1m').imageUploader({
            extensions: ['.pdf', '.doc', '.docx', '.xls', '.csv'],
            mimes: ['application/pdf', 'application/msword',
                'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                'application/vnd.ms-excel', 'text/csv'
            ]
        });

        let preloaded = [{
                id: 1,
                src: 'https://picsum.photos/500/500?random=1'
            },
            {
                id: 2,
                src: 'https://picsum.photos/500/500?random=2'
            },
            {
                id: 3,
                src: 'https://picsum.photos/500/500?random=3'
            },
            {
                id: 4,
                src: 'https://picsum.photos/500/500?random=4'
            },
            {
                id: 5,
                src: 'https://picsum.photos/500/500?random=5'
            },
            {
                id: 6,
                src: 'https://picsum.photos/500/500?random=6'
            },
        ];

        $('.input-images-2').imageUploader({
            preloaded: preloaded,
            imagesInputName: 'photos',
            preloadedInputName: 'old',
            maxSize: 2 * 1024 * 1024,
            maxFiles: 10
        });





        // Input and label handler
        $('input').on('focus', function() {
            $(this).parent().find('label').addClass('active')
        }).on('blur', function() {
            if ($(this).val() == '') {
                $(this).parent().find('label').removeClass('active');
            }
        });

        // Sticky menu
        let $nav = $('nav'),
            $header = $('header'),
            offset = 4 * parseFloat($('body').css('font-size')),
            scrollTop = $(this).scrollTop();

        // Initial verification
        setNav();

        // Bind scroll
        $(window).on('scroll', function() {
            scrollTop = $(this).scrollTop();
            // Update nav
            setNav();
        });

        function setNav() {
            if (scrollTop > $header.outerHeight()) {
                $nav.css({
                    position: 'fixed',
                    'top': offset
                });
            } else {
                $nav.css({
                    position: '',
                    'top': ''
                });
            }
        }
    });
</script>
<script>
     function applyColor(){
        const tosetitas = document.querySelectorAll('.tosetitas')
        setTimeout(()=>{
            tosetitas.forEach(function(tosetitas) {
                if (tosetitas.value === 'Approved') {
                    tosetitas.nextElementSibling.children[0].children[0].style.backgroundColor = "#E4F6ED";
                    tosetitas.nextElementSibling.children[0].children[0].children[0].style.color = "#1DB469";
                    tosetitas.nextElementSibling.children[0].children[0].style.setProperty('border',
                        '1px solid #1DB469', 'important');
                }
                if (tosetitas.value === 'Submitted') {
                    tosetitas.nextElementSibling.children[0].children[0].style.backgroundColor = "#FFF9DF";
                    tosetitas.nextElementSibling.children[0].children[0].children[0].style.color = "#D8A800";
                    tosetitas.nextElementSibling.children[0].children[0].style.setProperty('border',
                        '1px solid #D8A800', 'important');
                }
                if (tosetitas.value === 'Active') {
                    tosetitas.nextElementSibling.children[0].children[0].style.backgroundColor = "#E4EAFB";
                    tosetitas.nextElementSibling.children[0].children[0].children[0].style.color = "#4A72FF";
                    tosetitas.nextElementSibling.children[0].children[0].style.setProperty('border',
                        '1px solid #4A72FF', 'important');
                }
                if (tosetitas.value === 'Expired') {
                    tosetitas.nextElementSibling.children[0].children[0].style.backgroundColor = "#FAE3F4";
                    tosetitas.nextElementSibling.children[0].children[0].children[0].style.color = "#FF3838";
                    tosetitas.nextElementSibling.children[0].children[0].style.setProperty('border',
                        '1px solid #FF3838', 'important');
                }
                if (tosetitas.value === 'Expired') {
                    tosetitas.nextElementSibling.children[0].children[0].style.backgroundColor = "#E4EAFB";
                    tosetitas.nextElementSibling.children[0].children[0].children[0].style.color = "#4A72FF";
                    tosetitas.nextElementSibling.children[0].children[0].style.setProperty('border',
                        '1px solid #4A72FF', 'important');

                    }
                    if (tosetitas.value === 'Completed') {
                        tosetitas.nextElementSibling.children[0].children[0].style.backgroundColor = "#E4EAFB";
                    tosetitas.nextElementSibling.children[0].children[0].children[0].style.color = "#4A72FF";
                    tosetitas.nextElementSibling.children[0].children[0].style.setProperty('border',
                        '1px solid #4A72FF', 'important');

                    }
            });

        },2000)
    }

    window.onload = function() {

       applyColor();

    };


    function checkTertiary(e) {
        console.log(e.target.value)
        console.log(e.target.nextElementSibling.children[0].children[0].children[0])
        console.log(e.target.nextElementSibling.children[0].children[0])
        if (e.target.value === 'Approved') {
            // e.target.nextElementSibling.children[0].children[0].classList.add('bg-danger')
            e.target.nextElementSibling.children[0].children[0].style.backgroundColor = "#E4F6ED";
            e.target.nextElementSibling.children[0].children[0].children[0].style.color = "#1DB469";
            e.target.nextElementSibling.children[0].children[0].style.setProperty('border', '1px solid #1DB469',
                'important');

        }
        if (e.target.value === 'Submitted') {
            e.target.nextElementSibling.children[0].children[0].style.backgroundColor = "#FFF9DF";
            e.target.nextElementSibling.children[0].children[0].children[0].style.color = "#D8A800";
            e.target.nextElementSibling.children[0].children[0].style.setProperty('border', '1px solid #D8A800',
                'important');

        }
        if (e.target.value === 'Active') {
            e.target.nextElementSibling.children[0].children[0].style.backgroundColor = "#E4EAFB";
            e.target.nextElementSibling.children[0].children[0].children[0].style.color = "#4A72FF";
            e.target.nextElementSibling.children[0].children[0].style.setProperty('border', '1px solid #4A72FF',
                'important');

        }
        if (e.target.value === 'Expired') {
            e.target.nextElementSibling.children[0].children[0].style.backgroundColor = "#FAE3F4";
            e.target.nextElementSibling.children[0].children[0].children[0].style.color = "#FF3838";
            e.target.nextElementSibling.children[0].children[0].style.setPrope
        }
    }
</script>
