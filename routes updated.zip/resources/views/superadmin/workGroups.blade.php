<?php
$activebar = 'groups';
?>
@include('superadmin.header')
<div class="iq-top-navbar py-2 rtl-iq-top-navbar ">
    <div class="iq-navbar-custom">
        <nav class="navbar navbar-expand-lg navbar-light p-0 toSetNavBarAll w-100">
            <div class="iq-navbar-logo d-flex align-items-center justify-content-between">
                <i class="ri-menu-line wrapper-menu"></i>
                <!-- Mobile Logo -->
            </div>
            <div class="iq-search-bar device-search">
                <h4 class="main_content_title ps-3">Work Groups</h4>
            </div>
            @include('superadmin.tooltip')
            <div class="d-xxl-none d-xl-none d-lg-none d-md-block d-sm-block d-block">
                <ul class="align-items-center d-flex gap-4 list-unstyled text-decoration-none m-0">
                    <li>
                        <button class="nav-AddNew-Button btn btn-primary" type="button" data-bs-toggle="modal"
                            data-bs-target="#exampleModal">Create Task</button>
                    </li>
                </ul>
            </div>
        </nav>
    </div>
</div>



<div class="content-page rtl-page">
    <div class="container-fluid mt-4">
        <div class="row UserPage">
            <div class="col-12">
                <div class="row mt-4">
                    <div class="col-12 ">
                        <div class="bg-white p-3 index-TablePage">
                            <div class="mb-3">
                                <div
                                    class="align-items-center d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column justify-content-between toSetFilterIcon">
                                    <div class="d-flex align-items-center gap-3">
                                        <h4 class="file-Heading">
                                            All Groups
                                        </h4>
                                        <a href="javascript:void(0)" class="text-decoration-none">
                                            <button data-bs-target=".CreateGroup" data-bs-toggle="modal"
                                                class="btn btn-secondary AllWorkerPageButton"><svg width="18"
                                                    height="18" viewBox="0 0 18 18" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M2.8125 9H15.1875M9 2.8125V15.1875" stroke-width="1.5"
                                                        stroke-linecap="round" stroke-linejoin="round" />
                                                </svg>
                                            </button>
                                        </a>
                                    </div>
                                    <div
                                        class="TogiveFullWidth d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column gap-2 mt-xxl-0 mt-xl-0 mt-lg-0 mt-md-0 mt-sm-3 mt-3">
                                        <!--                                            <select name="" class="js-select2" data-minimum-results-for-search="Infinity" >-->
                                        <!--                                                <option value="All Task">All Task</option>-->
                                        <!--                                                <option value="Staff Task">Staff Task</option>-->
                                        <!--                                                <option value="My Task">My Task</option>-->
                                        <!--                                            </select>-->
                                        <!-- <button  class="FilterButtonSetting btn btn-secondary d-flex gap-2 align-items-center" >
                                                Sort by <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M3.375 13.4995H7.3125M10.125 11.812L12.9375 14.6245M12.9375 14.6245L15.7499 11.8125M12.9375 14.6245L12.9375 7.87451M3.375 8.99951H8.43743M3.375 4.49951H12.9374"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                </svg>
                                            </button> -->

                                        <!--                                                 <input type="text" class="form-control">-->
                                        <!--                                            <form action="" class="p-0 m-0 position-relative">-->
                                        <!--                                                <img style="" class="GlobalInputIconSetting position-absolute" src="../assets/icons/MagnifyingGlass.svg" alt="">-->
                                        <!--                                                <input style="" type="text" class="form-control GlobalInputSetting" placeholder="s">-->
                                        <!--                                            </form>-->
                                    </div>
                                </div>
                            </div>
                            <div class="table-responsive">
                                <table id="" class="dataTable table-responsive stripe w-100 ">
                                    <thead>
                                        <tr>
                                            <th class="text-start" >
                                                S.No
                                            </th>
                                            <th class="text-start">Created On</th>
                                            <th class="text-start">Group Name</th>
                                            <th class="text-start">Address</th>
                                            <th class="text-start">Group Members</th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @foreach ($all_group as $k=>$item)
                                            <tr>
                                                <td>
                                                  <p class="table-MainHeading" > {{$k+1}}</p>
                                                </td>
                                                <td>
                                                    @php
                                                        $timestamp = strtotime($item->created_at);
                                                        $date = date('Y.j.n', $timestamp);
                                                        $time = date('H:i:s', $timestamp);
                                                    @endphp
                                                    <p class="p-0 m-0 table-MainHeading mb-1">
                                                        {{ $date }},
                                                    </p>
                                                    <p class="p-0 m-0 table-SubHeading">
                                                        {{ $time }}
                                                    </p>
                                                </td>
                                                <td>
                                                    <p class="p-0 m-0 table-MainHeading mb-1">
                                                        {{ $item->gorup_name }}
                                                    </p>
                                                    <p class="p-0 m-0 table-SubHeading">
                                                        {{ $item->email }}
                                                    </p>
                                                </td>
                                                <td>
                                                    <p class="p-0 m-0 table-MainHeading">
                                                        {{ $item->address }}
                                                    </p>
                                                </td>
                                                <td colspan="2">
                                                    <div class="d-flex">
                                                        @if (!empty($item->users))
                                                        @foreach ($item->users as $member)
                                                            <div>
                                                                <div class="tale-small-image timage-1">
                                                                    @if (!empty($member) and !empty($member->image))
                                                                        <img src="{{ url('storage/app/uploads/' . $member->image) }}"
                                                                            alt="{{ $member->image }}">
                                                                    @else
                                                                        <img src="{{ url('storage/app/uploads/placeholder.jpg') }}"
                                                                            alt="no image">
                                                                    @endif
                                                                </div>
                                                            </div>
                                                        @endforeach
                                                        @endif


                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="tableButtonSetting">
                                                        <div class="btn-group dropstart">
                                                            <a href="#" class="dropdown-toggle" type="button"
                                                                data-bs-toggle="dropdown" aria-expanded="false">
                                                                <img src="{{ asset('public/assets/icons/DotsThreeOutline.svg') }}"
                                                                    alt="">
                                                            </a>
                                                            <ul class="dropdown-menu tosetWidh-Dropdown">
                                                                <li><a href="{{ route('admin.groupView', ['id' => $item->id]) }}"
                                                                        class="dropdown-item  togivepaddingLeft"
                                                                        >View</a>
                                                                </li>
                                                                <li><a class="dropdown-item  togivepaddingLeft"
                                                                        href="javascript:void(0)"
                                                                        onclick="del_group('{{ $item->id }}')"
                                                                        data-bs-toggle="modal"
                                                                        type="button">Delete</a></li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        @endforeach

                                    </tbody>

                                </table>

                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</div>

{{-- worker group --}}

<div class="modal fade CreateGroup" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title group_title" id="exampleModalLabel">Create Group</h5>
               <button style="border:none !important;" type="button" class="btn-secondary " data-bs-dismiss="modal" aria-label="Close"> <i class="fa-regular fa-x"></i> </button>
            </div>
            <div class="modal-body">
                <form action="{{ route('admin.create_group') }}" method="POST" id="add_worker">
                    @csrf
                    <div class="row">
                        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12">
                            <div class="mb-3">
                                <div>
                                    <label class="group_label">Group Manager</label>
                                </div>
                                <select name="group_manager[]"
                                    class="form-select w-100 js-example-basic-multiple-limit"
                                    data-minimum-results-for-search="Infinity" multiple="multiple">
                                    @foreach ($grp_manager as $item)
                                        <option value="{{ $item->id }}">
                                            {{ isset($item->f_name) && isset($item->l_name) ? $item->f_name . ' ' . $item->l_name : '-' }}
                                        </option>
                                    @endforeach

                                </select>
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-12 col-lg-6 col-xl-6 col-xxl-6 col-12">
                            <div class="mb-3">
                                <label class="group_label">Group Name</label>
                                <input class="form-control w-100" name="group_name"
                                    placeholder="Please enter your group name" type="text">
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-12 col-lg-6 col-xl-6 col-xxl-6 col-12">
                            <div class="mb-3">
                                <label class="group_label">Email Address</label>
                                <input class="form-control w-100" name="email"
                                    placeholder="Please enter your email address" type="email">
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-12 col-lg-6 col-xl-6 col-xxl-6 col-12">
                            <div class="mb-3">
                                <label class="group_label">Address</label>
                                <input type="text" class="form-control w-100" name="address"
                                    placeholder="Please enter your address">
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-12 col-lg-6 col-xl-6 col-xxl-6 col-12">
                            <div class="mb-3">
                                <label class="group_label">Main Phone</label>
                                <input type="number" class="form-control w-100" name="phone"
                                    placeholder="Please enter your number">
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12">
                            <div class="mb-3">
                                <div>
                                    <label class="group_label">Group Members</label>
                                </div>
                                <select name="group_members[]"
                                    class="form-select w-100 js-example-basic-multiple-limit"
                                    data-minimum-results-for-search="Infinity" multiple="multiple">
                                    @foreach ($workers as $item)
                                        <option value="{{ $item->id }}">
                                            {{ isset($item->f_name) && isset($item->l_name) ? $item->f_name . ' ' . $item->l_name : '-' }}
                                        </option>
                                    @endforeach
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12">
                            <div class="mb-3">
                                <label class="userview_label">Comments</label>
                                <textarea name="comments" type="text" class="form-control w-100 form_textarea"
                                    placeholder="Enter some description..."></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" id="add_worker_btn" class="btn btn-secondary"
                            data-bs-dismiss="modal">Create</button>
                    </div>
                </form>

            </div>
        </div>
    </div>
</div>

{{-- Edit group --}}

<div class="modal fade" id="EditGroup" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title group_title" id="exampleModalLabel">Update Group</h5>
               <button style="border:none !important;" type="button" class="btn-secondary " data-bs-dismiss="modal" aria-label="Close"> <i class="fa-regular fa-x"></i> </button>
            </div>
            <div class="modal-body">
                <form action="{{ route('admin.update_group') }}" method="POST" id="add_worker">
                    @csrf
                    <div class="row">
                        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12">
                            <div class="mb-3">
                                <div>
                                    <label class="group_label">Group Manager</label>
                                </div>
                                <select id="group_manager" name="group_manager[]"
                                    class="form-select w-100 js-example-basic-multiple-limit"
                                    data-minimum-results-for-search="Infinity" multiple="multiple">
                                    <option value="" selected>
                                    </option>

                                </select>
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-12 col-lg-6 col-xl-6 col-xxl-6 col-12">
                            <div class="mb-3">
                                <label class="group_label">Group Name</label>
                                <input class="form-control w-100" id="group_name" name="group_name"
                                    placeholder="Please enter your group name" type="text">
                                <input type="hidden" name="group_id" id="group_id">
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-12 col-lg-6 col-xl-6 col-xxl-6 col-12">
                            <div class="mb-3">
                                <label class="group_label">Email Address</label>
                                <input class="form-control w-100" id="email" name="email"
                                    placeholder="Please enter your email address" type="email">
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-12 col-lg-6 col-xl-6 col-xxl-6 col-12">
                            <div class="mb-3">
                                <label class="group_label">Address</label>
                                <input type="text" class="form-control w-100" id="address" name="address"
                                    placeholder="Please enter your address">
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-12 col-lg-6 col-xl-6 col-xxl-6 col-12">
                            <div class="mb-3">
                                <label class="group_label">Main Phone</label>
                                <input type="number" class="form-control w-100" id="phone" name="phone"
                                    placeholder="Please enter your number">
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12">
                            <div class="mb-3">
                                <div>
                                    <label class="group_label">Group Members</label>
                                </div>
                                <select name="group_members[]" id="group_members"
                                    class="form-select w-100 js-example-basic-multiple-limit"
                                    data-minimum-results-for-search="Infinity" multiple="multiple">
                                    <option value=""></option>
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12">
                            <div class="mb-3">
                                <label class="userview_label">Comments</label>
                                <textarea name="comments" id="comments" type="text" class="form-control w-100 form_textarea"
                                    placeholder="Enter some description..."></textarea>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" id="add_worker_btn" class="btn btn-secondary"
                            data-bs-dismiss="modal">Create</button>
                    </div>
                </form>

            </div>
        </div>
    </div>
</div>


<!-- group Delete Modal Start -->

<div class="modal fade" id="group_del" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <form action="{{ route('admin.del_group') }}" method="POST">
            @csrf
            <div class="modal-content">
                <div class="modal-header">
                    <input type="hidden" name="del_group_id" id="del_group_id">
                    <h5 class="modal-title" id="exampleModalLabel">Delete Confirmation</h5>
                   <button style="border:none !important;" type="button" class="btn-secondary " data-bs-dismiss="modal" aria-label="Close"> <i class="fa-regular fa-x"></i> </button>
                </div>
                <div class="modal-body">
                    <p>Are you sure want to delete?</p>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Yes</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div>
            </div>
        </form>
    </div>
</div>
<!--group Delete Modal End -->

<script>
    function Edit_group(id) {
        console.log(id)
        let grp_manager = $('#group_manager');
        let grp_name = $('#group_name');
        let email = $('#email');
        let address = $('#address');
        let phone = $('#phone');
        let grp_member = $('#group_members');
        let comments = $('#comments');
        // console.log(group_manager, group_name, email, address, phone, group_members, comments)

        $.ajax({
            url: "{{ route('admin.edit_group') }}",
            type: "POST",
            data: {
                group_id: id,
                _token: "{{ csrf_token() }}"
            },
            success: function(res) {
                console.log(res);
                res.worker.forEach(e => {
                    grp_member.append("<option value=" + e.id + ">" + e.f_name + e.l_name +
                        "</option>");

                });
                res.group_managers.forEach(e => {
                    grp_manager.append("<option value=" + e.id + ">" + e.f_name + e.l_name +
                        "</option>");

                });
                grp_name.val(res.group_data.group_name)
                email.val(res.group_data.email)
                address.val(res.group_data.address)
                phone.val(res.group_data.phone)
                grp_member.val(res.group_data.grp_member)
                comments.val(res.group_data.comments)
                $('#group_id').val(id);
                $('#EditGroup').modal('show');
            }
        })
    }

    $(document).ready(function() {
        // Event listener for when the "Create" button is clicked
        $('#add_worker_btn').on('click', function(event) {
            // Prevent the default form submission
            event.preventDefault();

            // Serialize form data
            var formData = $('#add_worker').serialize();

            // Get the IDs of selected workers from the select box
            var selectedWorkers = $('#group_members').val() || [];

            // Get the IDs of all workers in the select box
            var allWorkers = [];
            $('#group_members option').each(function() {
                allWorkers.push($(this).val());
            });

            // Find deselected workers (those not in the selectedWorkers array)
            var deselectedWorkers = allWorkers.filter(function(workerId) {
                return !selectedWorkers.includes(workerId);
            });

            // Append deselected worker IDs to the form data
            deselectedWorkers.forEach(function(workerId) {
                formData += '&deselected_workers[]=' + workerId;
            });

            // Get the CSRF token value from the page meta tag
            var csrfToken = $('meta[name="csrf-token"]').attr('content');

            // Add the CSRF token to the headers
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': csrfToken
                }
            });

            // Send Ajax request to update the group
            $.ajax({
                url: "{{ route('admin.create_group') }}",
                method: 'POST',
                data: formData,
                success: function(response) {
                    // Handle success
                    console.log(response); // Log the response for debugging
                    // Close the modal after successful update
                    $('#EditGroup').modal('hide');
                    // Refresh the page after successful update
                    window.location.reload();
                },
                error: function(xhr, status, error) {
                    // Handle error
                    console.error(xhr.responseText); // Log the error response for debugging
                    // You can display an error message to the user if needed
                }
            });
        });
    });



    function del_group(id) {
        console.log(id);
        $('#del_group_id').val(id)
        $('#group_del').modal('show');

    }
</script>

@include('superadmin.footer')
