<?php
$activebar = "tasks";
?>
@include('superadmin.header')
    <div class="iq-top-navbar py-2 rtl-iq-top-navbar ">
        <div class="iq-navbar-custom">
            <nav class="navbar navbar-expand-lg navbar-light p-0 toSetNavBarAll w-100">
                <div class="iq-navbar-logo d-flex align-items-center justify-content-between">
                    <i class="ri-menu-line wrapper-menu"></i>
                    <!-- Mobile Logo -->
                </div>
                <div class="iq-search-bar device-search">
                    <h4 class="main_content_title">Task Management</h4>
                </div>
                @include('superadmin/tooltip')
                <div class="d-xxl-none d-xl-none d-lg-none d-md-block d-sm-block d-block">
                    <ul class="align-items-center d-flex gap-4 list-unstyled text-decoration-none m-0">
                        <li>
                            <button class="nav-AddNew-Button btn btn-primary" type="button" data-bs-toggle="modal" data-bs-target="#">Create Task</button>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
    </div>



    <div class="content-page rtl-page">
        <div class="container-fluid mt-4">
            <div class="row">
                <div class="col-12">
                    <div class="row mt-4">
                        <div class="col-12 ">
                            <div class="bg-white p-3 index-TablePage">
                                <div class="mb-3">
                                    <div class="align-items-center d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column justify-content-between toSetFilterIcon">
                                        <h4 class="file-Heading">
                                            All Tasks
                                        </h4>
                                        {{-- <div class="TogiveFullWidth d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column gap-2 mt-xxl-0 mt-xl-0 mt-lg-0 mt-md-0 mt-sm-3 mt-3">
                                            <select name="" class="js-select2" data-minimum-results-for-search="Infinity" >
                                                <option value="All Task">All Task</option>
                                                <option value="Staff Task">Staff Task</option>
                                                <option value="My Task">My Task</option>
                                            </select>

                                        </div> --}}
                                    </div>
                                </div>
                                <div class="table-responsive">
                                    <table id="" class="dataTable table-responsive stripe w-100 ">
                                        <thead>
                                        <tr>
                                           <th>  S.No </th>
                                            <th>Date Created</th>
                                            <th class="text-start">Task Id</th>
                                            <th>Task Tittle</th>
                                            <th>Assigned To</th>
                                            <th>Start on</th>
                                            <th>End on</th>
                                            <th>Status</th>
                                            <th></th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                            @foreach ($tasks as $k=>$item)
                                            <tr>
                                                <td>
                                                   {{$k+1}}
                                                </td>
                                                <td>
                                                    <p class="p-0 m-0 table-MainHeading">
                                                        {{isset($item->created_at) ? $item->created_at : '-'}}
                                                    </p>
                                                    <p class="p-0 m-0 table-SubHeading">
                                                        03:45 pm
                                                    </p>
                                                </td>
                                                <td>
                                                    <p class="p-0 m-0 table-MainHeading">
                                                        {{isset($item->task_id) ? $item->task_id : '-'}}
                                                    </p>
                                                </td>
                                                <td>
                                                    <p class="p-0 m-0 table-MainHeading">
                                                        {{isset($item->task_name) ? $item->task_name : '-'}}
                                                    </p>
                                                </td>
                                                <td>
                                                    <p class="p-0 m-0 table-MainHeading">
                                                        @if(!empty($item->users))
                                                        @foreach ($item->users as $worker)
                                                        <span class="badge badge-inactive">{{isset($worker->f_name) ? $worker->f_name : ''}}</span>
                                                        @endforeach
                                                        @endif

                                                    </p>
                                                </td>
                                                @php
                                                $timestamp = (strtotime($item->start_datetime));
                                                $date = date('j.n.Y', $timestamp);
                                                $time = date('H:i:s', $timestamp);
                                                @endphp
                                                <td>
                                                    <p class="p-0 m-0 table-MainHeading">
                                                        {{$date}}
                                                    </p>
                                                    <p class="p-0 m-0 table-SubHeading">
                                                        {{$time}}
                                                    </p>
                                                </td>
                                                @php
                                                $timestamp = (strtotime($item->end_datetime));
                                                $date = date('j.n.Y', $timestamp);
                                                $time = date('H:i:s', $timestamp);
                                                @endphp
                                                <td>
                                                    <p class="p-0 m-0 table-MainHeading">
                                                        {{$date}}
                                                    </p>
                                                    <p class="p-0 m-0 table-SubHeading">
                                                        {{$time}}
                                                    </p>
                                                </td>
                                                <td>
                                                    <select name="status" onchange="changeStatusFunc(event , '{{$item->id}}')" id="status-{{ $k }}" class="js-select2 tosetitas status-select-{{ $k }}">
                                                        <option value="Select Option" disabled>Select Option</option>
                                                        <option value="Approved" {{ isset($item->status) && $item->status == 'Approved' ? 'selected' : '' }}>Approved</option>
                                                        <option value="Submitted" {{ isset($item->status) && $item->status == 'Submitted' ? 'selected' : '' }}>Submitted</option>
                                                        <option value="Active" {{ isset($item->status) && $item->status == 'Active' ? 'selected' : '' }}>Active</option>
                                                        <option value="Expired" {{ isset($item->status) && $item->status == 'Expired' ? 'selected' : '' }}>Expired</option>
                                                        <option value="Completed" {{ isset($item->status) && $item->status == 'Completed' ? 'selected' : '' }}>Completed</option>
                                                    </select>
                                                </td>
                                                <td>
                                                    <div class="tableButtonSetting">
                                                        <div class="btn-group dropstart">
                                                            <a href="#" class="dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false" >
                                                                <img src="{{asset('public/assets/icons/DotsThreeOutline.svg')}}" alt="">
                                                            </a>
                                                            <ul class="dropdown-menu tosetWidh-Dropdown">
                                                                <li><a class="dropdown-item  togivepaddingLeft" href="{{route('admin.taskView' , ['id' => $item->id])}}" onclick="read_task_msg('{{ $item->id}}' , '{{Auth::id()}}')">View</a></li>
                                                                <li><a class="dropdown-item  togivepaddingLeft" href="javascript:void(0)" onclick="Del_task('{{$item->id}}')" data-bs-toggle="modal" data-bs-target="#task_delete_modal" type="button">Delete</a></li>

                                                            </ul>
                                                        </div>
                                                    </div>
                                                    @if(isset($item->chats) && count($item->chats) > 0)
                                                    <a href="{{route('admin.taskView' , ['id' => $item->id])}}" onclick="read_task_msg('{{ $item->id }}', '{{Auth::id()}}')" class="text-danger">
                                                        {{ count($item->chats) }}
                                                    </a>
                                                    @endif
                                                </td>
                                            </tr>
                                            @endforeach
                                        </tbody>

                                    </table>

                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

@include('superadmin.footer')


<script src="{{ asset('public/assets/js/select2.min.js') }}"></script>
<script>
   $(document).ready(function() {
       $('select.js-select2').select2({
           selectOnClose: true
       });
   });
</script>
<script>

    setInterval(() => {
        get_tasks();
    }, 2000);
    function get_tasks(){
    $.ajax({
        url  : "{{route('admin.get_tasks')}}",
        type : "POST",
        data:{
            _token:'{{ csrf_token() }}',
        },
        success : function(res){
            console.log(res);
            if(res.data) {
                $('#appendAllTaks').html(res.data);
                setTimeout(() => {
                    $('select.js-select2').each(function() {
                        $(this).select2({
                            selectOnClose: true
                        });
                    });

                    applyColor();
                }, 2000);
            }

        }
    })
}
get_tasks();


function read_task_msg(id , user_id){
        console.log(id);
        $.ajax({
            url : "{{route('admin.read_tasks_msg')}}",
            method : "POST",
            data : {
                read_id : id,
                user_id : user_id,
                _token : "{{csrf_token()}}",
            },
            success : function(res){
                console.log(res)
                Show_task_msg()


            }
        })
    }
</script>
