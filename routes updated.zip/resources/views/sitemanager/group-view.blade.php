<?php
$activebar = 'groups';
?>



@include('sitemanager.header')
<style>
    .select2-container {
        width: 100% !important;
    }

</style>
<div class="iq-top-navbar py-2 rtl-iq-top-navbar ">
    <div class="iq-navbar-custom">
        <nav class="navbar navbar-expand-lg navbar-light p-0 toSetNavBarAll w-100">
            <div class="iq-navbar-logo d-flex align-items-center justify-content-between">
                <i class="ri-menu-line wrapper-menu"></i>
                <!-- Mobile Logo -->
            </div>
            <div class="iq-search-bar device-search">
                <h4 class="main_content_title">Group View</h4>
            </div>
            @include('sitemanager.tooltip')
        </nav>
    </div>
</div>



<div class="content-page rtl-page">
    <div class="container-fluid mt-4">
        <div class="row">
                <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12">
                    <div class="mt-4">
                        <div class="toSetSettingsBackground">
                            <form action="{{ route('sitemanager.group_info_update') }}" method="POST">
                            <div class="row">
                                    @csrf
                                <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12 sections_change">
                                    <div class="mb-4 d-flex justify-content-between align-items-center">
                                        <h3 class="userview_head3">Group Details</h3>
                                        <button type="submit" class="btn btn-primary">Update </button>
                                    </div>
                                </div>
                                <div class="col-sm-12 col-md-12 col-lg-6 col-xl-6 col-xxl-6 col-12">
                                    <div class="row">
                                        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12">
                                            <div class="mb-3">
                                                <label class="userview_label">Group Name</label>
                                                <input type="hidden" name="group_id" value="{{ isset($group_data[0]->id) ? $group_data[0]->id : '' }}">
                                                <input type="text" name="group_name"
                                                    value="{{ isset($group_data[0]->group_name) ? $group_data[0]->group_name : '' }}"
                                                    class="form-control w-100"
                                                    placeholder="Please enter your group name">
                                            </div>
                                        </div>
                                        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12">
                                            <div class="mb-3">
                                                <label class="userview_label">Address</label>
                                                <input type="text" name="address" class="form-control w-100"
                                                    value="{{ isset($group_data[0]->address) ? $group_data[0]->address : '' }}"
                                                    placeholder="Please enter your address">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-12 col-md-12 col-lg-6 col-xl-6 col-xxl-6 col-12">
                                    <div class="mb-3">
                                        <label class="userview_label">Email Address</label>
                                        <input type="text" name="email" class="form-control w-100"
                                            value="{{ isset($group_data[0]->email) ? $group_data[0]->email : '' }}"
                                            placeholder="Please enter your email">
                                    </div>
                                    <div class="mb-3">
                                        <label class="userview_label">Main Phone</label>
                                        <input type="number" name="phone" class="form-control w-100"
                                            value="{{ isset($group_data[0]->phone) ? $group_data[0]->phone : '' }}"
                                            placeholder="Please enter your number">
                                    </div>
                                </div>
                            </div>

                            <div class="row mt-2 mb-2 auto_row">
                                <div class="col-12 auto_pad">
                                    <div class="mb-4">
                                        <label class="userview_label">Comments</label>
                                        <textarea type="text" name="comments" class="form-control w-100 form_textarea"
                                             placeholder="Please enter some comments">{{ isset($group_data[0]->comments) ? $group_data[0]->comments : '' }}</textarea>
                                    </div>
                                </div>
                            </div>
                        </form>
                            <div class="row">
                                <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12 sections_change">
                                    <div class="mb-4 d-flex align-items-center justify-content-between">
                                        <div class="d-flex align-items-center gap-3">
                                            <h3 class="userview_head3">Group Members</h3>
                                            <button type="button" class="btn btn-secondary mx-2" data-bs-target=".EditGroup"
                                                data-bs-toggle="modal"><svg width="18" height="18"
                                                    viewBox="0 0 18 18" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M2.8125 9H15.1875M9 2.8125V15.1875" stroke-width="1.5"
                                                        stroke-linecap="round" stroke-linejoin="round"></path>
                                                </svg></button>
                                        </div>
                                        <div class="d-flex align-items-center gap-3">
                                            <h3 class="userview_head3">Group Managers</h3>
                                            <button type="button" class="btn btn-secondary" data-bs-target=".EditMAnagers"
                                                data-bs-toggle="modal"><svg width="18" height="18"
                                                    viewBox="0 0 18 18" fill="none"
                                                    xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M2.8125 9H15.1875M9 2.8125V15.1875" stroke-width="1.5"
                                                        stroke-linecap="round" stroke-linejoin="round"></path>
                                                </svg></button>
                                        </div>
                                        <!-- <div class="d-flex align-items-center gap-3">
                                            <button type="button" class="btn btn-secondary">Sort by <img alt=""
                                                    src="assets/icons/f_sort.svg"></button>
                                            <div class="position-relative">
                                                <input type="search" class="form-control w-100 search_input"
                                                    placeholder="Search">
                                                <img alt="" src="assets/icons/f_search.svg"
                                                    class="position-absolute search_svg">
                                            </div>
                                        </div> -->
                                    </div>
                                </div>

                                @if (!empty($group_data))
                                    @foreach ($group_data as $item)
                                        @if (!empty($item))
                                            @foreach ($item->members as $users)
                                                <div class="col-sm-6 col-md-6 col-lg-4 col-xl-4 col-xxl-4 col-12">
                                                    <div class="card member-card">
                                                        <div class="card-body member-card-body">
                                                            <div
                                                                class="h-100 w-100 d-flex justify-content-center align-items-center mb-3">
                                                                @if (!empty($users->image))
                                                                    <img src="{{ url('storage/app/uploads/' . $users->image) }}"
                                                                        class="member-image">
                                                                @else
                                                                    <img src="{{ url('storage/app/uploads/placeholder.jpg') }}"
                                                                        class="member-image">
                                                                @endif
                                                            </div>
                                                            <div class="mb-2">
                                                                <h5 class="member_name text-center">
                                                                    {{ isset($users->f_name) && isset($users->l_name) ? $users->f_name . ' ' . $users->l_name : '-' }}
                                                                </h5>
                                                                <h6 class="member_type text-center">Worker</h6>
                                                            </div>
                                                            <div class="mb-2 d-flex justify-content-center gap-3">
                                                                <a class="btn btn-secondary member_link mx-2"
                                                                    href="{{ route('sitemanager.chat') }}">Chat</a>
                                                                <a class="btn btn-secondary member_link mx-2"
                                                                    href="{{route('sitemanager.EditEmployee', ['id' => $users->id])}}">View</a>
                                                                    <a class="btn btn-secondary member_link mx-2" onclick="del_user('{{ $users->id }}')"  href="javascript:void(0)">Remove</a>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            @endforeach
                                            @foreach ($item->managers as $users)
                                                <div class="col-sm-6 col-md-6 col-lg-4 col-xl-4 col-xxl-4 col-12">
                                                    <div class="card member-card">
                                                        <div class="card-body member-card-body">
                                                            <div
                                                                class="h-100 w-100 d-flex justify-content-center align-items-center mb-3">
                                                                @if (!empty($users->image))
                                                                    <img src="{{ url('storage/app/uploads/' . $users->image) }}"
                                                                        class="member-image">
                                                                @else
                                                                    <img src="{{ url('storage/app/uploads/placeholder.jpg') }}"
                                                                        class="member-image">
                                                                @endif
                                                            </div>
                                                            <div class="mb-2">
                                                                <h5 class="member_name text-center">
                                                                    {{ isset($users->f_name) && isset($users->l_name) ? $users->f_name . ' ' . $users->l_name : '-' }}
                                                                </h5>
                                                                <h6 class="member_type text-center">{{isset($users->role) == 'groupmanager' ? 'Group Manager' : ''}}</h6>
                                                            </div>
                                                            <div class="mb-2 d-flex justify-content-center gap-3">
                                                                <a class="btn btn-secondary member_link mx-2"
                                                                    href="{{ route('sitemanager.chat') }}">Chat</a>
                                                                <a class="btn btn-secondary member_link mx-2"
                                                                    href="{{route('sitemanager.EditEmployee', ['id' => $users->id])}}">View</a>
                                                                    <a class="btn btn-secondary member_link mx-2" onclick="del_manager('{{ $users->id }}')"  href="javascript:void(0)">Remove</a>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            @endforeach
                                        @endif
                                    @endforeach
                                @endif
                            </div>
                        </div>

                    </div>
                </div>
        </div>
    </div>
</div>

{{-- edit group managers modal start --}}
{{-- <div class="modal fade CreateGroup2" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-md">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title group_title" id="exampleModalLabel">Edit Managers</h5>
                   <button style="border:none !important;" type="button" class="btn-secondary " data-bs-dismiss="modal" aria-label="Close"> <i class="fa-regular fa-x"></i> </button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12">
                            <div class="mb-3">
                                <div>
                                    <label class="group_label">Group Managers</label>
                                </div>
                                <select class="form-select w-100 js-example-basic-multiple-limit w-100"
                                    data-minimum-results-for-search="Infinity" multiple="multiple">
                                    @if (!empty($group_data))
                                    @foreach ($group_data as $item)
                                    @if (!empty($item))
                                    @foreach ($item->managers as $managers)
                                        <option value="{{$managers->id}}">{{ isset($managers->f_name) && isset($managers->l_name) ? $managers->f_name . ' ' . $managers->l_name : '-' }}</option>
                                    @endforeach
                                    @endif
                                    @endforeach
                                    @endif
                                </select>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Update</button>
                </div>
            </div>
        </div>
    </div> --}}
{{-- edit group managers modal end --}}

<div class="modal fade EditGroup" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-md">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title group_title" id="exampleModalLabel">Add Members</h5>
               <button style="border:none !important;" type="button" class="btn-secondary " data-bs-dismiss="modal" aria-label="Close"> <i class="fa-regular fa-x"></i> </button>
            </div>
            <div class="modal-body">
                <form id="add_worker_form">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="mb-3">
                                <div>
                                    <label class="group_label">Members</label>
                                </div>
                                <input type="hidden"
                                    value="{{ isset($group_data[0]->id) ? $group_data[0]->id : '' }}"
                                    name="group_id">
                                <select name="group_members[]" id="group_members"
                                    class="form-select w-100 js-example-basic-multiple-limit"
                                     multiple="multiple">
                                    @if (!empty($group_data))
                                    @foreach ($group_data as $items)
                                        @foreach ($items->other_members as $item)
                                        <option value="{{ $item->id }}">
                                            {{ isset($item->f_name) && isset($item->l_name) ? $item->f_name . ' ' . $item->l_name : '-' }}
                                        </option>
                                        @endforeach
                                    @endforeach
                                    @endif
                                </select>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" id="add_member_btn" class="btn btn-primary">Add</button>
            </div>
        </div>
    </div>
</div>

{{-- group managers edit modal --}}

<div class="modal fade EditMAnagers" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-md">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title group_title" id="exampleModalLabel">Add Managers</h5>
               <button style="border:none !important;" type="button" class="btn-secondary " data-bs-dismiss="modal" aria-label="Close"> <i class="fa-regular fa-x"></i> </button>
            </div>
            <div class="modal-body">
                <form id="add_manager_form">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="mb-3">
                                <div>
                                    <label class="group_label">Managers</label>
                                </div>
                                <input type="hidden"
                                    value="{{ isset($group_data[0]->id) ? $group_data[0]->id : '' }}"
                                    name="group_id">
                                    <select name="group_managers[]" id="group_managers"
                                    class="form-select w-100 js-example-basic-multiple-limit"
                                    data-minimum-results-for-search="Infinity" multiple="multiple">
                                @if ($group_managers->isNotEmpty())
                                    @foreach ($group_managers as $manager)
                                        <option value="{{ $manager->id }}">
                                            {{ isset($manager->f_name) && isset($manager->l_name) ? $manager->f_name . ' ' . $manager->l_name : '-' }}
                                            {{ isset($manager->role) ? $manager->role : '-' }}
                                        </option>
                                    @endforeach
                                @endif
                            </select>


                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="button" id="add_manager_btn" class="btn btn-primary">Add</button>
            </div>
        </div>
    </div>
</div>


  <!-- user Delete Modal Start -->

  <div class="modal fade" id="user_del" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <form action="{{route('sitemanager.delete_user')}}" method="POST">
            @csrf
            <div class="modal-content">
                <div class="modal-header">
                    <input type="hidden" name="del_user_id" id="del_user_id">
                    <input type="hidden" name="group_id" id="group_id" value="{{ isset($group_data[0]->id ) ? $group_data[0]->id : ''}}">
                    <h5 class="modal-title" id="exampleModalLabel">Delete Confirmation</h5>
                   <button style="border:none !important;" type="button" class="btn-secondary " data-bs-dismiss="modal" aria-label="Close"> <i class="fa-regular fa-x"></i> </button>
                </div>
                <div class="modal-body">
                    <p>Are you sure want to delete?</p>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Yes</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div>
            </div>
        </form>
    </div>
</div>
<!--user Delete Modal End -->


{{-- group manager remove modal --}}

<div class="modal fade" id="manager_del" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <form action="{{route('sitemanager.delete_manager')}}" method="POST">
            @csrf
            <div class="modal-content">
                <div class="modal-header">
                    <input type="hidden" name="del_manager_id" id="del_manager_id">
                    <input type="hidden" name="group_id" id="group_id" value="{{ isset($group_data[0]->id ) ? $group_data[0]->id : ''}}">
                    <h5 class="modal-title" id="exampleModalLabel">Delete Confirmation</h5>
                   <button style="border:none !important;" type="button" class="btn-secondary " data-bs-dismiss="modal" aria-label="Close"> <i class="fa-regular fa-x"></i> </button>
                </div>
                <div class="modal-body">
                    <p>Are you sure want to delete?</p>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Yes</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div>
            </div>
        </form>
    </div>
</div>

<script>
    //     function Edit_group(id) {
    //        console.log(id)
    //        $.ajax({
    //            url: "{{ route('groupmanager.edit_group') }}",
    //            type: "POST",
    //            data: {
    //                group_id: id,
    //                _token: "{{ csrf_token() }}"
    //            },
    //            success: function(res) {
    //                console.log(res);


    //                $('.EditGroup').modal('show');
    //              }
    //        })
    //    }


    function del_user(id){
        console.log(id);
        $('#del_user_id').val(id)
        $('#group_id').val()
        $('#user_del').modal('show');

    }

    function del_manager(id){
        console.log(id);
        $('#del_manager_id').val(id)
        $('#group_id').val()
        $('#manager_del').modal('show');

    }

    {{-- group managers edit --}}

$(document).ready(function() {
    $('#add_manager_btn').on('click', function() {
        var formData = $('#add_manager_form').serialize();
        console.log(formData);
        var selectedWorkers = $('#group_managers').val();

        var allWorkers = [];
        $('#group_managers option').each(function() {
            allWorkers.push($(this).val());
        });

        var deselectedWorkers = allWorkers.filter(function(workerId) {
            return !selectedWorkers.includes(workerId);
        });

        deselectedWorkers.forEach(function(workerId) {
            formData += '&deselected_workers[]=' + workerId;
        });

        var csrfToken = $('meta[name="csrf-token"]').attr('content');

        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': csrfToken
            }
        });

        $.ajax({
            url: "{{ route('sitemanager.update_group_managers') }}",
            method: 'POST',
            data: formData,
            success: function(response) {
                console.log(response);
                $('.modal').modal('hide');
                  window.location.reload();
            },
            error: function(xhr, status, error) {
                console.error(xhr.responseText);
            }
        });
    });
});


    $(document).ready(function() {
        $('#add_member_btn').on('click', function() {
            var formData = $('#add_worker_form').serialize();
            console.log(formData);
            var selectedWorkers = $('#group_members').val();

            var allWorkers = [];
            $('#group_members option').each(function() {
                allWorkers.push($(this).val());
            });

            var deselectedWorkers = allWorkers.filter(function(workerId) {
                return !selectedWorkers.includes(workerId);
            });

            deselectedWorkers.forEach(function(workerId) {
                formData += '&deselected_workers[]=' + workerId;
            });

            var csrfToken = $('meta[name="csrf-token"]').attr('content');

            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': csrfToken
                }
            });

            $.ajax({
                url: "{{ route('sitemanager.update_group_workers') }}",
                method: 'POST',
                data: formData,
                success: function(response) {
                    console.log(response);
                    $('.modal').modal('hide');
                      window.location.reload();
                },
                error: function(xhr, status, error) {
                    console.error(xhr.responseText);
                }
            });
        });
    });
</script>



@include('sitemanager.footer')
