<?php
$activebar = "users";
?>



@include('sitemanager.header')
<style>
    .js-select2 {
        border: 1px solid #AFBACA;
    padding: 10px 14px !important;
    border-radius: 8px !important;
    background-color: transparent;
    box-shadow: 0px 1px 2px 1px rgba(16, 24, 40, 0.05) !important;
    width: 100% !important;
    width: 100% !important;
    }
</style>
    <div class="iq-top-navbar py-2 rtl-iq-top-navbar ">
        <div class="iq-navbar-custom">
            <nav class="navbar navbar-expand-lg navbar-light p-0 toSetNavBarAll w-100">
                <div class="iq-navbar-logo d-flex align-items-center justify-content-between">
                    <i class="ri-menu-line wrapper-menu"></i>
                    <!-- Mobile Logo -->
                </div>
                <div class="iq-search-bar device-search">
                    <h4 class="main_content_title">User View</h4>
                </div>
                @include('sitemanager.tooltip')
            </nav>
        </div>
    </div>



    <form action="{{ route('sitemanager.UpdateEmployee') }}" method="POST" enctype="multipart/form-data">
        @csrf
        <div class="content-page rtl-page">
            <div class="container-fluid mt-4">
                <div class="row">
                    <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12">
                        <div class="mt-4">
                            <div class="toSetSettingsBackground">
                                <div class="row">
                                    <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12 sections_change">
                                        <div class="mb-4 d-flex align-items-center justify-content-between">
                                            <h3 class="userview_head3">Member Details</h3>
                                            <button class="btn btn-primary"> Update Profile </button>
                                        </div>
                                    </div>
                                    <div class="col-sm-12 col-md-4 col-lg-3 col-xl-3 col-xxl-3 col-12">
                                        <div
                                            class="d-flex align-items-center flex-column justify-content-center position-relative h-100">
                                            <div class="d-flex ">
                                                <div class="avatar-upload">
                                                    <div class="avatar-edit">
                                                        <label for="imageUpload"></label>
                                                    </div>
                                                    <div class="avatar-preview">
                                                        <div style="background-image: url('{{ url('storage/app/uploads/' . $user_data->image) }}')"
                                                            class="imagePreview" id="imagePreview" name="files">
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="d-flex align-items-center position-absolute">
                                                <label for="imageUpload" class="upload_picture">
                                                    <div
                                                        class="avatar-edit d-flex justify-content-center align-items-center">
                                                        <i class="fi fi-rr-upload mt-1"></i>
                                                        Upload Picture
                                                    </div>
                                                </label>
                                                <input type="file" name="image" id="imageUpload"
                                                    accept=".png, .jpg, .jpeg" style="display: none;">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-12 col-md-8 col-lg-4 col-xl-4 col-xxl-4 col-12">
                                        <div class="row">
                                            <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12">
                                                <div class="mb-3">
                                                    <label class="userview_label">First Name</label>
                                                    <input type="text" class="form-control w-100" name="f_name"
                                                        value="{{ isset($user_data->f_name) ? $user_data->f_name : '-' }}"
                                                        placeholder="Please enter your first name">
                                                    <input type="hidden" value="{{ $user_data->id }}" name="user_id">
                                                </div>
                                            </div>
                                            <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12">
                                                <div class="mb-3">
                                                    <label class="userview_label">Last Name</label>
                                                    <input type="text" class="form-control w-100" name="l_name"
                                                        value="{{ isset($user_data->l_name) ? $user_data->l_name : '-' }}"
                                                        placeholder="Please enter your last name">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-12 col-md-12 col-lg-5 col-xl-5 col-xxl-5 col-12">
                                        <div class="mb-3">
                                            <label class="userview_label">Email Address</label>
                                            <input type="text" class="form-control w-100" name="email"
                                                value="{{ isset($user_data->email) ? $user_data->email : '-' }}"
                                                placeholder="Please enter your email">
                                        </div>
                                        <div class="mb-3">
                                            <label class="userview_label">Main Phone</label>
                                            <input type="number" class="form-control w-100" name="phone"
                                                value="{{ isset($user_data->phone) ? $user_data->phone : '-' }}"
                                                placeholder="Please enter your number">
                                        </div>
                                    </div>
                                </div>
                                <div class="row mt-2 mb-2 auto_row">
                                    <div class="col-sm-12 col-md-12 col-lg-6 col-xl-6 col-xxl-6 col-12 auto_pad">
                                        <div class="row">
                                            <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12">
                                                <div class="mb-3">
                                                    <div>
                                                        <label class="userview_label">Residential Address</label>
                                                    </div>
                                                    <input type="text" class="form-control w-100" name="address"
                                                        value="{{ isset($user_data->address) ? $user_data->address : '-' }}"
                                                        placeholder="Please enter your residential address">
                                                </div>
                                            </div>
                                            <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12">
                                                <div class="mb-3">
                                                    <label class="userview_label">Training Level</label>
                                                    <input type="text" class="form-control w-100" name="training_level"
                                                        value="{{ isset($user_data->training_level) ? $user_data->training_level : '-' }}"
                                                        placeholder="Please enter your training level" value="Basic Level">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-12 col-md-12 col-lg-6 col-xl-6 col-xxl-6 col-12 auto_pad">
                                        <div class="row">
                                            <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12">
                                                <div class="mb-3">
                                                    <div class="mb-3">
                                                        <div>
                                                            <label class="userview_label">Role</label>
                                                        </div>
                                                        <select class="js-select2"
                                                            data-minimum-results-for-search="Infinity" name="role">
                                                            <option value="worker" {{ isset($user->role) && $user->role == 'worker' ? 'worker' : '' }}>Worker</option>
                                                            <option value="sitemanager" {{ isset($user->role) && $user->role == 'sitemanager' ? 'sitemanager' : '' }}>Site Manager</option>
                                                            <option value="groupmanager" {{ isset($user->role) && $user->role == 'groupmanager' ? 'groupmanager' : '' }}>Group Manager</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12">
                                                <div class="mb-3">
                                                    <label class="userview_label">Status</label>
                                                    <input type="text" class="form-control w-100" placeholder=""
                                                        name="status"
                                                        value="{{ isset($user_data->status) ? $user_data->status : '-' }}">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12 auto_pad">
                                        <div class="mb-3">
                                            <label class="userview_label">Comments</label>
                                            <textarea type="text" class="form-control w-100 form_textarea" name="comment"
                                                placeholder="Please enter some comments" value="">{{ isset($user_data->comment) ? $user_data->comment : '-' }}</textarea>
                                        </div>
                                    </div>
                                </div>
                                <div class="row PageViewTable">
                                    <div class="col-12 mt-4 Document-Section">
                                        <div
                                            class="d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column align-items-xxl-center align-items-xl-center align-items-lg-center align-items-md-center align-items-sm-start align-items-start justify-content-between">
                                            <h2 class="p-0 m-0 document-heading">
                                                Documents
                                            </h2>
                                            <div
                                                class="d-flex gap-2 align-items-center mt-xxl-0 mt-xl-0 mt-lg-0 mt-md-0 mt-sm-3 mt-3">
                                                <button type="button" data-bs-toggle="modal" data-bs-target="#document"
                                                    class="btn btn-secondary">Upload Document</button>
                                            </div>
                                        </div>
                                        <div class="row">
                                            
    
    
    
                                            @if ($allFiles != null)
                                            @foreach ($allFiles['files'] as $file)
                                                <div class="col-6 mt-3">
                                                    <div
                                                        class="DownloadIconSetting d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column align-items-xxl-center align-items-xl-center align-items-lg-center align-items-md-center align-items-sm-start align-items-start justify-content-between">
                                                        <div
                                                            class="d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column gap-3">
                                                            <div>
                                                                @if(str_contains($file, '.docx'))
                                                                <img style="height: 40px; width: 40px" src="{{url('storage/app/uploads/word.png')}}" width="50">
                                                                @elseif(str_contains($file, '.pdf'))
                                                                <img style="height: 40px; width: 40px" src="{{url('storage/app/uploads/pdf.png')}}" width="50">
                                                                @elseif(str_contains($file, '.csv'))
                                                                <img style="height: 40px; width: 40px" src="{{url('storage/app/uploads/excel.png')}}" width="50">
                                                                @else
                                                                <img style="height: 50px"
                                                                src="{{ url('storage/app/uploads/' . $file) }}"
                                                                alt="">
                                                                @endif
                                                            </div>
                                                            <div>
                                                                <p class="m-0 p-0 FileNameHeading">
                                                                    {{ $file }}
                                                                </p>
                                                                <small class="m-0 p-0">7 KB</small>
                                                            </div>
                                                        </div>
                                                        <div>
                                                            <a href="{{ asset('storage/app/uploads/' . $file) }}"
                                                                download>
                                                                <img src="{{ asset('public/assets/icons/DownloadSimple.svg') }}"
                                                                    alt="">
                                                            </a>
                                                            <a href="javascript:void(0)"
                                                                onclick="Delete_doc('{{ $allFiles['id'] }}', '{{ $file }}')">
                                                                <img src="{{ asset('public/assets/icons/trash.svg') }}"
                                                                    alt="">
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            @endforeach
                                        @else
                                        <div>
                                                <p class="m-0 p-0 FileNameHeading text-center">
                                                   No Documents Uploaded of This User
                                                </p>
                                            </div>
                                        @endif
                                         
    
                                        </div>
                                    </div>
    
                                </div>
                            </div>
    
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </form>

    <div class="modal fade" id="document" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <form action="{{ route('sitemanager.update_documents_user') }}" method="POST" enctype="multipart/form-data">
                @csrf
                <div class="modal-content">
                    <div class="modal-header extendModal">
                        <h1 class="modal-title fs-5" id="exampleModalLabel">Documents</h1>
                       <button style="border:none !important;" type="button" class="btn-secondary " data-bs-dismiss="modal" aria-label="Close"> <i class="fa-regular fa-x"></i> </button>
                    </div>
                    <div class="modal-body DocumentModal">
                        <div class="row">
                            <div class="col-12 mt-3">
                                <div class="emp_doc_upload" style="padding-top: .5rem;"></div>
                            </div>
                            <input type="hidden" value="{{ $user_data->id }}" name="user_id">
                           
                        </div>
    
                    </div>
                    <div class="modal-footer">
                        <!--                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>-->
                        <button type="submit" class="btn btn-secondary">Save</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

        {{-- Delete Confirmation Modal Start --}}
<div class="modal fade" id="DeleteModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <form action="{{ route('sitemanager.delete_user_doc') }}" method="POST">
            @csrf
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Delete Confirmation</h5>
                   <button style="border:none !important;" type="button" class="btn-secondary " data-bs-dismiss="modal" aria-label="Close"> <i class="fa-regular fa-x"></i> </button>
                </div>
                <div class="modal-body">
                    <p>Are you sure want to delete?</p>
                    <input type="hidden" id="doc_id" name="doc_id">
                    <input type="hidden" id="doc_name" name="doc_name">
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Yes</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div>
            </div>
        </form>
    </div>
</div>
{{-- Delete Confirmation Modal End --}}



<script>
    function Delete_doc(id, files) {
    console.log(id)
    console.log(files)
    $('#doc_id').val(id)
    $('#doc_name').val(files)
    $('#DeleteModal').modal('show');
}
</script>

@include('sitemanager.footer')

<script src="{{ asset('public/assets/js/select2.min.js') }}"></script>

<script>
     $('.js-select2').select2({
        selectOnClose: true
});
</script>