<script>

// create group js

document.getElementById('create_grp_btn').addEventListener('click', function(event) {
           event.preventDefault();
           document.getElementById('create_grp_form').submit();
       });
       

</script>