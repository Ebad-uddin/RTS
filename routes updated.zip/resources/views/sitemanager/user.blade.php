<?php
$activebar = "users";
?>

@include('sitemanager.header')
    <div class="iq-top-navbar py-2 rtl-iq-top-navbar ">
        <div class="iq-navbar-custom">
            <nav class="navbar navbar-expand-lg navbar-light p-0 toSetNavBarAll w-100">
                <div class="iq-navbar-logo d-flex align-items-center justify-content-between">
                    <i class="ri-menu-line wrapper-menu"></i>
                    <!-- Mobile Logo -->
                </div>
                <div class="iq-search-bar device-search">
                    <h4 class="main_content_title ps-3">Users</h4>
                </div>
                @include('sitemanager.tooltip')
                <div class="d-xxl-none d-xl-none d-lg-none d-md-block d-sm-block d-block">
                    <ul class="align-items-center d-flex gap-4 list-unstyled text-decoration-none m-0">
                        <li>
                            <button class="nav-AddNew-Button btn btn-primary" type="button" data-bs-toggle="modal" data-bs-target="#exampleModal">Create Task</button>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
    </div>



    <div class="content-page rtl-page">
        <div class="container-fluid mt-4">
            <div class="row UserPage">
                <div class="col-12">
                    <div class="row mt-4">
                        <div class="col-12 ">
                            <div class="bg-white p-3 index-TablePage">
                                <div class="mb-3">
                                    <div class="align-items-center d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column justify-content-between toSetFilterIcon">
                                        <div class="d-flex align-items-center gap-3">
                                            <h4 class="file-Heading">
                                                All Workers
                                            </h4>
                                            <a href="#" class="text-decoration-none mx-2">
                                                <button  data-bs-target=".AddUserModal" data-bs-toggle="modal" class="btn btn-secondary AllWorkerPageButton"><svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M2.8125 9H15.1875M9 2.8125V15.1875" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                    </svg>
                                                </button>
                                            </a>
                                        </div>
                                        <div class="TogiveFullWidth d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column gap-2 mt-xxl-0 mt-xl-0 mt-lg-0 mt-md-0 mt-sm-3 mt-3">
                                             <select id="role" onchange="filterRole(event)"name="role" class="js-select2" data-minimum-results-for-search="Infinity" >
                                                <option value="all">All</option>
                                                <option value="Worker">Workers</option>
                                                <option value="groupmanager">Group Manager</option>
                                            </select>

                                            <div
                                                class="mt-xxl-0 mt-xl-0 mt-lg-0 mt-md-0 mt-sm-3 mt-3 d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column gap-2">
                                                {{--<!--   <button data-bs-toggle="dropdown" data-bs-auto-close="inside"
                                                    aria-expanded="false"
                                                    class="FilterButtonSetting btn btn-secondary dropdown-toggle d-flex gap-2 align-items-center">
                                                    Sort by
                                                    <svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                                                        xmlns="http://www.w3.org/2000/svg">
                                                        <path
                                                            d="M3.375 13.4995H7.3125M10.125 11.812L12.9375 14.6245M12.9375 14.6245L15.7499 11.8125M12.9375 14.6245L12.9375 7.87451M3.375 8.99951H8.43743M3.375 4.49951H12.9374"
                                                            stroke-width="1.5" stroke-linecap="round"
                                                            stroke-linejoin="round" />
                                                    </svg>
                                                </button> --> --}}

                                                <div class="dropdown-menu dropdown-menu-end filter_dropdown"
                                                    data-popper-placement="bottom-end">
                                                    <div class="filter-con-div">
                                                        <ul
                                                            class="timeline ddflx mmy d-flex gap-1 m-2 flex-column list-unstyled">



                                                            <li>
                                                                <div class="form-group">
                                                                    <label class="text-label">Training Level</label> <br />
                                                                    <select name="" class="js-select2 ">
                                                                        <option value="Select Option" disabled>Select
                                                                            Option
                                                                        </option>
                                                                        <option value="T1">T1</option>
                                                                        <option value="T2" selected>T2
                                                                        </option>
                                                                        <option value="T3">T3</option>
                                                                        <option value="T4">T4</option>
                                                                    </select>
                                                                </div>
                                                            </li>
                                                            <li>
                                                                <div class="form-group">
                                                                    <label class="text-label">Name</label> <br />
                                                                    <select name="" class="js-select2 ">
                                                                    <option value="Select Option" disabled>Select
                                                                            Option
                                                                        </option>
                                                                        <option value="John Doe">John Doe</option>
                                                                        <option value="Henry Clark" selected>Henry Clark
                                                                        </option>
                                                                        <option value="Methew Henry">Methew Henry</option>
                                                                        <option value="Richard Hord">Richard Hord</option>
                                                                    </select>
                                                                </div>
                                                            </li>





                                                        </ul>
                                                        <div class="d-flex gap-3 flx-d-column">
                                                            <button type="button"
                                                                class="btn w-100 btn-danger light cancelbtn-m"
                                                                data-bs-dismiss="modal">Clear Filters
                                                            </button>
                                                            <button type="button"
                                                                class="ad-n-blk btn btn-primary bg-r-l  w-100 gr-b">Apply
                                                                Filters</button>
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>

                                            <!--                                                 <input type="text" class="form-control">-->
                                            <!--                                            <form action="" class="p-0 m-0 position-relative">-->
                                            <!--                                                <img style="" class="GlobalInputIconSetting position-absolute" src="assets/icons/MagnifyingGlass.svg" alt="">-->
                                            <!--                                                <input style="" type="text" class="form-control GlobalInputSetting" placeholder="s">-->
                                            <!--                                            </form>-->
                                        </div>
                                    </div>
                                </div>
                                <div class="table-responsive">
                                    <table id="" class="dataTable table-responsive stripe w-100 ">
                                        <thead>
                                        <tr>
                                           <th>  S.No </th>
                                            <th class="text-start">Date Added</th>
                                            <th class="text-start">Name</th>
                                            <th class="text-start">Training Level</th>
                                            <th class="text-start">Total Task</th>
                                            <th class="text-start">Last Online</th>
                                            <th></th>
                                        </tr>
                                        </thead>
                                        <tbody id="users_table">
                                            @if(!empty($users_data))
                                            @foreach ($users_data as $k=>$item)
                                            <tr>
                                                <td>
                                                <p class="table-MainHeading" >
                                                   {{ $k+1 }}
                                                   </p>
                                                </td>
                                                <td>
                                                    @php
                                                    $timestamp = (strtotime($item->created_at));
                                                    $date = date('j.n.Y', $timestamp);
                                                    $time = date('H:i:s', $timestamp);
                                                    @endphp
                                                    <p id="dateAdded" class="p-0 m-0 table-MainHeading mb-1">
                                                        {{$date}}
                                                    </p>
                                                    <p class="p-0 m-0 table-SubHeading">
                                                        {{$time}}
                                                    </p>
                                                </td>
                                                <td>
                                                    <p id="name" class="p-0 m-0 table-MainHeading mb-1">
                                                        {{isset($item->f_name) && isset($item->l_name) ? $item->f_name . ' ' . $item->l_name : '-'}}
                                                    </p>
                                                    <p id="email" class="p-0 m-0 table-SubHeading">
                                                        {{isset($item->email) ? $item->email : '-'}}
                                                    </p>
                                                </td>
                                                <td>
                                                    <p id="training_level" class="p-0 m-0 table-MainHeading">
                                                        {{isset($item->training_level) ? $item->training_level : '-'}}
                                                    </p>
                                                </td>
                                                <td>
                                                    <p class="p-0 m-0 table-MainHeading">
                                                        {{$item->tasks}}
                                                    </p>
                                                </td>
                                                <td>
                                                    <p class="p-0 m-0 table-MainHeading">
                                                        @php
                                                        $lastLoginTime = strtotime($item->last_login);
                                                        $currentTime = time();
                                                        $timeDifferenceSeconds = $currentTime - $lastLoginTime;
                                                        $minutes = floor(($timeDifferenceSeconds % 3600) / 60);
                                                        $hours = floor($timeDifferenceSeconds / 3600);
                                                        $seconds = $timeDifferenceSeconds % 60;

                                                        // Convert to a human-readable format
                                                        if ($minutes < 1) {
                                                            $timeDifference = 'Just now';
                                                        } elseif ($minutes < 60) {
                                                            $timeDifference = $minutes .' min ago';
                                                        } elseif ($minutes > 60) {
                                                            $timeDifference = $hours . ' hours ago';
                                                        } else{
                                                            $timeDifference = $hours;
                                                        }
                                                    @endphp

                                                    {{$timeDifference}}
                                                    </p>
                                                </td>
                                                <td>
                                                    <div class="tableButtonSetting">
                                                        <div class="btn-group dropstart">
                                                            <a href="#" class="dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false" >
                                                                <img src="{{asset('public/assets/icons/DotsThreeOutline.svg')}}" alt="">
                                                            </a>
                                                            <ul class="dropdown-menu tosetWidh-Dropdown">
                                                                <li><a class="dropdown-item  togivepaddingLeft" href="{{route('sitemanager.EditEmployee',['id' => $item->id])}}">View</a></li>
                                                                <li><a class="dropdown-item  togivepaddingLeft" href="#" data-bs-toggle="modal" data-bs-target="#Delete_worker" onclick="Delete_worker('{{$item->id}}')" type="button">Delete</a></li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                            @endforeach
                                            @endif
                                        </tbody>

                                    </table>

                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

<script>
      function filterRole(e){
        var role_val = e.target.value;
               console.log(role_val);
               $.ajax({
                   url: "{{ route('sitemanager.filter_user') }}",
                   type: 'POST',
                   data: {
                       user_role: role_val,
                       _token: "{{ csrf_token() }}"
                   },
                   success: function(response) {
    console.log(response);
    users_table.innerHTML = '';
    response.users.forEach((e, index) => {
        console.log(e);

        // Calculate the time difference for last_login
        const lastLoginDate = new Date(e.last_login);
        const currentDate = new Date();
        const timeDifference = currentDate - lastLoginDate; // Difference in milliseconds

        // Calculate time difference in human-readable format
        const seconds = Math.floor(timeDifference / 1000);
        const minutes = Math.floor(seconds / 60);
        const hours = Math.floor(minutes / 60);
        const days = Math.floor(hours / 24);

        let lastLoginTimeAgo = '';
        if (days > 0) {
            lastLoginTimeAgo = `more than a day ago`;
        } else if (hours > 0) {
            lastLoginTimeAgo = `${hours} hour${hours > 1 ? 's' : ''} ago`;
        } else if (minutes > 0) {
            lastLoginTimeAgo = `${minutes} minute${minutes > 1 ? 's' : ''} ago`;
        } else {
            lastLoginTimeAgo = `${seconds} second${seconds > 1 ? 's' : ''} ago`;
        }

        // Create the table row HTML
        users_table.innerHTML += `
            <tr>
                <td>${index + 1}</td>
                <td>
                    <p id="dateAdded" class="p-0 m-0 table-MainHeading mb-1">
                        ${e.created_at}
                    </p>
                </td>
                <td>
                    <p id="name" class="p-0 m-0 table-MainHeading mb-1">
                        ${e.f_name} ${e.l_name}
                    </p>
                    <p id="email" class="p-0 m-0 table-SubHeading">
                        ${e.email}
                    </p>
                </td>
                <td>
                    <p id="training_level" class="p-0 m-0 table-MainHeading">
                        ${e.training_level}
                    </p>
                </td>
                <td>
                    <p class="p-0 m-0 table-MainHeading">
                        ${e.tasks}
                    </p>
                </td>
                <td>
                    <p class="p-0 m-0 table-MainHeading">
                        ${lastLoginTimeAgo}
                    </p>
                </td>
                <td>
                    <div class="tableButtonSetting">
                        <div class="btn-group dropstart">
                            <a href="#" class="dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <img src="{{asset('public/assets/icons/DotsThreeOutline.svg')}}" alt="">
                            </a>
                            <ul class="dropdown-menu tosetWidh-Dropdown">
                                <li><a class="dropdown-item togivepaddingLeft" href="{{url('superadmin/EditEmployee')}}/${e.id}">View</a></li>
                                <li><a class="dropdown-item togivepaddingLeft" href="#" data-bs-toggle="modal" data-bs-target="#Delete_worker" onclick="Delete_worker('{{$item->id}}')" type="button">Delete</a></li>
                            </ul>
                        </div>
                    </div>
                </td>
            </tr>`;
    });
}

               })
      }
</script>

<!--
    <script>
        var role = $('#role');
        console.log(role);
           var users_table = document.getElementById('users_table');

           role.on('change', function(e) {
            console.log('role changes')
               role_val = e.target.value;
               console.log(role_val);
               $.ajax({
                   url: "{{ route('sitemanager.filter_user') }}",
                   type: 'POST',
                   data: {
                       user_role: role_val,
                       _token: "{{ csrf_token() }}"
                   },
                   success: function(reponse) {
                       console.log(reponse);
                       users_table.innerHTML = '';
                       reponse.forEach((e , index) => {
                           console.log(e);
                           users_table.innerHTML += `<tr>
                                                <td>
                                                  ${index+1}
                                                </td>
                                                <td>
                                                    <p id="dateAdded" class="p-0 m-0 table-MainHeading mb-1">
                                                        ${e.created_at}
                                                    </p>
                                                </td>
                                                <td>
                                                    <p id="name" class="p-0 m-0 table-MainHeading mb-1">
                                                        ${e.f_name} ${e.l_name}
                                                    </p>
                                                    <p id="email" class="p-0 m-0 table-SubHeading">
                                                        ${e.email}
                                                    </p>
                                                </td>
                                                <td>
                                                    <p id="training_level" class="p-0 m-0 table-MainHeading">
                                                        ${e.training_level}
                                                    </p>
                                                </td>
                                                <td>
                                                    <p class="p-0 m-0 table-MainHeading">
                                                        17
                                                    </p>
                                                </td>
                                                <td>
                                                    <p class="p-0 m-0 table-MainHeading">
                                                        1 min ago
                                                    </p>
                                                </td>
                                                <td>
                                                    <div class="tableButtonSetting">
                                                        <div class="btn-group dropstart">
                                                            <a href="#" class="dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false" >
                                                                <img src="../assets/icons/DotsThreeOutline.svg" alt="">
                                                            </a>
                                                            <ul class="dropdown-menu tosetWidh-Dropdown">
                                                                <li><a class="dropdown-item  togivepaddingLeft" href="user-view.php">View</a></li>
                                                                <li><a class="dropdown-item  togivepaddingLeft" href="#" data-bs-toggle="modal" data-bs-target="#DeleteModal" type="button">Delete</a></li>
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>`

                       });



                   }
               })
           });




    </script> -->
@include('sitemanager.footer')


<script src="{{ asset('public/assets/js/select2.min.js') }}"></script>

<script>
     $('.js-select2').select2({
        selectOnClose: true
});
</script>
