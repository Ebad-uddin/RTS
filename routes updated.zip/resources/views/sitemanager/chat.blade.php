<?php
$activebar = "chat";
?>
<style>
    .Section-Chat-Page .chat-middle .tosetHeigthOfchat {
        height: 40rem !important;
        overflow-y: scroll !important;
    }

    .tosetitsWidth {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 0px 10px;
    }

    .chat_text {
        display: none;
    }
</style>
@include('sitemanager.header')
<div class="iq-top-navbar py-2 rtl-iq-top-navbar ">
    <div class="iq-navbar-custom">
        <nav class="navbar navbar-expand-lg navbar-light p-0 toSetNavBarAll w-100">
            <div class="iq-navbar-logo d-flex align-items-center justify-content-between">
                <i class="ri-menu-line wrapper-menu"></i>
                <!-- Mobile Logo -->
            </div>
            <div class="iq-search-bar device-search">
                <h4 class="main_content_title ps-3">Chat</h4>
            </div>
            @include('sitemanager.tooltip')
            <div class="d-xxl-none d-xl-none d-lg-none d-md-block d-sm-block d-block">
                <ul class="align-items-center d-flex gap-4 list-unstyled text-decoration-none m-0">
                    <li>
                    <button class="nav-AddNew-Button btn btn-primary" type="button" data-bs-toggle="modal" data-bs-target="#create_task_modal">Create Task</button>
                    </li>
                </ul>
            </div>
        </nav>
    </div>
</div>


<div class="content-page rtl-page">
    <div class="container-fluid mt-4">
        <div class="row">
            <div class="col-12 mb-3 d-xxl-none d-xl-none d-lg-none d-md-block d-sm-block d-block">
                <div class="d-flex align-items-center justify-content-between">
                <button class="btn btn-secondary" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasExample" aria-controls="offcanvasExample">
                            All Chat
                        </button>
                    <!-- <button class="btn btn-secondary" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasRight" aria-controls="offcanvasRight">Upload File</button> -->

                </div>

            </div>
            <div class="col-12">
                <div class="Section-Chat-Page">
                    <div class="container-fluid">
                        <div class="row tosetHeightofChat">
                            <div class="col-3 d-xxl-block d-xl-block d-lg-block d-md-none d-sm-none d-none chat-left px-0 py-2">
                                <div class="Chat-Border-setting d-flex align-items-center justify-content-between">
                                    <h1 class="p-0 m-0 chat-Main-Heading">Conversations</h1>
                                    {{-- <button class="btn btn-secondary ChatAddBtn"> <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg"> <path d="M2.8125 9H15.1875M9 2.8125V15.1875"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/> </svg>
                                    </button> --}}
                                </div>
                                <div class="mt-3 px-3">
                                    <div class="row tosetHeigthOfchat overflow-y-scroll">
                                        <div class="col-12">
                                            <div>
                                                <input type="text" placeholder="Search member" id="member_search" class="form-control w-100">
                                            </div>
                                            <div class="mt-3">
                                                <div style="height: 35rem; overflow-y:scroll;" class="nav flex-column nav-pills usersTab" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                                                    <div id="members-container">
                                                        @foreach ($all_members as $item)
                                                        @if($item->id !== Auth::id())
                                                        <button  style="
                                                            background-color: white !important;
                                                            border-bottom: 1px solid lightgray !important;
                                                            border-radius: 0px !important;
                                                            padding: 10px;
                                                            " onclick="See_chat('{{$item->id}}'); read_msg('{{$item->id}}');" class="nav-link active w-100 border-0 my-2 seachResults" id="v-pills-home-tab" data-bs-toggle="pill" data-bs-target="#v-pills-profile" type="button" role="tab" aria-controls="v-pills-home" aria-selected="true">
                                                            <div class="d-flex gap-2 align-items-center">
                                                                <div class="tab-chat-image-setting">
                                                                    @if (!empty($item->image))
                                                                    <img src="{{url('storage/app/uploads/' . $item->image)}}" class="w-100 h-100" alt="">
                                                                    @else
                                                                    <img src="{{url('storage/app/uploads/placeholder.jpg')}}" class="w-100 h-100" alt="">
                                                                    @endif
                                                                </div>
                                                                @php
                                                                $count_msg = 0;
                                                                @endphp
                                                                @if(!empty($item->chats))
                                                                @foreach ($item->chats as $chats)
                                                                @if(!empty($chats) && $chats->status == 0 && $chats->reciever_Id == Auth::id())
                                                                @php
                                                                $count_msg = count($item->chats)
                                                                @endphp
                                                                @endif
                                                                @endforeach
                                                                @endif
                                                                <div class="tosetitsWidth">
                                                                    <div class="d-flex align-items-center justify-content-between">
                                                                        <h4 class="m-0 p-0 tab-chat-name">{{isset($item->f_name) && isset($item->l_name) ? $item->f_name . ' ' . $item->l_name : '-'}}</h4>
                                                                        <small class="tab-chat-hour me-1 p-2 rounded-circle bg-danger {{!empty($count_msg) ? $count_msg : 'd-none'}}">
                                                                            {{isset($count_msg) ? $count_msg : ''}}
                                                                        </small>
                                                                    </div>
                                                                    <div>
                                                                        <p class="text-start tab-chat-text p-0 m-0">{{$item->role}}</p>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </button>
                                                        @endif
                                                        @endforeach
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                            </div>

                            <script>
                                function read_msg(id){
                                    console.log(id);
                                    $.ajax({
                                        url : "{{route('sitemanager.read_msg')}}",
                                        method : "POST",
                                        data : {
                                            read_id : id,
                                            _token : "{{csrf_token()}}",
                                        },
                                        success : function(res){
                                            console.log(res)
                                            Show_msg()
                                        }
                                    })
                                }
                            </script>




                            <div class="col-xxl-9 col-xl-9 col-lg-6 col-md-12 col-sm-12 col-12 chat-middle py-2 px-0">

                                <div class="tab-content apndChats show active" id="v-pills-tabContent" >
                                </div>
                                <div class="chat_text" >
                                    <div class="d-flex align-items-center gap-2 px-2  " >
                                        <input style=""  id="sender_typed_msg" onkeyup="sendMessage(event)" type="text" class="form-control GlobalInputSetting w-100 mx-2" placeholder="Type a message">
                                        <button class="btn-primary mx-2" onclick="sendMessage()"> Send  </button>
                                    </div>
                                </div>
                            </div>


                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>





<div class="offcanvas offcanvas-start" tabindex="-1" id="offcanvasExample" aria-labelledby="offcanvasExampleLabel">
        <div class="offcanvas-header">
           
            <h5 class="offcanvas-title" id="offcanvasExampleLabel">All Chats</h5>
        <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
        </div>
        <div class="offcanvas-body">
        <div class="container-fluid">
              <div class="row Section-Chat-Page">
                  <div class="col-12 chat-left  ">
                      <div class="Chat-Border-setting d-flex align-items-center justify-content-between">
                          <h1 class="p-0 m-0 chat-Main-Heading">Conversations</h1>
                          <button class="btn btn-secondary ChatAddBtn"> <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg"> <path d="M2.8125 9H15.1875M9 2.8125V15.1875"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/> </svg>
                          </button>
                      </div>
                      <div class="mt-3 px-3">
                          <div class="row tosetHeigthOfchat overflow-y-scroll">
                              <div class="col-12">
                                  <div>
                                      <input type="text" class="form-control w-100">
                                  </div>
                                  <div class="mt-3">
                                    <div id="members-container">
                                        @if(!empty($all_members))
                                        @foreach ($all_members as $item)
                                        <a href="#{{$item->id}}" 
                                        
                                        style=" background-color: white !important; border-bottom: 1px solid lightgray !important; border-radius: 0px !important; padding: 10px; "
                                        
                                        onclick="See_chat('{{$item->id}}'); read_msg('{{$item->id}}');" class="nav-link active w-100 seachResults" id="v-pills-home-tab" data-bs-toggle="pill" data-bs-target="#v-pills-profile" type="button" role="tab" aria-controls="v-pills-home" aria-selected="true">
                                            <div class="d-flex gap-2 align-items-center">
                                                <div class="tab-chat-image-setting">

                                                    @if (!empty($item->image))
                                                    <img src="{{url('storage/app/uploads/' . $item->image)}}" class="w-100 h-100" alt="">
                                                    @else
                                                    <img src="{{url('storage/app/uploads/placeholder.jpg')}}" class="w-100 h-100" alt="">
                                                    @endif
                                                </div>
                                                    @php
                                                    $count_msg = 0;
                                                    @endphp
                                                    @if(!empty($item->chats))
                                                    @foreach ($item->chats as $chats)
                                                    @if(!empty($chats) && $chats->status == 0 && $chats->reciever_Id == Auth::id())
                                                    @php
                                                        $count_msg = count($item->chats)
                                                    @endphp
                                                    @endif
                                                    @endforeach
                                                    @endif
                                                <div class="tosetitsWidth">
                                                    <div class="d-flex align-items-center justify-content-between w-100">
                                                        <h4 class="m-0 p-0 tab-chat-name">{{isset($item->f_name) && isset($item->l_name) ? $item->f_name . ' ' . $item->l_name : '-'}}</h4>
                                                        <small class="tab-chat-hour me-1 p-2 rounded-circle bg-danger {{!empty($count_msg) ? $count_msg : 'd-none'}}">
                                                            {{isset($count_msg) ? $count_msg : ''}}
                                                        </small>
                                                    </div>
                                                    <div>
                                                        <p class="text-start tab-chat-text p-0 m-0">{{$item->role}}</p>
                                                    </div>
                                                </div>
                                            </div>
                                        </a>
                                        @endforeach
                                        @endif
                                    </div>

                                  </div>

                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
        </div>
</div>



{{-- chat script --}}
<script>
    var chatid = null;
    setInterval(() => {
        See_chat(chatid);
    }, 1000);
    function See_chat(id) {

        chatid=id;
        $('#reciever_typed_id').val(id);
        $.ajax({
            url: "{{ route('sitemanager.showchat') }}",
            type: "POST",
            data: {
                reciever_typed_id: id,
                _token: "{{ csrf_token() }}"
            },
            success: function(res) {
                console.log(res);
                $('.chat_text').show()

                $('.apndChats').html(res.view);
                chatWindow = $('#chattingscrfl')
                chatWindow.scrollTop(chatWindow[0].scrollHeight);
                $('#offcanvasExample').hide();
                $('.offcanvas-backdrop').css('display' , 'none');
            }
        });
    }

    function sendMessage(event) {
        if (event && event.keyCode !== 13) {
            return;
        }

        if ($('#sender_typed_msg').val() !== '') {
            let sender_msg = $('#sender_typed_msg').val();
            let reciever_typed_id = $('#recUserId').val();

            $.ajax({
                url: "{{ route('sitemanager.sendMsg') }}",
                type: "POST",
                data: {
                    sender_msg: sender_msg,
                    reciever_id: reciever_typed_id,
                    _token: "{{ csrf_token() }}"
                },
                success: function(res) {
                    console.log(res);
                    // Refresh chat section
                    See_chat(reciever_typed_id);
                    // Clear input field
                    $('#sender_typed_msg').val('');
                }
            });
        } else {
            return false;
        }
    }

</script>

<script>
    $(document).ready(function() {
        $('#member_search').on('input', function() {
            var searchText = $(this).val().toLowerCase();
            $('.seachResults').each(function() {
                var eventText = $(this).text().toLowerCase();
                if (eventText.includes(searchText)) {
                    $(this).show();
                } else {
                    $(this).hide();
                }
            });
        });
    });



</script>


@include('sitemanager.footer')
