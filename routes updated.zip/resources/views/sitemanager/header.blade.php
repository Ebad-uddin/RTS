<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>RTS | Site Manager Portal</title>


<meta name="csrf-token" content="{{ csrf_token() }}">

    <link rel="stylesheet" href="{{ asset('public/assets/vendor/bootstrap/bootstrap-dist.min.css') }}">

    <link rel="stylesheet" href="{{asset('public/assets/css/plugin.css')}}">
    <link rel="stylesheet" href="{{asset('public/assets/css/select2.min.css')}}" />
    <link rel="stylesheet" href="{{asset('public/assets//vendor/flatpickr/flatpickr.css')}}" />
    <link rel="stylesheet" href="{{asset('public/assets//css/datatables.css')}}" />
    <link rel="stylesheet" href="{{asset('public/assets//css/style.css')}}">
    <link rel="stylesheet" href="{{asset('public/assets//scss/components.css')}}">
    <link rel="stylesheet" href="{{asset('public/assets//vendor/%40fortawesome/fontawesome-free/css/all.min.css')}}">
    <link rel="stylesheet" href="{{asset('public/assets//vendor/line-awesome/dist/line-awesome/css/line-awesome.min.css')}}">
    <link rel="stylesheet" href="{{asset('public/assets//vendor/remixicon/fonts/remixicon.css')}}">
    <link rel="stylesheet" href="{{asset('public/assets//vendor/%40icon/dripicons/dripicons.css')}}">

    <link rel="stylesheet" href="{{asset('public/assets//vendor/mapbox/mapbox-gl.css')}}">
    <link rel="stylesheet" href="{{asset('public/assets//icons/ui_icons/css/uicons-regular-rounded.css')}}">
    <link rel="stylesheet" href="{{asset('public/assets//vendor/flatpickr/flatpickr.css')}}">
    <link rel="stylesheet" href="{{asset('public/assets//vendor/@fortawesome/fontawesome-free/css/all.min.css')}}">
    <link rel="stylesheet" href="{{asset('public/assets//css/datatables.css')}}" />
    <link rel="stylesheet" href="{{asset('public/assets/vendor/drag-drop-image-uploader/dist/image-uploader.min.css')}}">

    {{-- toastr --}}
    <link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" rel="stylesheet"/>

    <link type="text/css" href="{{asset('public/assets/css/sample.css')}}" rel="stylesheet" media="screen" />
    <script src="{{asset('public/assets/vendor/jqueryui/js/jquery.min.js')}}"> </script>
    <script src="{{asset('public/assets/vendor/jqueryui/js/jquery-ui.min.js')}}"> </script>
    <link rel="stylesheet" href="{{asset('public/assets/css/apexstyles.css')}}">
    <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
    <link rel="stylesheet" href="{{asset('public/assets/scss/admin.css')}}">


    <style>
 .toast-center {
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        -webkit-transform: translate(-50%, -50%);
        -ms-transform: translate(-50%, -50%);
    }
    .toast-center {
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }
        .is-invalid {
        border-color: red;
    }
    #completeOption {
    display: none; /* Initially hide the Complete option */
}

.highlight {
    display: block !important; /* Show the Complete option when highlighted */
}

.dropdown-toggle::after {
    display: none !important;
}
    </style>

    <script>

// $(document).ready(function() {
//     $('.dropdown-menu').on( 'click' , function(event){
//         event.stopPropagation();
//         event.preventDefault()
//     })
// })
    </script>
</head>

<body class="">
    {{-- <div id="loading">
        <div id="loading-center">
        </div>
    </div> --}}
    <div class="wrapper">
@include('sitemanager.sidebar')
