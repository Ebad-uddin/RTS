
@foreach ($all_tasks_count as $k=>$item)
                                                <tr>
                                                    <td>
                                                      <p class="table-MainHeading" > {{$k+1}}   </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            {{isset($item->created_at) ? $item->created_at : '-'}}
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            03:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            {{isset($item->task_id) ? $item->task_id : '-'}}
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            {{isset($item->task_name) ? $item->task_name : '-'}}
                                                        </p>
                                                    </td>

                                                            <td>
                                                                <p class="p-0 m-0 table-MainHeading">
                                                                    @if(!empty($item->users))
                                                                    @foreach ($item->users as $worker)
                                                                    <span class="badge badge-inactive">{{isset($worker->f_name) ? $worker->f_name : ''}}</span>

                                                                    @endforeach
                                                                    @endif
                                                                </p>
                                                            </td>
                                                    @php
                                                    $timestamp = (strtotime($item->start_datetime));
                                                    $date = date('j.n.Y', $timestamp);
                                                    $time = date('H:i:s', $timestamp);
                                                    @endphp
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            {{$date}}
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            {{$time}}
                                                        </p>
                                                    </td>
                                                    @php
                                                    $timestamp = (strtotime($item->end_datetime));
                                                    $date = date('j.n.Y', $timestamp);
                                                    $time = date('H:i:s', $timestamp);
                                                    @endphp
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            {{$date}}
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            {{$time}}
                                                        </p>
                                                    </td>
                                                    <td>
                                                         <select name="status" onchange="changeStatusFunc(event , '{{$item->id}}')" id="status-{{ $k }}" class="js-select2 tosetitas status-select-{{ $k }}">
                                                                <option value="Select Option" disabled>Select Option</option>
                                                                <option value="Approved" {{ isset($item->status) && $item->status == 'Approved' ? 'selected' : '' }}>Approved</option>
                                                                <option value="Submitted" {{ isset($item->status) && $item->status == 'Submitted' ? 'selected' : '' }}>Submitted</option>
                                                                <option value="Active" {{ isset($item->status) && $item->status == 'Active' ? 'selected' : '' }}>Active</option>
                                                                <option value="Expired" {{ isset($item->status) && $item->status == 'Expired' ? 'selected' : '' }}>Expired</option>
                                                        </select>
                                                    </td>
                                                    <td>
                                                        <div class="tableButtonSetting">
                                                            <div class="btn-group dropstart">
                                                                <a href="#" class="dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false" >
                                                                    <img src="{{asset('public/assets/icons/DotsThreeOutline.svg')}}" alt="">
                                                                </a>
                                                                <ul class="dropdown-menu tosetWidh-Dropdown">
                                                                    <li><a class="dropdown-item  togivepaddingLeft" href="{{route('{{$item->role}}.taskView' , ['id' => $item->id])}}" onclick="read_task_msg('{{ $item->id }}' , '{{Auth::id()}}')">View</a></li>
                                                                    <li><a class="dropdown-item  togivepaddingLeft" href="javascript:void(0)" onclick="Del_task('{{$item->id}}')" data-bs-toggle="modal" data-bs-target="#task_delete_modal" type="button">Delete</a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                        @if(isset($item->chats) && count($item->chats) > 0)
                                                        <a href="{{ route('{{$item->role}}.taskView', ['id' => $item->id]) }}" onclick="read_task_msg('{{ $item->id }}', '{{Auth::id()}}')" class="text-danger">
                                                            {{ count($item->chats) }}
                                                        </a>
                                                        @endif
                                                    </td>
                                                </tr>
                                                @endforeach
