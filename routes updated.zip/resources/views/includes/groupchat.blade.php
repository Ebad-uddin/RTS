
    @foreach ($chats as $chat)
            {{-- left --}}

            {{-- right --}}

            @if ($chat->sender_Id == Auth::id() && $chat->type == 'groupChat')

            <div class="col-12 chat-Setting mt-3">
                <div class="d-flex flex-row-reverse align-items-start gap-3 justify-content-start">
                    <div class="user-profile-image">
                         @if (!empty(Auth::user()->image))
                        <img src="{{url('storage/app/uploads/' . Auth::user()->image)}}" class="w-100 h-100" alt="">
                        @else
                        <img src="{{url('storage/app/uploads/placeholder.jpg')}}" class="w-100 h-100" alt="">
                        @endif
                    </div>
                    <div class="d-flex flex-column align-items-end">
                        <span class="badge badge-danger d-block">{{ $chat->msg }}</span>
                        <small class="">{{$chat->created_at }} </small>
                        <!-- <span class="">{{ 'Me' }} </span> -->
                    </div>
                </div>
            </div>
            @else
            {{-- @foreach ($user as $item) --}}
            {{-- @if($chat->id == $chat->sender_Id) --}}
            
            <div class="col-12 chat-Setting mt-3">
                <div class="d-flex align-items-start gap-3">
                    <div class="user-profile-image">
                            
                        @if (!empty($chat->user_details->image))
                        <img src="{{url('storage/app/uploads/' . $chat->user_details->image)}}" class="w-100 h-100" alt="">
                        @else
                        <img src="{{url('storage/app/uploads/placeholder.jpg')}}" class="w-100 h-100" alt="">
                        @endif
                        {{-- <img src="{{url('storage/app/uploads/' . isset($user->image) ? $user->image : 'placeholder.jpg')}}" class="w-100 h-100" alt=""> --}}
                    </div>
                    <div class="d-flex flex-column align-items-start">
                        <span class="mx-2"  ><b> {{isset($chat->user_details->f_name) ? $chat->user_details->f_name : ''}}  </b></span>
                        {{-- <span class=""> <b></b> {{${{$user->f_name }} </b> </span> --}}
                        <span class="badge badge-chat d-block">{{$chat->msg }}  </span>
                        {{-- <span class="badge badge-chat d-block">{{$chat->sender_Id }}  </span> --}}
                        <small class="">{{$chat->created_at }} </small>
                    </div>
                </div>
            </div>
            {{-- @endif --}}
            {{-- @endforeach --}}
            @endif
    @endforeach
