<div class="modal fade Header-Modal" id="Edit_task_modal" tabindex="-1" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Create Task Assignment</h5>
               <button style="border:none !important;" type="button" class="btn-secondary " data-bs-dismiss="modal" aria-label="Close"> <i class="fa-regular fa-x"></i> </button>
            </div>
            <form action="{{ route('admin.Update_task') }}" method="POST" enctype="multipart/form-data"
            id="task_form">
            @csrf
            <div class="modal-body">
                    <div class="row">
                        <div class="col-xxl-4 col-xl-4 col-lg-12 col-md-12 col-sm-12 col-12 modal-leftSIde">
                            <div class="row">

                                <div class="col-12 mt-3">
                                    <div class="p-3 CheckboxSection">
                                        <div class="d-flex justify-content-between">
                                            <h4 class="Checkbox-Heading">Tasks</h4>
                                            <div class="d-flex">
                                                <div class="custom-Radio-Button">
                                                    <label class="custom-radio m-0" for="modalcheck">
                                                        <input type="checkbox" class="customme selectallCheckBox"   name="task_abbreviation[]"
                                                            id="modalcheck">
                                                        <span class="radio-btn"></span>

                                                    </label>
                                                </div>
                                                <span class="textbox-option">Select All</span>
                                            </div>
                                        </div>
                                        <div class="d-flex align-items-start mt-4 gap-5">
                                            <ul class="list-unstyled text-decoration-none d-flex flex-column gap-4" id="tasks">
                                                @if(!empty($all_tasks))
                                                
                                                @foreach($all_tasks as $k=>$t)
                                                <li>
                                                    <div class="d-flex">
                                                        <div class="custom-Radio-Button">
                                                            <label class="custom-radio m-0" for="task_edit{{$t['id']}}">
                                                                {{-- <input type="checkbox" class="customme tomarkallcheckbox"> --}}
                                                                <input type="checkbox"  class="customme tomarkallcheckbox"
                                                                 {{(isset($task_data[0]['task_abbreviation']) and in_array((string)$t['id'],json_decode($task_data[0]['task_abbreviation'],true))) ? 'checked' : ""}}
                                                                    name="task_abbreviation[]" id="task_edit{{$t['id']}}" value="{{$t['id']}}">
                                                                <span class="radio-btn"></span>
                                                            </label>
                                                        </div>
                                                        <span class="textbox-option">{{$t['task_abbreviation']}}</span>
                                                    </div>
                                                </li>
                                                @endforeach
                                                
                                                @endif
                                            </ul>
                                           
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <div class="col-xxl-8 col-xl-8 col-lg-12 col-md-12 col-sm-12 col-12">
                            <div class="row">
                                <div class="col-12">
                                    <div>
                                        <label for="start-Date" class="d-block">
                                            Task Title
                                        </label>
                                        <input type="text" value="{{isset($task_data[0]['task_name']) ? $task_data[0]['task_name'] : ""}}" name="task_name" placeholder="Account"
                                            id="task_name" class="form-control bg-transparent w-100">
                                            <input type="hidden" id="task_id" name="task_id" value="{{$task_data[0]['id']}}">
                                    </div>
                                </div>
                                <div class="col-12">
                                    <div>
                                        <label for="start-Date" class="d-block">
                                            Account
                                        </label>
                                        <input type="number" value="{{isset($task_data[0]['account']) ? $task_data[0]['account'] : ""}}" name="account" placeholder="Account"
                                            id="account" class="form-control bg-transparent w-100">
                                    </div>
                                </div>
                                <div class="col-12 mt-3">
                                    <div>
                                        <label for="start-Date" class="d-block">
                                            Company
                                        </label>
                                        <input type="text" name="company" value="{{isset($task_data[0]['company']) ? $task_data[0]['company'] : ""}}" placeholder="ABC Ltd." id="company"
                                            class="form-control bg-transparent w-100">
                                    </div>
                                </div>
                                <div class="col-12 mt-3">
                                    <div>
                                        <label for="start-Date" class="d-block">
                                            Department
                                        </label>
                                        <input type="text" name="department" value="{{isset($task_data[0]['department']) ? $task_data[0]['department'] : ""}}" placeholder="Testing"
                                            id="department" class="form-control bg-transparent w-100">
                                    </div>
                                </div>
                                <div class="col-12 mt-3">
                                    <div>
                                        <label for="start-Date" class="d-block">
                                            Test
                                        </label>
                                        <input type="text" name="test" id="test" name="test"
                                            class="form-control bg-transparent w-100">
                                    </div>
                                </div>
                                <div class="col-12 mt-3">
                                    <div>
                                        <label for="start-Date" class="d-block">
                                            Workers
                                        </label>
                                        <select id="workers"
                                            class="js-example-basic-multiple-limit-modal form-control w-100"
                                            name="workers[]" multiple="multiple">
                                            @if (!empty($task_workers))
                                            {{-- @foreach ($task_workers as $item) --}}
                                            @foreach ($task_workers as $user)
                                            <option {{(isset($task_data[0]['workers']) and in_array($user->id,json_decode($task_data[0]['workers'],true))) ? 'selected' : ""}} value="{{ $user->id}}">{{ isset($user->f_name) && isset($user->l_name) ? $user->f_name . ' ' . $user->l_name : '-'  }}</option>
                                            @endforeach
                                            {{-- @endforeach --}}
                                            @endif
                                        </select>
                                    </div>
                                </div>
                                <div class="col-12 mt-3">
                                    <div>
                                        <label for="vehiclec" class="d-block">
                                            Vehicle Category
                                        </label>
                                        <input type="text" name="vehicle_category" value="{{isset($task_data[0]['vehicle_category']) ? $task_data[0]['vehicle_category'] : ""}}" id="vehicle_category"
                                            class="form-control bg-transparent w-100">
                                    </div>
                                </div>
                                <div class="col-12 mt-3">
                                    <div>
                                        <label for="T-Level" class="d-block">
                                            T-Level
                                        </label>
                                        <select name="t_level" class="js-select2 w-100 form-control" id="t_level">
                                            <option value="T1" {{(isset($task_data[0]['t_level']) and $task_data[0]['t_level'] === 'T1') ? 'selected' : ""}}>T1</option>
                                            <option value="T2" {{(isset($task_data[0]['t_level']) and $task_data[0]['t_level'] === 'T2') ? 'selected' : ""}}>T2</option>
                                            <option value="T3" {{(isset($task_data[0]['t_level']) and $task_data[0]['t_level'] === 'T3') ? 'selected' : ""}}>T3</option>

                                        </select>
                                        <!-- <input type="text"  id="T-Level" class="form-control bg-transparent w-100"> -->
                                    </div>
                                </div>
                                <div class="col-12 mt-3">
                                    <div>
                                        <label for="Status" class="d-block">
                                            Status
                                        </label>
                                        <select name="status" class="js-select2 w-100 form-control" id="status">
                                            <option {{(isset($task_data[0]['status']) and $task_data[0]['status'] === 'Created') ? 'selected' : ""}} value="Created">Created</option>
                                            <option {{(isset($task_data[0]['status']) and $task_data[0]['status'] === 'Submitted') ? 'selected' : ""}} value="Submitted">Submitted</option>
                                            <option {{(isset($task_data[0]['status']) and $task_data[0]['status'] === 'Approved') ? 'selected' : ""}} value="Approved">Approved</option>
                                            <option {{(isset($task_data[0]['status']) and $task_data[0]['status'] === 'Rejected') ? 'selected' : ""}} value="Rejected">Rejected</option>
                                            <option {{(isset($task_data[0]['status']) and $task_data[0]['status'] === 'Active') ? 'selected' : ""}} value="Active">Active</option>
                                            <option {{(isset($task_data[0]['status']) and $task_data[0]['status'] === 'Completed') ? 'selected' : ""}} value="Completed">Completed</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-12 mt-3">
                                    <div>
                                        <label for="T-Level" class="d-block">
                                            Comments
                                        </label>
                                        <textarea name="comments" class="form-control w-100 bg-transparent" id="comments" cols="30" rows="2">{{isset($task_data[0]['comments']) ? $task_data[0]['comments'] : ""}}</textarea>
                                        <!--                                    <input type="text"  id="T-Level" class="form-control bg-transparent w-100">-->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                <button type="submit" id="task_form_btn" class="btn btn-primary">Save changes</button>
            </div>
        </form>
        </div>
    </div>
</div>