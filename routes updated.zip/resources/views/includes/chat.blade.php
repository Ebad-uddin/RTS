<div class="tab-pane fade show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
    <div class="Chat-Border-setting d-flex gap-3">
        <div class="main-chat-image">
            @if (!empty($user->image))
            <img src="{{url('storage/app/uploads/' . $user->image)}}" id="member_image" class="w-100 h-100" alt="">
            @else
            <img src="{{url('storage/app/uploads/placeholder.jpg')}}" class="w-100 h-100" alt="">
            @endif
           
        </div>
        <div>
            <h4 id="reciever_name" class="chat-user-Name m-0 p-0">{{ isset($user->f_name) ? $user->f_name.' '.$user->l_name : "" }}</h4>
            @if (isset($user->status) and $user->status == 1)

            <span class="d-flex gap-1 align-items-center"><svg width="10" height="11" viewBox="0 0 10 11" fill="none" xmlns="http://www.w3.org/2000/svg"> <circle cx="5" cy="5.5" r="5" fill="#68D391"/> </svg><small>Online</small></span>
            @endif
        </div>
    </div>
    <div class="px-3 mt-3" >
        <div class="row tosetHeigthOfchat overflow-y-scroll" id="chattingscrfl"> 

            @foreach ($chats as $chat)
            {{-- left --}}

            {{-- right --}}

            @if ($chat->sender_Id == Auth::id())

            <div class="col-12 chat-Setting mt-3">
                <div class="d-flex flex-row-reverse align-items-start gap-3 justify-content-start">
                    <div class="user-profile-image">
                        @if (!empty(Auth::user()->image))
                        <img src="{{url('storage/app/uploads/' . Auth::user()->image)}}" class="w-100 h-100" alt="">
                        @else
                        <img src="{{url('storage/app/uploads/placeholder.jpg')}}" class="w-100 h-100" alt="">
                        @endif
                    </div>
                    <div class="d-flex flex-column align-items-end">
                        <span class="badge badge-danger d-block">{{ isset($chat->msg) ? $chat->msg : '' }}</span>
                        <small style="font-size:10px">{{ $chat->created_at }}</small>
                    </div>
                </div>
            </div>
            @else
            <div class="col-12 chat-Setting mt-3">
                <div class="d-flex align-items-start gap-3">
                    <div class="user-profile-image">
                        {{-- <img src="{{url('storage/app/uploads/' . $user->image)}}" class="w-100 h-100" alt=""> --}}
                    </div>
                    <div class="user-profile-image">
                        @if (!empty($user->image))
                        <img src="{{url('storage/app/uploads/' . $user->image)}}" class="w-100 h-100" alt="">
                        @else
                        <img src="{{url('storage/app/uploads/placeholder.jpg')}}" class="w-100 h-100" alt="">
                        @endif
                    </div>
                    <div class="d-flex flex-column align-items-start">
                    {{-- <small class=" mx-3">{{ $user->f_name }} </small> --}}

                        <span class="badge badge-chat d-block">{{ isset($chat->msg) ? $chat->msg : '' }} </span>
                        <small style="font-size:10px">{{ $chat->created_at }}</small>
                    </div>
                </div>
            </div>
            @endif
            @endforeach
        </div>
        <div class="row">
            <div class="col-12 mt-3">
                <a href="#"> <img style="" class="GlobalInputIconSetting position-absolute" src="assets/icons/PaperPlaneTilt.svg" alt=""></a>
                <input type="hidden" name="" id="recUserId" value="{{$user->id}}">

            </div>
        </div>
    </div>
</div>
