<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Email</title>
  </head>
  <body>
    <table style="width: 100%">
      <thead>
        <tr>
          <th style="text-align: center; padding-top: 1rem; font-size: 18px">
            Welcome to RTS Remote Tracking System!
          </th>
        </tr>
      </thead>
      <tbody>

      
      
      </tbody>
    </table>
    <table>
      <thead></thead>
      <tbody>
        <tr>
          <td style="text-align: start; padding-top: 1rem; font-size: 15px; font-weight: bold; ">
          Greetings !
          </td>
        </tr>

        <tr>
          <td style="text-align: start; padding-top: 1rem; font-size: 14px">
          <b> Dear {{ isset($data['name']) ? $data['name'] : '' }}</b>,
          </td>
        </tr>
        <tr>
          <td
            style="
              text-align: start;
              padding-top: 1rem;
              line-height: 2rem;
              font-size: 14px;
            "
          >
            <span>

              Welcome to RTS Remote Tracking System! We are excited to have you on board as a <b>{{ isset($data['role']) ? $data['role'] : '' }}</b>.
              
            </span>
            <span>
              Here are your account details:

              <ul>
                <li><b>Email: </b>{{ isset($data['email']) ? $data['email'] : '' }}</li>
                <li><b>Password: </b>{{ isset($data['pass']) ? $data['pass'] : '' }}</li>
              </ul>
              </span>
            <br />
            <span>
              You can access the system using the following link: <a target="_blank" href="http://5.78.95.23/rts/login" > Remote Tracking System Login  </a>

            </span>
<br />
            <span>
              With RTS, you can simplify your tasks and enhance your efficiency with our state-of-the-art tracking solutions. We are committed to supporting your needs and helping you achieve your goals.
            </span>
         
            <br />
            <span>We look forward to growing and succeeding together.</span>
          </td>
        </tr>
        <tr>
          <td style="text-align: start; padding-top: 1rem; font-size: 14px">
            Best Regards,
          </td>
        </tr>
        <tr>
          <td style="text-align: start; padding-top: 0.1rem; font-size: 14px; font-weight: bold">
            REMOTE TRACKING SYSTEM
          </td>
        </tr>
        <tr>
          <td style="text-align: start; padding-top: 3rem; font-size: 14px">
            _________________
          </td>
        </tr>
      </tbody>
    </table>
  </body>
</html>