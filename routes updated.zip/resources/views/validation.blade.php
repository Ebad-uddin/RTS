<script>
    // settings validations

    // console.log(profile_btn)
    // let profile_btn = document.getElementById('update_profile').addEventListener('click', function(){
    // })
    
</script>