<?php
$activebar = "reports";
?>

@include('group_manager.header')

<div class="iq-top-navbar py-2 rtl-iq-top-navbar ">
    <div class="iq-navbar-custom">
        <nav class="navbar navbar-expand-lg navbar-light p-0 toSetNavBarAll w-100">
            <div class="iq-navbar-logo d-flex align-items-center justify-content-between">
                <i class="ri-menu-line wrapper-menu"></i>
                <!-- Mobile Logo -->
            </div>
            <div class="iq-search-bar device-search">
                <h4 class="main_content_title ps-3">Reports</h4>
            </div>
            @include('group_manager.tooltip')
            <!-- <div class="d-xxl-none d-xl-none d-lg-none d-md-block d-sm-block d-block">
                    <ul class="align-items-center d-flex gap-4 list-unstyled text-decoration-none m-0">
                        <li>
                            <button class="nav-AddNew-Button btn btn-primary" type="button" data-bs-toggle="modal" data-bs-target="#exampleModal">Create Task</button>
                        </li>
                    </ul>
                </div> -->
        </nav>
    </div>
</div>



<div class="content-page rtl-page">
    <div class="container-fluid mt-4">
        <div class="row UserPage">
        </div>
    </div>
</div>

@include('group_manager.footer')