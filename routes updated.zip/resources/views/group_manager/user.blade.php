<?php
$activebar = "users";
?>

@include('group_manager.header')
    <div class="iq-top-navbar py-2 rtl-iq-top-navbar ">
        <div class="iq-navbar-custom">
            <nav class="navbar navbar-expand-lg navbar-light p-0 toSetNavBarAll w-100">
                <div class="iq-navbar-logo d-flex align-items-center justify-content-between">
                    <i class="ri-menu-line wrapper-menu"></i>
                    <!-- Mobile Logo -->
                </div>
                <div class="iq-search-bar device-search">
                    <h4 class="main_content_title ps-3">Users</h4>
                </div>
                @include('group_manager.tooltip')
                <div class="d-xxl-none d-xl-none d-lg-none d-md-block d-sm-block d-block">
                    <ul class="align-items-center d-flex gap-4 list-unstyled text-decoration-none m-0">
                        <li>
                            <button class="nav-AddNew-Button btn btn-primary" type="button" data-bs-toggle="modal" data-bs-target="#exampleModal">Create Task</button>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
    </div>



    <div class="content-page rtl-page">
        <div class="container-fluid mt-4">
            <div class="row UserPage">
                <div class="col-12">
                    <div class="row mt-4">
                        <div class="col-12 ">
                            <div class="bg-white p-3 index-TablePage">
                                <div class="mb-3">
                                    <div class="align-items-center d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column justify-content-between toSetFilterIcon">
                                        <div class="d-flex align-items-center gap-3">
                                            <h4 class="file-Heading">
                                                All Workers
                                            </h4>
                                            <a href="#" class="text-decoration-none">
                                                <button  data-bs-target=".AddWorkerModal" data-bs-toggle="modal" class="btn btn-secondary AllWorkerPageButton"><svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                        <path d="M2.8125 9H15.1875M9 2.8125V15.1875" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                    </svg>
                                                </button>
                                            </a>
                                        </div>

                                    </div>
                                </div>
                                <div class="table-responsive">
                                    <table id="" class="dataTable table-responsive stripe w-100 ">
                                        <thead>
                                        <tr>
                                            <th class="text-start">  S.No </th>  
                                            <th class="text-start">Date Added</th>
                                            <th class="text-start">Name</th>
                                            <th class="text-start">Training Level</th>
                                            <th class="text-start">Total Task</th>
                                            <th class="text-start">Last Online</th>
                                            <th></th>  
                                        </tr>
                                        </thead>
                                        <tbody>
                                            @foreach ($user_data as $k=>$item)
                                           <tr>
                                            <td>
                                              <p  class="table-MainHeading" >
                                                {{ $k+1 }}
                                              </p>
                                            </td>
                                            <td>
                                                @php
                                                $timestamp = (strtotime($item->created_at));
                                                $date = date('Y.j.n', $timestamp);
                                                $time = date('H:i:s', $timestamp);
                                                @endphp
                                                <p id="dateAdded" class="p-0 m-0 table-MainHeading mb-1">
                                                    {{$date}}
                                                </p>
                                                <p class="p-0 m-0 table-SubHeading">
                                                    {{$time}}
                                                </p>
                                            </td>
                                            <td>
                                                <p id="name" class="p-0 m-0 table-MainHeading mb-1">
                                                    {{isset($item->f_name) && isset($item->l_name) ? $item->f_name . ' ' . $item->l_name : '-'}}
                                                </p>
                                                <p id="email" class="p-0 m-0 table-SubHeading">
                                                    {{isset($item->email) ? $item->email : '-'}}
                                                </p>
                                            </td>
                                            <td>
                                                <p id="training_level" class="p-0 m-0 table-MainHeading">
                                                    {{isset($item->training_level) ? $item->training_level : '-'}}
                                                </p>
                                            </td>
                                            <td>
                                                <p class="p-0 m-0 table-MainHeading">
                                                    {{$item->tasks}}
                                                </p>
                                            </td>
                                            <td>
                                                <p class="p-0 m-0 table-MainHeading">
                                                    @php
                                                    // $lastLoginTime = strtotime($item->last_login);
                                                    // $currentTime = time();
                                                    // $timeDifferenceSeconds = $currentTime - $lastLoginTime;
                                                    // $minutes = floor(($timeDifferenceSeconds % 3600) / 60);
                                                    // $hours = floor($timeDifferenceSeconds / 3600);
                                                    // $seconds = $timeDifferenceSeconds % 60;

                                                    // Convert to a human-readable format
                                                    // if ($minutes < 1) {
                                                    //     $timeDifference = 'Just now';
                                                    // } elseif ($minutes < 60) {
                                                    //     $timeDifference = $minutes .' min ago';
                                                    // } elseif ($minutes > 60) {
                                                    //     $timeDifference = $hours . ' hours ago';
                                                    // } else{
                                                    //     $timeDifference = $hours;
                                                    // }
                                                @endphp



                                                </p>
                                            </td>
                                            <td>
                                                <div class="tableButtonSetting">
                                                    <div class="btn-group dropstart">
                                                        <a href="#" class="dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false" >
                                                            <img src="{{asset('public/assets/icons/DotsThreeOutline.svg')}}" alt="">
                                                        </a>
                                                        <ul class="dropdown-menu tosetWidh-Dropdown">
                                                            <li><a class="dropdown-item  togivepaddingLeft" href="{{route('group_manager.user_view',['id' => $item->id])}}">View</a></li>
                                                            <li><a class="dropdown-item  togivepaddingLeft" href="#" data-bs-toggle="modal"  onclick="del_user('{{ $item->id }}')"  type="button">Delete</a></li>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                           @endforeach
                                        </tbody>

                                    </table>

                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

    {{-- add worker modal start --}}
<div class="modal fade AddWorkerModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Add User</h5>
               <button style="border:none !important;" type="button" class="btn-secondary " data-bs-dismiss="modal" aria-label="Close"> <i class="fa-regular fa-x"></i> </button>
            </div>
            <form action="{{ route('groupmanager.addWorker') }}" id="addWorkerForm" method="POST"
                enctype="multipart/form-data">
                @csrf
                <div class="modal-body">
                    <div class="row">

                        <div class="col-sm-12 col-md-4 col-lg-3 col-xl-3 col-xxl-3 col-12">
                            <div
                                class="d-flex align-items-center flex-column justify-content-center position-relative h-100">
                                <div class="d-flex ">
                                    <div class="avatar-upload">
                                        <div class="avatar-edit">
                                            <label for="imageUpload"></label>
                                        </div>
                                        <div class="avatar-preview">
                                            <div 
                                                class="imagePreview" id="imagePreview">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="d-flex align-items-center position-absolute">
                                    <label for="imageUpload" class="upload_picture">
                                        <div name="image"
                                            class="avatar-edit d-flex justify-content-center align-items-center">
                                            <i class="fi fi-rr-upload mt-1"></i>
                                            Upload Picture
                                        </div>
                                    </label>
                                    <input type="file" id="imageUpload" name="image" accept=".png, .jpg, .jpeg"
                                        style="display: none;">
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-8 col-lg-4 col-xl-4 col-xxl-4 col-12">
                            <div class="row">
                                <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12">
                                    <input type="hidden" value="{{Auth::id()}}" name="creator_id">
                                    <div class="mb-3">
                                        <label class="userview_label">First Name</label>
                                        <input type="text" name="f_name" value="{{old('f_name')}}" class="form-control w-100"
                                            placeholder="Please enter your first name">
                                    </div>
                                </div>
                                <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12">
                                    <div class="mb-3">
                                        <label class="userview_label">Last Name</label>
                                        <input type="text" name="l_name" value="{{old('l_name')}}" class="form-control w-100"
                                            placeholder="Please enter your last name">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-12 col-lg-5 col-xl-5 col-xxl-5 col-12">
                            <div class="mb-3">
                                <label class="userview_label">Email Address</label>
                                <input type="text" name="email" id="useremail" value="{{old('email')}}" class="form-control w-100"
                                    placeholder="Please enter your email">
                                    <span class="text-danger" id="emailerror"></span>
                            </div>
                            <div class="mb-3">
                                <label class="userview_label">Main Phone</label>
                                <input type="number" value="{{old('phone')}}" name="phone" class="form-control w-100"
                                    placeholder="Please enter your number">
                            </div>
                        </div>
                    </div>
                    <div class="row mt-2 mb-2 auto_row">
                        <div class="col-sm-12 col-md-12 col-lg-6 col-xl-6 col-xxl-6 col-12 auto_pad">
                            <div class="row">
                                <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12">
                                    <div class="mb-3">
                                        <div>
                                            <label class="userview_label">Residential Address</label>
                                        </div>
                                        <input type="text" value="{{old('address')}}" name="address" class="form-control w-100"
                                            placeholder="Please enter your residential address">
                                    </div>
                                </div>
                                <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12">
                                    <div class="mb-3">
                                        <label class="userview_label">Training Level</label>
                                        <input type="text" value="{{old('training_level')}}" name="training_level" class="form-control w-100"
                                            placeholder="Please enter your training level">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-12 col-lg-6 col-xl-6 col-xxl-6 col-12 auto_pad">
                            <div class="row">
                                <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12">
                                    <div class="mb-3">
                                        <div class="mb-3">
                                            <div>
                                                <label class="userview_label">Role</label>
                                            </div>
                                            <select name="role" class="js-select2"
                                                data-minimum-results-for-search="Infinity">
                                                <option value="worker">Worker</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12">
                                    <div class="mb-3">
                                        <label class="userview_label">Status</label>
                                        <input type="text" value="{{old('status')}}" name="status" class="form-control w-100"
                                            placeholder="" value="">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12 auto_pad">
                            <div class="mb-3">
                                <label class="userview_label">Comments</label>
                                <textarea type="text" value="{{old('comment')}}" name="comment" class="form-control w-100 form_textarea"
                                    placeholder="Please enter some comments"></textarea>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" id="addWorkerbtn" onclick="Check_Email()" class="btn btn-primary">Add</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- user Delete Modal Start -->

<div class="modal fade" id="user_del" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <form action="{{ route('groupmanager.delete_user_data') }}" method="POST">
            @csrf
            <div class="modal-content">
                <div class="modal-header">
                    <input type="hidden" name="del_user_id" id="del_user_id">
                    <h5 class="modal-title" id="exampleModalLabel">Delete Confirmation</h5>
                   <button style="border:none !important;" type="button" class="btn-secondary " data-bs-dismiss="modal" aria-label="Close"> <i class="fa-regular fa-x"></i> </button>
                </div>
                <div class="modal-body">
                    <p>Are you sure want to delete?</p>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Yes</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div>
            </div>
        </form>
    </div>
</div>
<!--user Delete Modal End -->



{{-- add worker modal end --}}

<script>
     function del_user(id) {
        console.log(id);
        $('#del_user_id').val(id)
        $('#group_id').val()
        $('#user_del').modal('show');

    }

</script>

<script>
    function Check_Email(){
      $('#emailerror').text(' ');
        let email  = $('#useremail').val();
        $.ajax({
          url : "{{route('groupmanager.checkEmail')}}",
          type : "POST",
          data : {
              email : email,
              _token : "{{csrf_token()}}"
          },
          success : function(res){
              if(res  == true){
              $('#emailerror').text('Email already exist');
              }else{
                  $('#addWorkerForm').submit();
              }
          }
      })
  }
  </script>

@include('group_manager.footer')
@include('group_manager.groupmanager_script')
