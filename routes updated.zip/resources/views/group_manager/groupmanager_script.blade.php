   <script>
       // create task script
       document.getElementById('task_form_btn').addEventListener('click', function(event) {
           event.preventDefault();
           document.getElementById('task_form').submit();
       });

       // add worker script
    //    document.getElementById('addWorkerbtn').addEventListener('click', function(event) {
    //        event.preventDefault();
    //        document.getElementById('addWorkerForm').submit();
    //    });


       // Role wise fetch users filtration work
    //    var role = $('#role');
    //    var users_table = document.getElementById('users_table');
    //    role.on('change', function(e) {
    //        role_val = e.target.value;
    //        $.ajax({
    //            url: "{{ route('admin.filter_user') }}",
    //            type: 'POST',
    //            data: {
    //                user_role: role_val,
    //                _token: "{{ csrf_token() }}"
    //            },
    //            success: function(reponse) {
    //                console.log(reponse);
    //                users_table.innerHTML = '';
    //                reponse.forEach(e => {
    //                    console.log(e);
    //                    users_table.innerHTML += `<tr>
    //                                         <td>
    //                                             <div class="custom-Radio-Button">
    //                                                 <label class="custom-radio m-0" for="tablec1">
    //                                                     <input type="checkbox" class="customme" name="customRadio" id="tablec1">
    //                                                     <span class="radio-btn"></span>

    //                                                 </label>
    //                                             </div>
    //                                         </td>
    //                                         <td>
    //                                             <p id="dateAdded" class="p-0 m-0 table-MainHeading mb-1">
    //                                                 ${e.created_at}
    //                                             </p>
    //                                         </td>
    //                                         <td>
    //                                             <p id="name" class="p-0 m-0 table-MainHeading mb-1">
    //                                                 ${e.f_name} ${e.l_name}
    //                                             </p>
    //                                             <p id="email" class="p-0 m-0 table-SubHeading">
    //                                                 ${e.email}
    //                                             </p>
    //                                         </td>
    //                                         <td>
    //                                             <p id="training_level" class="p-0 m-0 table-MainHeading">
    //                                                 ${e.training_level}
    //                                             </p>
    //                                         </td>
    //                                         <td>
    //                                             <p class="p-0 m-0 table-MainHeading">
    //                                                 17
    //                                             </p>
    //                                         </td>
    //                                         <td>
    //                                             <p class="p-0 m-0 table-MainHeading">
    //                                                 1 min ago
    //                                             </p>
    //                                         </td>
    //                                         <td>
    //                                             <div class="tableButtonSetting">
    //                                                 <div class="btn-group dropstart">
    //                                                     <a href="#" class="dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false" >
    //                                                         <img src="../assets/icons/DotsThreeOutline.svg" alt="">
    //                                                     </a>
    //                                                     <ul class="dropdown-menu tosetWidh-Dropdown">
    //                                                         <li><a class="dropdown-item  togivepaddingLeft" href="user-view.php">View</a></li>
    //                                                         <li><a class="dropdown-item  togivepaddingLeft" href="#" data-bs-toggle="modal" data-bs-target="#DeleteModal" type="button">Delete</a></li>
    //                                                     </ul>
    //                                                 </div>
    //                                             </div>
    //                                         </td>
    //                                     </tr>`

    //                });



    //            }
    //        })
    //    });

   </script>
