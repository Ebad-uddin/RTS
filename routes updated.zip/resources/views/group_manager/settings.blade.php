<?php
$activebar = 'settings';
?>
@include('group_manager.header')
<style>
    .nav-pills .nav-link.active {
        background: linear-gradient(180deg, rgb(233, 34, 21) 0%, rgb(131, 19, 12) 100%);
        padding: 9px 17px 9px 15px !important;
        border: 3px solid #FF4F43;
        border-radius: 6px;
        box-shadow: rgba(0, 0, 0, 0.1) 0px 4px 6px -1px, rgba(0, 0, 0, 0.06) 0px 2px 4px -1px;
        color: #fff;
        width: max-content;
        white-space: nowrap;
    }

    .nav-pills .nav-link.active:hover {
        color: #fff;
    }

    .nav-pills .nav-link {
        color: #88909F;
    }

    .nav-pills .nav-link:hover {
        color: #88909F;
    }
</style>
<div class="iq-top-navbar py-2 rtl-iq-top-navbar ">
    <div class="iq-navbar-custom">
        <nav class="navbar navbar-expand-lg navbar-light p-0 toSetNavBarAll w-100">
            <div class="iq-navbar-logo d-flex align-items-center justify-content-between">
                <i class="ri-menu-line wrapper-menu"></i>
                <!-- Mobile Logo -->
            </div>
            <div class="iq-search-bar device-search">
                <h4 class="main_content_title">Settings</h4>
            </div>
            @include('group_manager.tooltip')
        </nav>
    </div>
</div>



<div class="content-page rtl-page">
    <div class="container-fluid mt-4">
        <div class="row">
            <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12">
                <div class="mt-4">
                    <div class="toSetSettingsBackground">
                        <div class="row">
                            <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12">
                                <div class="w-100 d-flex justify-content-center align-items-center">
                                    <ul class="nav nav-pills settings_nav d-flex align-items-center" id="pills-tab"
                                        role="tablist">
                                        <li class="nav-item navsettingBtntwo" role="presentation">
                                            <button class="nav-link active navsettingBtntwo" id="pills-home-tab" data-bs-toggle="pill"
                                                data-bs-target="#pills-profile_setting" type="button" role="tab"
                                                aria-controls="pills-home" aria-selected="true"><i
                                                    class="fa-regular fa-user"></i> Profile Settings</button>
                                        </li>
                                        <li class="nav-item navsettingBtntwo" role="presentation">
                                            <button class="nav-link navsettingBtntwo" id="pills-profile-tab" data-bs-toggle="pill"
                                                data-bs-target="#pills-RolesManagement" type="button" role="tab"
                                                aria-controls="pills-profile" aria-selected="false"><i
                                                    class="fa-solid fa-lock"></i> Security Settings</button>
                                        </li>

                                    </ul>
                                </div>
                            </div>
                            <div class="col-sm-12 col-md-12 col-lg-12 col-xl-912col-xxl-12 col-12">
                                <div class="tab-content px-3 py-2 settings_tab_content" id="v-pills-tabContent">
                                    <div class="tab-pane fade show active" id="pills-profile_setting" role="tabpanel"
                                        aria-labelledby="v-pills-home-tab">
                                        <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12">
                                            <div class="mt-2 mb-2 py-2">
                                                <h4 class="settings_tab_head4">Personal Details</h4>
                                            </div>
                                        </div>
                                        <form action="{{ route('groupmanager.settings_update') }}" method="POST"
                                            enctype="multipart/form-data">
                                            @csrf
                                            <div class="row">
                                                <div class="col-sm-12 col-md-4 col-lg-3 col-xl-3 col-xxl-3 col-12">
                                                    <div
                                                        class="d-flex align-items-center flex-column justify-content-center position-relative h-100">
                                                        <div class="d-flex ">
                                                            <div class="avatar-upload">
                                                                <div class="avatar-edit">
                                                                    <label for="imageUpload"></label>
                                                                </div>
                                                                <div class="avatar-preview">
                                                                    <div style="background-image: url('{{ url('storage/app/uploads/' . $user_data->image) }}')"
                                                                        class="imagePreview" id="imagePreview">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="d-flex align-items-center position-absolute">
                                                            <label for="imageUpload" class="upload_picture">
                                                                <div class="avatar-edit">
                                                                    <i class="fi fi-rr-upload mt-1"></i>
                                                                    Upload Picture
                                                                </div>
                                                            </label>
                                                            <input type="file" name="image" id="imageUpload"
                                                                accept=".png, .jpg, .jpeg" style="display: none;">
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-sm-12 col-md-8 col-lg-4 col-xl-4 col-xxl-4 col-12">
                                                    <div class="row">
                                                        <div
                                                            class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12">
                                                            <div class="mb-3">
                                                                <label class="settings_tab_label">First Name</label>
                                                                <input type="text" name="f_name" id="f_name"
                                                                    class="form-control w-100"
                                                                    value="{{ isset($user_data->f_name) ? $user_data->f_name : '-' }}"
                                                                    placeholder="Please enter your first name">
                                                                <input type="hidden" name="user_id"
                                                                    value="{{ $user_data->id }}">
                                                            </div>
                                                        </div>
                                                        <div
                                                            class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12">
                                                            <div class="mb-3">
                                                                <label class="settings_tab_label">Last Name</label>
                                                                <input type="text" name="l_name" id="l_name"
                                                                    class="form-control w-100"
                                                                    value="{{ isset($user_data->l_name) ? $user_data->l_name : '-' }}"
                                                                    placeholder="Please enter your last name">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-sm-12 col-md-12 col-lg-5 col-xl-5 col-xxl-5 col-12">
                                                    <div class="mb-3">
                                                        <label class="settings_tab_label">Email Address</label>
                                                        <input type="text" name="email" id="email"
                                                            class="form-control w-100"
                                                            value="{{ isset($user_data->email) ? $user_data->email : '-' }}"
                                                            placeholder="Please enter your email">
                                                    </div>
                                                    <div class="mb-3">
                                                        <label class="settings_tab_label">Main Phone</label>
                                                        <input type="number" name="phone" id="phone"
                                                            class="form-control w-100"
                                                            value="{{ isset($user_data->phone) ? $user_data->phone : '-' }}"
                                                            placeholder="Please enter your number">
                                                    </div>
                                                </div>
                                                <div
                                                    class="col-12 auto_pad">
                                                    <div class="row">
                                                        <div
                                                            class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12">
                                                            <div class="mb-3">
                                                                <div>
                                                                    <label class="settings_tab_label">Residential
                                                                        Address</label>
                                                                </div>
                                                                <input type="text" name="address" id="address"
                                                                    class="form-control w-100"
                                                                    value="{{ isset($user_data->address) ? $user_data->address : '-' }}"
                                                                    placeholder="Please enter your residential address">
                                                            </div>
                                                        </div>
                                                        {{-- <div
                                                                class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12">
                                                            <div class="mb-3">
                                                                <label class="settings_tab_label">Training Level</label>
                                                                <input type="text" class="form-control w-100" value="{{isset($item->training_level) ? $item->training_level : '-'}}"
                                                                       placeholder="Please enter your training level">
                                                            </div>
                                                        </div> --}}
                                                    </div>
                                                </div>
                                                <div
                                                    class="col-sm-12 col-md-12 col-lg-6 col-xl-6 col-xxl-6 col-12 auto_pad">
                                                    <div class="row">
                                                        <div
                                                            class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12">
                                                            {{-- <div class="mb-3">
                                                                <div>
                                                                    <label class="settings_tab_label">Role</label>
                                                                </div>
                                                                <select class="js-select2 w-100"
                                                                        data-minimum-results-for-search="Infinity">
                                                                    <option value="">Worker</option>
                                                                    <option value="">Worker</option>
                                                                    <option value="">Worker</option>
                                                                    <option value="">Worker</option>
                                                                </select>
                                                            </div> --}}
                                                        </div>
                                                        {{-- <div
                                                                class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12">
                                                            <div class="mb-3">
                                                                <label class="settings_tab_label">Status</label>
                                                                <input type="text" class="form-control w-100"
                                                                       placeholder="Please enter your status">
                                                            </div>
                                                        </div> --}}
                                                     
                                                    </div>
                                                </div>




                                            </div>
                                            <div class="row" >
                                                <div class=" col-12">
                                                    <div class="mb-3 d-flex justify-content-end">
                                                        <button type="submit" id="update_profile"
                                                            class="btn btn-secondary">Update
                                                            Settings</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>

                                    <div class="tab-pane fade" id="pills-RolesManagement" role="tabpanel"
                                        aria-labelledby="v-pills-profile-tab">
                                        <form action="{{ route('groupmanager.updatePassword') }}" method="POST">
                                            @csrf
                                            <div class="row auto_row">

                                                <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12">
                                                    <div class="mt-2 mb-4">
                                                        <h4 class="settings_tab_head4">Password Settings</h4>
                                                    </div>
                                                </div>
                                                <div class="col-sm-12 col-md-12 col-lg-6 col-xl-6 col-xxl-6 col-12">
                                                    <div class="mb-3">
                                                        <label class="settings_tab_label">Current Password</label>
                                                        <input type="password" class="form-control w-100 form_input"
                                                            id="CurrentPassword" name="CurrentPassword"
                                                            placeholder="Please enter your password">
                                                        <span onclick="password_show_hide()"
                                                            class="toggle_settings_password position-absolute">
                                                            <i class="fas fa-eye-slash eye-border"
                                                                id="show_eye_current"></i>
                                                            <i class="fas fa-eye d-none eye-border"
                                                                id="hide_eye_current"></i>
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="col-sm-12 col-md-12 col-lg-6 col-xl-6 col-xxl-6 col-12">
                                                    <div class="mb-3">
                                                        <label class="settings_tab_label">New Password</label>
                                                        <input type="password" class="form-control w-100 form_input"
                                                            id="NewPassword" name="NewPassword"
                                                            placeholder="Please enter your password">
                                                        <span onclick="password_showhide()"
                                                            class="toggle_settings_password position-absolute">
                                                            <i class="fas fa-eye-slash eye-border"
                                                                id="show_eye_new"></i>
                                                            <i class="fas fa-eye d-none eye-border"
                                                                id="hide_eye_new"></i>
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="col-sm-12 col-md-12 col-lg-6 col-xl-6 col-xxl-6 col-12">
                                                    <div class="mb-3">
                                                        <label class="settings_tab_label">Confirm New Password</label>
                                                        <input type="password" class="form-control w-100 form_input"
                                                            id="NewPassword2" name="ConfirmPassword"
                                                            placeholder="Please enter your password">
                                                        <span onclick="password_showhide2()"
                                                            class="toggle_settings_password position-absolute">
                                                            <i class="fas fa-eye-slash eye-border"
                                                                id="show_eye_new2"></i>
                                                            <i class="fas fa-eye d-none eye-border"
                                                                id="hide_eye_new2"></i>
                                                        </span>
                                                    </div>
                                                </div>

                                                <div class="col-12">
                                                    <div class="mb-3 d-flex justify-content-end">
                                                        <button type="submit" class="btn btn-secondary">Update
                                                            Password</button>
                                                    </div>
                                                </div>
                                            </div>

                                    </div>
                                    </form>
                                </div>


                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>
</div>

@include('group_manager.footer')
