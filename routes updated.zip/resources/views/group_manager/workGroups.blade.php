<?php
$activebar = "groups";
?>

@include('group_manager.header')
    <div class="iq-top-navbar py-2 rtl-iq-top-navbar ">
        <div class="iq-navbar-custom">
            <nav class="navbar navbar-expand-lg navbar-light p-0 toSetNavBarAll w-100">
                <div class="iq-navbar-logo d-flex align-items-center justify-content-between">
                    <i class="ri-menu-line wrapper-menu"></i>
                    <!-- Mobile Logo -->
                </div>
                <div class="iq-search-bar device-search">
                    <h4 class="main_content_title ps-3">Work Groups</h4>
                </div>
                @include('group_manager.tooltip')
                <div class="d-xxl-none d-xl-none d-lg-none d-md-block d-sm-block d-block">
                    <ul class="align-items-center d-flex gap-4 list-unstyled text-decoration-none m-0">
                        <li>
                            <button class="nav-AddNew-Button btn btn-primary" type="button" data-bs-toggle="modal" data-bs-target="#exampleModal">Create Task</button>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
    </div>



    <div class="content-page rtl-page">
        <div class="container-fluid mt-4">
            <div class="row UserPage">
                <div class="col-12">
                    <div class="row mt-4">
                        <div class="col-12 ">
                            <div class="bg-white p-3 index-TablePage">
                                <div class="mb-3">
                                    <div class="align-items-center d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column justify-content-between toSetFilterIcon">
                                        <div class="d-flex align-items-center gap-3">
                                            <h4 class="file-Heading">
                                                All Groups
                                            </h4>

                                        </div>
                                        <div class="TogiveFullWidth d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column gap-2 mt-xxl-0 mt-xl-0 mt-lg-0 mt-md-0 mt-sm-3 mt-3">
<!--                                            <select name="" class="js-select2" data-minimum-results-for-search="Infinity" >-->
<!--                                                <option value="All Task">All Task</option>-->
<!--                                                <option value="Staff Task">Staff Task</option>-->
<!--                                                <option value="My Task">My Task</option>-->
<!--                                            </select>-->
                                           <!-- <button  class="FilterButtonSetting btn btn-secondary d-flex gap-2 align-items-center" >
                                                Sort by <svg width="18" height="18" viewBox="0 0 18 18" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                    <path d="M3.375 13.4995H7.3125M10.125 11.812L12.9375 14.6245M12.9375 14.6245L15.7499 11.8125M12.9375 14.6245L12.9375 7.87451M3.375 8.99951H8.43743M3.375 4.49951H12.9374"  stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                                </svg>
                                            </button> -->

                                            <!--                                                 <input type="text" class="form-control">-->
                                            <!--                                            <form action="" class="p-0 m-0 position-relative">-->
                                            <!--                                                <img style="" class="GlobalInputIconSetting position-absolute" src="../assets/icons/MagnifyingGlass.svg" alt="">-->
                                            <!--                                                <input style="" type="text" class="form-control GlobalInputSetting" placeholder="s">-->
                                            <!--                                            </form>-->
                                        </div>
                                    </div>
                                </div>
                                <div class="table-responsive">
                                    <table id="" class="dataTable table-responsive stripe w-100 ">
                                        <thead>
                                        <tr>
                                           <th>  S.No </th>  
                                            <th class="text-start">Created On</th>
                                            <th class="text-start">Group Name</th>
                                            <th class="text-start">Address</th>
                                            <th class="text-start">Group Members</th>
                                            <th></th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                            @foreach ($group_data as $item)
                                            <tr>
                                                <td>
                                                    <div class="custom-Radio-Button">
                                                        <label class="custom-radio m-0" for="tablec1">
                                                            <input type="checkbox" class="customme" name="customRadio"
                                                                id="tablec1">
                                                            <span class="radio-btn"></span>

                                                        </label>
                                                    </div>
                                                </td>
                                                <td>
                                                    @php
                                                        $timestamp = strtotime($item->created_at);
                                                        $date = date('Y.j.n', $timestamp);
                                                        $time = date('H:i:s', $timestamp);
                                                    @endphp
                                                    <p class="p-0 m-0 table-MainHeading mb-1">
                                                        {{ $date }},
                                                    </p>
                                                    <p class="p-0 m-0 table-SubHeading">
                                                        {{ $time }}
                                                    </p>
                                                </td>
                                                <td>
                                                    <p class="p-0 m-0 table-MainHeading mb-1">
                                                        {{ $item->gorup_name }}
                                                    </p>
                                                    <p class="p-0 m-0 table-SubHeading">
                                                        {{ $item->email }}
                                                    </p>
                                                </td>
                                                <td>
                                                    <p class="p-0 m-0 table-MainHeading">
                                                        {{ $item->address }}
                                                    </p>
                                                </td>
                                                <td colspan="2">
                                                    <div class="d-flex">
                                                        @foreach ($item->members as $member)
                                                <div>
                                                    <div class="tale-small-image timage-1">
                                                        @if ($member != null)
                                                        <img src="{{ url('storage/app/uploads/'.$member->image) }}" alt="{{$member->image}}">
                                                        @else
                                                        <img src="{{ url('storage/app/uploads/placeholder.jpg') }}" alt="no image">
                                                        @endif
                                                    </div>
                                                </div>
                                                @endforeach

                                                    </div>
                                                </td>
                                                <td>
                                                    <div class="tableButtonSetting">
                                                        <div class="btn-group dropstart">
                                                            <a href="#" class="dropdown-toggle" type="button"
                                                                data-bs-toggle="dropdown" aria-expanded="false">
                                                                <img src="{{ asset('public/assets/icons/DotsThreeOutline.svg') }}"
                                                                    alt="">
                                                            </a>
                                                            <ul class="dropdown-menu tosetWidh-Dropdown">
                                                                <li><a class="dropdown-item  togivepaddingLeft"
                                                                        data-bs-toggle="modal"
                                                                        onclick="Edit_group('{{ $item->id }}')">View</a>
                                                                </li>
                                                                <li><a class="dropdown-item  togivepaddingLeft"
                                                                    href="javascript:void(0)" onclick="del_group('{{ $item->id }}')"
                                                                    data-bs-toggle="modal"
                                                                    type="button">Delete</a></li> 
                                                            </ul>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        @endforeach
                                        </tbody>

                                    </table>

                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="EditGroup" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title group_title" id="exampleModalLabel">Add Group Members</h5>
                   <button style="border:none !important;" type="button" class="btn-secondary " data-bs-dismiss="modal" aria-label="Close"> <i class="fa-regular fa-x"></i> </button>
                </div>
                <div class="modal-body">
                    <form action="{{ route('groupmanager.update_group') }}" method="POST" id="add_worker">
                        @csrf
                        <div class="row">

                            <div class="col-sm-12 col-md-12 col-lg-12 col-xl-12 col-xxl-12 col-12">
                                <div class="mb-3">
                                    <div>
                                        <label class="group_label">Group Members</label>
                                    </div>
                                    <input type="hidden" value="{{$group_data[0]->id}}" name="group_id">
                                    <select name="group_members[]" id="group_members"
                                        class="form-select w-100 js-example-basic-multiple-limit"
                                        data-minimum-results-for-search="Infinity" multiple="multiple">
                                        @foreach ($workers as $item)
                                        <option value="{{$item->id}}" selected>{{isset($item->f_name) && isset($item->l_name) ? $item->f_name . ' ' . $item->l_name : '-'}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>

                        </div>
                        <div class="modal-footer">
                            <button type="submit" id="add_worker_btn" class="btn btn-secondary"
                                data-bs-dismiss="modal">Update</button>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>

    
<!-- group Delete Modal Start -->

<div class="modal fade" id="group_del" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <form action="{{route('groupmanager.del_group')}}" method="POST">
            @csrf
            <div class="modal-content">
                <div class="modal-header">
                    <input type="hidden" name="del_group_id" id="del_group_id">
                    <h5 class="modal-title" id="exampleModalLabel">Delete Confirmation</h5>
                   <button style="border:none !important;" type="button" class="btn-secondary " data-bs-dismiss="modal" aria-label="Close"> <i class="fa-regular fa-x"></i> </button>
                </div>
                <div class="modal-body">
                    <p>Are you sure want to delete?</p>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Yes</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div>
            </div>
        </form>
    </div>
</div>
<!--group Delete Modal End -->

    <script>
        function Edit_group(id) {
            console.log(id)
            $.ajax({
                url: "{{ route('groupmanager.edit_group') }}",
                type: "POST",
                data: {
                    group_id: id,
                    _token: "{{ csrf_token() }}"
                },
                success: function(res) {
                    console.log(res);


                    $('#EditGroup').modal('show');
                  }
            })
        }

        function del_group(id){
        console.log(id);
        $('#del_group_id').val(id)
        $('#group_del').modal('show');

    }
    </script>

@include('group_manager.footer')
