<div class="d-flex align-items-center">
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav ml-auto navbar-list align-items-center d-flex gap-4">
            <li>
                <button class="nav-AddNew-Button btn btn-primary" type="button" data-bs-toggle="modal" data-bs-target="#create_task_modal">Create Task</button>
            </li>
            <li class="d-flex align-items-center gap-3 Signout-Setting">
              <div class="signout-Image">
                @if (!empty(Auth::user()->image))
                <img src="{{url('storage/app/uploads/' . Auth::user()->image)}}" alt="" class="w-100 h-100">
                @else
                <img src="{{url('storage/app/uploads/placeholder.jpg')}}" alt="" class="w-100 h-100">
                @endif
              </div>
                <div class="d-flex align-items-center gap-3">
                   <div>
                       <h4 class="p-0 m-0 signout-Name">{{Auth::user()->f_name . ' ' .Auth::user()->l_name }}</h4>
                    <p class="p-0 m-0 signout-Role">Group Manager</p>
                   </div>
                   <form action="{{ route('logout') }}" method="POST" id="logout-form">
                    @csrf
                </form>
        <a onclick="event.preventDefault(); document.getElementById('logout-form').submit();"
        href="#"><img src="{{ asset('public/assets/icons/SignOut.svg') }}" alt="">
        </a>
                </div>
            </li>
        </ul>
    </div>
</div>


<script>
    let varLocation = window.location.pathname
    let btn = document.querySelector('.add_new_btn')
    if(varLocation.includes('index')  || varLocation.includes('chat') || varLocation.includes('Taskmanagement')) {
            btn.style.display = 'block'
    } else {
        btn.style.display = 'none'

    }
</script>
