<?php
$activebar = 'tasks';
?>
@include('group_manager.header')

<div class="iq-top-navbar py-2 rtl-iq-top-navbar ">
    <div class="iq-navbar-custom">
        <nav class="navbar navbar-expand-lg navbar-light p-0 toSetNavBarAll w-100">
            <div class="iq-navbar-logo d-flex align-items-center justify-content-between">
                <i class="ri-menu-line wrapper-menu"></i>
                <!-- Mobile Logo -->
            </div>
            <div class="iq-search-bar device-search">
                <h4 class="main_content_title ps-3">Task Management</h4>
            </div>
            @include('group_manager.tooltip')
            <div class="d-xxl-none d-xl-none d-lg-none d-md-block d-sm-block d-block">
                <ul class="align-items-center d-flex gap-4 list-unstyled text-decoration-none m-0">
                    <li>
                    <button class="nav-AddNew-Button btn btn-primary" type="button" data-bs-toggle="modal" data-bs-target="#create_task_modal">Create Task</button>
                    </li>
                </ul>
            </div>
        </nav>
    </div>
</div>


<div class="content-page rtl-page">
    <div class="container-fluid mt-4">
        <div class="row UserPage">
            <div class="col-12">
                <div class="PageViewTable px-3 py-4">
                    <div class="row mt-4">
                        <div
                            class="order-xxl-1 order-xl-1 order-lg-1 order-md-2 order-sm-2 order-2 col-xxl-8 col-xl-8 col-lg-8 col-md-12 col-sm-12 col-12 mt-xxl-0 mt-xl-0 mt-lg-0 mt-md-4 mt-sm-4 mt-4">
                            <div class="">
                                <div class="row TaskViewtogIveBorder">
                                    <div class="col-12">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div>
                                                <h4 class="fileViewTitle mb-1">Task ID:
                                                    {{ isset($Task[0]->task_id) ? $Task[0]->task_id : '' }}
                                                </h4>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="col-xxl-8 col-xl-8 col-lg-8 col-md-6 col-sm-12 col-12 mt-4">
                                        <div
                                            class="TaskView-Left d-flex align-items-start justify-content-between flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-row flex-column">
                                            <div>
                                                <div>
                                                    <h4 class="Task-sub-Title">Account</h4>
                                                    <p class="Task-sub-text">
                                                        {{ isset($Task[0]->account) ? $Task[0]->account : '-' }}</p>
                                                </div>
                                                <div>
                                                    <h4 class="Task-sub-Title">Task Title</h4>
                                                    <p class="Task-sub-text">
                                                        {{ isset($Task[0]->task_name) ? $Task[0]->task_name : '-' }}</p>
                                                </div>
                                                <div>
                                                    <h4 class="Task-sub-Title">Company</h4>
                                                    <p class="Task-sub-text">
                                                        {{ isset($Task[0]->company) ? $Task[0]->company : '-' }}</p>
                                                </div>
                                            </div>
                                            <div>
                                                <div>
                                                    <h4 class="Task-sub-Title">Department</h4>
                                                    <p class="Task-sub-text">
                                                        {{ isset($Task[0]->department) ? $Task[0]->department : '-' }}
                                                    </p>
                                                </div>
                                                <div>
                                                    <h4 class="Task-sub-Title">Vehicle Category</h4>
                                                    <p class="Task-sub-text">
                                                        {{ isset($Task[0]->vehicle_category) ? $Task[0]->vehicle_category : '-' }}
                                                    </p>
                                                </div>
                                            </div>
                                            <div>
                                                <div>
                                                    <h4 class="Task-sub-Title">T-Level</h4>
                                                    <p class="Task-sub-text">
                                                        {{ isset($Task[0]->t_level) ? $Task[0]->t_level : '-' }}</p>
                                                </div>
                                                <div>
                                                    <h4 class="Task-sub-Title">Assigned Workers</h4>
                                                    <a href="#"
                                                        onclick="show_members('{{ $Task[0]->id }}')">
                                                        <p class="Task-sub-text textcolor">
                                                            @php

                                                                $total_members = json_decode($Task[0]->workers);
                                                                if (!empty($total_members)) {
                                                                    echo count($total_members);
                                                                } else {
                                                                    echo 'no members to show';
                                                                }
                                                            @endphp
                                                        </p>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>


                                    {{-- members in task modal start --}}

                                    <div class="modal fade" id="assignedWorkersModal" tabindex="-1"
                                        aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog">

                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel">Assigned Workers</h5>
                                                    <button style="border:none !important;" type="button"
                                                        class="btn-secondary " data-bs-dismiss="modal"
                                                        aria-label="Close"> <i class="fa-regular fa-x"></i> </button>
                                                </div>
                                                <div class="modal-body">
                                                    <ul id="workers">

                                                    </ul>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                    {{-- members in task modal end --}}

                                    <script>
                                        function show_members(id) {
                                            console.log(id);
                                            $.ajax({
                                                url: "{{ route('groupmanager.assignedWorkers') }}",
                                                type: "POST",
                                                data: {
                                                    task_id: id,
                                                    _token: "{{ csrf_token() }}"
                                                },
                                                success: function(res) {
                                                    console.log(res);
                                                    $('#workers').html(' ');
                                                    res.forEach(element => {
                                                        console.log(element.f_name);
                                                        $('#workers').append(`<div class="MainAddeddiv">
                                                       <div class="imagwithName">
                                                       <img src="{{ url('storage/app/uploads') }}/${element.image}"/>
                                                        <li>${element.f_name} ${element.l_name}</li>
                                                        </div>
                                                        <a class="btn btn-primary" href="{{ url('superadmin/EditEmployee') }}/${element.id}">view</a>
                                                        </div>`);
                                                        $('#assignedWorkersModal').modal('show');
                                                    });

                                                }
                                            })
                                        }
                                    </script>


                                    <div class="col-xxl-4 col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12 mt-4">
                                        <div
                                            class="d-flex align-items-end justify-content-xxl-end justify-content-xl-end justify-content-lg-end justify-content-md-start justify-content-sm-start justify-content-start h-100">
                                            <select name="" id="" disabled class="js-select2">
                                                <option value="Created"
                                                    {{ $Task[0]->status == 'Created' ? 'selected' : '' }}>Created
                                                </option>
                                                <option value="Submitted"
                                                    {{ $Task[0]->status == 'Submitted' ? 'selected' : '' }}>Submitted
                                                </option>
                                                <option value="Approved"
                                                    {{ $Task[0]->status == 'Approved' ? 'selected' : '' }}>Approved
                                                </option>
                                                <option value="Rejected"
                                                    {{ $Task[0]->status == 'Rejected' ? 'selected' : '' }}>Rejected
                                                </option>
                                                <option value="Active"
                                                    {{ $Task[0]->status == 'Active' ? 'selected' : '' }}>Active
                                                </option>
                                                <option value="Completed"
                                                    {{ $Task[0]->status == 'Completed' ? 'selected' : '' }}>Completed
                                                </option>
                                                <option value="Expired"
                                                    {{ $Task[0]->status == 'Expired' ? 'selected' : '' }}>Expired
                                                </option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-12 mt-4 Document-Section">
                                        <div
                                            class="d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column align-items-xxl-center align-items-xl-center align-items-lg-center align-items-md-center align-items-sm-start align-items-start justify-content-between">
                                            <h2 class="p-0 m-0 document-heading">
                                                Documents
                                            </h2>
                                            <div
                                                class="d-flex gap-2 align-items-center mt-xxl-0 mt-xl-0 mt-lg-0 mt-md-0 mt-sm-3 mt-3">
                                                <button type="button" data-bs-toggle="modal" data-bs-target="#document"
                                                    class="btn btn-secondary">Upload Document</button>
                                            </div>
                                        </div>

                                        {{-- upload document modal start --}}
                                        <div class="modal fade" id="document" tabindex="-1"
                                            aria-labelledby="exampleModalLabel" aria-hidden="true">
                                            <div class="modal-dialog modal-lg">
                                                <form action="{{ route('groupmanager.update_docments_task') }}"
                                                    method="POST" enctype="multipart/form-data">
                                                    @csrf
                                                    <div class="modal-content">
                                                        <div class="modal-header extendModal">
                                                            <h1 class="modal-title fs-5" id="exampleModalLabel">
                                                                Documents</h1>
                                                            <button type="button" class="btn-close"
                                                                data-bs-dismiss="modal" aria-label="Close"></button>
                                                        </div>
                                                        <div class="modal-body DocumentModal">
                                                            <div class="row">
                                                                <div class="col-12 mt-3">
                                                                    <div id="upd_doc" style="padding-top: .5rem;">
                                                                    </div>
                                                                </div>
                                                                <div class="col-12 mt-3">
                                                                    <input type="hidden" value="{{ $Task[0]->id }}"
                                                                        name="task_id">
                                                                </div>

                                                            </div>

                                                        </div>
                                                        <div class="modal-footer">
                                                            <!--                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>-->
                                                            <button type="submit"
                                                                class="btn btn-secondary">Save</button>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                        {{-- upload document modal end --}}




                                        <div class="row">

                                            @if ($allFiles != null)
                                                @foreach ($allFiles['files'] as $file)
                                                    <div class="col-6 mt-3">
                                                        <div
                                                            class="DownloadIconSetting d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column align-items-xxl-center align-items-xl-center align-items-lg-center align-items-md-center align-items-sm-start align-items-start justify-content-between">
                                                            <div
                                                                class="d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column gap-3">
                                                                <div>
                                                                    @if (str_contains($file, '.docx'))
                                                                        <img style="height: 40px; width: 40px"
                                                                            src="{{ url('storage/app/uploads/word.png') }}"
                                                                            width="50">
                                                                    @elseif(str_contains($file, '.pdf'))
                                                                        <img style="height: 40px; width: 40px"
                                                                            src="{{ url('storage/app/uploads/pdf.png') }}"
                                                                            width="50">
                                                                    @elseif(str_contains($file, '.csv'))
                                                                        <img style="height: 40px; width: 40px"
                                                                            src="{{ url('storage/app/uploads/excel.png') }}"
                                                                            width="50">
                                                                    @else
                                                                        <img style="height: 50px"
                                                                            src="{{ url('storage/app/uploads/' . $file) }}"
                                                                            alt="">
                                                                    @endif
                                                                </div>
                                                                <div>
                                                                    <p class="m-0 p-0 FileNameHeading">
                                                                        {{ $file }}
                                                                    </p>
                                                                    <small class="m-0 p-0">7 KB</small>
                                                                </div>
                                                            </div>
                                                            <div>
                                                                <a href="{{ asset('storage/app/uploads/' . $file) }}"
                                                                    download>
                                                                    <img src="{{ asset('public/assets/icons/DownloadSimple.svg') }}"
                                                                        alt="">
                                                                </a>
                                                                <a href="javascript:void(0)"
                                                                    onclick="Delete_doc('{{ $allFiles['id'] }}', '{{ $file }}')">
                                                                    <img src="{{ asset('public/assets/icons/trash.svg') }}"
                                                                        alt="">
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                @endforeach
                                            @else
                                                <div>
                                                    <p class="m-0 p-0 FileNameHeading">
                                                        No files to show
                                                    </p>
                                                    <small class="m-0 p-0">7 KB</small>
                                                </div>
                                            @endif



                                        </div>
                                    </div>

                                    <div class="col-12 my-2">
                                        <hr class="">
                                    </div>
                                    <div class="col-12 groupChat-Section">
                                        <div class="d-flex justify-content-between align-items-center">
                                            <div>
                                                <h3 class="groupchat-Heading">Group Chat</h3>
                                                <span class="d-flex align-items-center gap-2 online-sub"><img
                                                        src="{{ url('public/assets/icons/online.svg') }}"
                                                        alt="">
                                                    {{ isset($count_online) ? $count_online : '' }}
                                                    Online</span>
                                            </div>
                                            <div class="w-50">
                                                <div class="d-flex justify-content-end">
                                                    @if (!empty($Task))
                                                        @foreach ($Task as $item)
                                                            @if (!empty($item))
                                                                @foreach ($item->members as $users)
                                                                    @if ($loop->iteration == 4)
                                                                    @break
                                                                @endif
                                                                <div>
                                                                    <div class="tale-small-image">
                                                                        @if (!empty($users->image))
                                                                            <img src="{{ url('storage/app/uploads/' . $users->image) }}"
                                                                                alt="">
                                                                        @else
                                                                            <img src="{{ url('storage/app/uploads/placeholder.jpg') }}"
                                                                                alt="">
                                                                        @endif
                                                                    </div>
                                                                </div>
                                                            @endforeach
                                                        @endif
                                                    @endforeach
                                                @endif


                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 my-2">
                                    <hr>
                                </div>
                                <div class="col-12 apndChats">

                                </div>
                                <div class="col-12 mt-3 d-flex align-items-center justify-content-between gap-3">
                                 
                                   
                                   <div class="w-100" >
                                   <input style="" id="sender_typed_msg" onkeyup="sendMessage(event)"
                                        type="text" class="form-control GlobalInputSetting w-100"
                                        placeholder="Type a message">
                                   </div>
                                        <div class="">
                                            <button class="btn-primary " onclick="sendMessage()"> Send  </button>
                                            </div>
                                        
                                    <input type="hidden" name="" id="recgroupId"
                                        value="{{ $Task[0]->id }}">
                                  
                                </div>
                            </div>

                        </div>
                    </div>
                    <div
                        class="order-xxl-2 order-xl-2 order-lg-2 order-md-1 order-sm-1 order-1 col-xxl-4 col-xl-4 col-lg-4 col-md-12 col-sm-12 col-12">
                        <div class="taskView-Right">
                            <div class="row">
                                <div class="col-12">
                                    <h4 class="taskView-Heading">Time Tracking</h4>
                                </div>
                                @php
                                    $start = strtotime($Task[0]->start_datetime);
                                    $strt_date = date('Y.j.n', $start);
                                    $strt_time = date('H:i:s', $start);
                                    $endtime = strtotime($Task[0]->end_datetime);
                                    $end_date = date('Y.j.n', $endtime);
                                    $end_time = date('H:i:s', $endtime);
                                @endphp
                                <div class="col-12 mt-3">
                                    <h3 class="text-center Clock-Time" id="timerDisplay">00:00:00</h3>
                                    <span class="clock-Expire text-center d-block">Expires on
                                        {{ $end_date }}</span>
                                </div>
                                </body>

                                </html>

                                <div class="col-12 mt-3">
                                    <div id="completeOption" class="Time-Card">
                                        <div class="d-flex justify-content-center">
                                            <div
                                                class="d-flex align-items-center gap-xxl-3 gap-xl-3 gap-lg-3 gap-md-3 gap-sm-1 gap-2">

                                                <p class="btn btn-primary text-white p-0 m-0 clock-card-text"
                                                    onclick="Task_complete('{{ $Task[0]->id }}')">Mark Complete
                                                </p>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 mt-3">
                                    <div class="p-3 CheckboxSection">

                                        {{-- @php
                                            $subTasks = json_decode($Task[0]->task_abbreviation);
                                        @endphp
                                        <div class="d-flex align-items-start mt-4 gap-5 flex-column">
                                            <h4>To do's</h4>
                                            <ul class="list-unstyled text-decoration-none d-flex flex-column gap-4 pe-4"
                                                id="check_all_tasks">
                                                @if (!empty($task_list))
                                                    @foreach ($task_list as $k => $item)
                                                        <li>
                                                            <div class="d-flex">
                                                                <div class="custom-Radio-Button">
                                                                    <label class="custom-radio m-0"
                                                                        for="modalcheck{{ $k }}">
                                                                        <input type="checkbox"
                                                                            {{ array_search($item->id, array_column($task_status, 'tasklist_id')) !== false ? 'checked' : '' }}
                                                                            class="customme checkboxes"
                                                                            onclick="markTaskComplete(this,{{ $item->id }})"
                                                                            value="{{ $item->id }}"
                                                                            name="customRadio"
                                                                            id="modalcheck{{ $k }}">
                                                                        <span class="radio-btn"></span>

                                                                    </label>
                                                                </div>
                                                                <span
                                                                    class="textbox-option">{{ $item->task_abbreviation }}</span>
                                                            </div>
                                                        </li>
                                                    @endforeach
                                                @else
                                                    {{ 'no tasks to show' }}
                                                @endif

                                        </div> --}}
                                        <h4>To do's</h4>

                                        @php
                                            $subTasks = json_decode($Task[0]->task_abbreviation);
                                            $count = 0;
                                        @endphp
                                        <div class="d-flex align-items-start mt-4 gap-5 flex-row">
                                            @if (!empty($task_list))
                                                @foreach ($task_list as $k => $item)
                                                    @if ($count % 9 == 0)
                                                        @if ($count != 0)
                                                            </ul>
                                                        @endif
                                                        <ul class="list-unstyled text-decoration-none d-flex flex-column gap-4 pe-4"
                                                            id="check_all_tasks">
                                                    @endif
                                                    <li>
                                                        <div class="d-flex">
                                                            <div class="custom-Radio-Button">
                                                                <label class="custom-radio m-0"
                                                                    for="modalcheck{{ $k }}">
                                                                    <input type="checkbox"
                                                                        {{ array_search($item->id, array_column($task_status, 'tasklist_id')) !== false ? 'checked' : '' }}
                                                                        class="customme checkboxes"
                                                                        onclick="markTaskComplete(this,{{ $item->id }})"
                                                                        value="{{ $item->id }}"
                                                                        name="customRadio"
                                                                        id="modalcheck{{ $k }}">
                                                                    <span class="radio-btn"></span>
                                                                </label>
                                                            </div>
                                                            <span
                                                                class="textbox-option">{{ $item->task_abbreviation }}</span>
                                                        </div>
                                                    </li>
                                                    @php $count++; @endphp
                                                @endforeach
                                                </ul>
                                            @else
                                                <p>no tasks to show</p>
                                            @endif
                                        </div>
                                    </div>
                                    <div class="col-12 mt-3">
                                        <form action="">
                                            <h1 class="Comment-Heading">Comments</h1>
                                            {{-- <textarea name="" class="form-control mt-3 bg-transparent w-100"></textarea> --}}
                                            {{ isset($Task[0]->comments) ? $Task[0]->comments : '' }}

                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



<!-- Button trigger modal -->


<!-- Modal -->
<div class="modal fade" id="extend" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header extendModal">
                <h1 class="modal-title fs-5" id="exampleModalLabel">Extend Date</h1>
                <button style="border:none !important;" type="button" class="btn-secondary "
                    data-bs-dismiss="modal" aria-label="Close"> <i class="fa-regular fa-x"></i> </button>
            </div>
            <div class="modal-body">
                <div class="row">
                    <div class="col-12 mt-3">
                        <div>
                            <label for="end-Date" class="d-block">
                                Start Date
                            </label>
                            <input type="date" id="end-Date"
                                class="datepicker form-control bg-transparent w-100">
                        </div>
                    </div>
                    <div class="col-12 mt-3">
                        <div>
                            <label for="end-Date" class="d-block">
                                End Date
                            </label>
                            <input type="date" id="end-Date"
                                class="datepicker form-control bg-transparent w-100">
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <!--                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>-->
                <button type="button" class="btn btn-secondary">Save</button>
            </div>
        </div>
    </div>
</div>
<!--MODAL EDN-->
<!--DOCUMENT MODAL-->
<div class="modal fade" id="document" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header extendModal">
                <h1 class="modal-title fs-5" id="exampleModalLabel">Documents</h1>
                <button style="border:none !important;" type="button" class="btn-secondary "
                    data-bs-dismiss="modal" aria-label="Close"> <i class="fa-regular fa-x"></i> </button>
            </div>
            <div class="modal-body DocumentModal">
                <div class="row">
                    <div class="col-12 mt-3">
                        <div class="input-images-1m" style="padding-top: .5rem;"></div>
                    </div>
                    <div class="col-12 mt-3">

                        <div
                            class="DownloadIconSetting d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column align-items-xxl-center align-items-xl-center align-items-lg-center align-items-md-center align-items-sm-start align-items-start justify-content-between">
                            <div
                                class="d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column  gap-3">
                                <div>
                                    <img src="../assets/icons/Avatar%20Icon.svg" alt="">
                                </div>
                                <div>
                                    <p class="m-0 p-0 FileNameHeading">
                                        insurance agreement.pdf
                                    </p>
                                    <small class="m-0 p-0">7 KB</small>
                                </div>
                            </div>
                            <div>
                                <a href="#"> <img src="../assets/icons/DownloadSimple.svg"
                                        alt=""></a>
                                <a href="#"><img src="../assets/icons/trash.svg" alt=""></a>
                            </div>
                        </div>

                    </div>
                    <div class="col-12 mt-3">

                        <div
                            class="DownloadIconSetting d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column align-items-xxl-center align-items-xl-center align-items-lg-center align-items-md-center align-items-sm-start align-items-start justify-content-between">
                            <div
                                class="d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column  gap-3">
                                <div>
                                    <img src="../assets/icons/Avatar%20Icon.svg" alt="">
                                </div>
                                <div>
                                    <p class="m-0 p-0 FileNameHeading">
                                        insurance agreement.pdf
                                    </p>
                                    <small class="m-0 p-0">7 KB</small>
                                </div>
                            </div>
                            <div>
                                <a href="#"> <img src="../assets/icons/DownloadSimple.svg"
                                        alt=""></a>
                                <a href="#"><img src="../assets/icons/trash.svg" alt=""></a>
                            </div>
                        </div>

                    </div>
                    <div class="col-12 mt-3">

                        <div
                            class="DownloadIconSetting d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column align-items-xxl-center align-items-xl-center align-items-lg-center align-items-md-center align-items-sm-start align-items-start justify-content-between">
                            <div
                                class="d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column  gap-3">
                                <div>
                                    <img src="../assets/icons/Avatar%20Icon.svg" alt="">
                                </div>
                                <div>
                                    <p class="m-0 p-0 FileNameHeading">
                                        insurance agreement.pdf
                                    </p>
                                    <small class="m-0 p-0">7 KB</small>
                                </div>
                            </div>
                            <div>
                                <a href="#"> <img src="../assets/icons/DownloadSimple.svg"
                                        alt=""></a>
                                <a href="#"><img src="../assets/icons/trash.svg" alt=""></a>
                            </div>
                        </div>

                    </div>
                    <div class="col-12 mt-3">

                        <div
                            class="DownloadIconSetting d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column align-items-xxl-center align-items-xl-center align-items-lg-center align-items-md-center align-items-sm-start align-items-start justify-content-between">
                            <div
                                class="d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column  gap-3">
                                <div>
                                    <img src="../assets/icons/Avatar%20Icon.svg" alt="">
                                </div>
                                <div>
                                    <p class="m-0 p-0 FileNameHeading">
                                        insurance agreement.pdf
                                    </p>
                                    <small class="m-0 p-0">7 KB</small>
                                </div>
                            </div>
                            <div>
                                <a href="#"> <img src="../assets/icons/DownloadSimple.svg"
                                        alt=""></a>
                                <a href="#"><img src="../assets/icons/trash.svg" alt=""></a>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <!--                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>-->
                <button type="button" class="btn btn-secondary">Save</button>
            </div>
        </div>
    </div>
</div>

{{-- Delete Confirmation Modal Start --}}
<div class="modal fade" id="DeleteModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <form action="{{ route('groupmanager.delete_task_doc') }}" method="POST">
            @csrf
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Delete Confirmation</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"
                        aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p>Are you sure want to delete?</p>
                    <input type="hidden" id="doc_id" name="doc_id">
                    <input type="hidden" id="doc_name" name="doc_name">
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Yes</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
                </div>
            </div>
        </form>
    </div>
</div>
{{-- Delete Confirmation Modal End --}}


@php
    $startDateTime = strtotime($Task[0]->start_datetime);
    $currentDateTime = strtotime(date('Y-m-d'));
    
@endphp

{{-- task timer --}}

<script>
    let all_task_completed = true;
    $("#check_all_tasks input[type='checkbox']").each(function(i, v) {
        if ($(v).is(":checked") === false) {
            all_task_completed = false
        }
        (all_task_completed === true) ? $("#completeOption").css('display', 'block'): $("#completeOption").css(
            'display', 'none')
    })

    function markTaskComplete(event, task_list_id) {
        let _token = '{{ csrf_token() }}';
        let task_id = '{{ $Task[0]->id }}'
        let status = ($(event).is(":checked") === true) ? "completed" : "pending";
        $.post('{{ route('groupmanager.mark_as_complete') }}', {
            _token,
            task_list_id,
            status,
            task_id
        }, function(resp) {
            // location.reload()
            console.log(resp)
        })

    }

</script>

<script>
    document.addEventListener("DOMContentLoaded", function() {
    let startTime = new Date("{{ $Task[0]->start_datetime }}").getTime();
    let currentTime = new Date().getTime();
    console.log(startTime, currentTime)

    if (('{{ $Task[0]->status }}' == 'Approved' || '{{ $Task[0]->status }}' == 'Active') && currentTime >= startTime) {
        startTimer(new Date("{{ $Task[0]->end_datetime }}").getTime());
        
        $.ajax({
            url: "{{ route('groupmanager.task_active') }}",
            type: "post",
            data: {
                status: "Active",
                id: "{{ $Task[0]->id }}",
                _token: "{{ csrf_token() }}"
            },
            success: function(res) {
                console.log(res);
            }
        });
    }
    if (('{{ $Task[0]->status }}' == 'Expired') && currentTime >= startTime) {
        startTimer(new Date("{{ $Task[0]->end_datetime }}").getTime());
        
        $.ajax({
            url: "{{ route('groupmanager.task_active') }}",
            type: "post",
            data: {
                status: "Active",
                id: "{{ $Task[0]->id }}",
                _token: "{{ csrf_token() }}"
            },
            success: function(res) {
                console.log(res);
            }
        });
    }

    function startTimer(expiryTime) {
        let timerInterval = setInterval(function() {
            let now = Date.now();
            let distance = expiryTime - now;

            if (distance <= 0) {
                clearInterval(timerInterval);
                document.getElementById('timerDisplay').innerHTML = "Expired";
                $.ajax({
                    url: "{{ route('groupmanager.task_expired') }}",
                    type: "post",
                    data: {
                        status: "Expired",
                        id: "{{ $Task[0]->id }}",
                        _token: "{{ csrf_token() }}"
                    },
                    success: function(res) {
                        console.log(res);
                    }
                });
                return;
            }

            let days = Math.floor(distance / (1000 * 60 * 60 * 24));
            let hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
            let minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
            let seconds = Math.floor((distance % (1000 * 60)) / 1000);

            document.getElementById('timerDisplay').innerHTML =
                (days > 0 ? days + "d " : "") +
                (hours < 10 ? "0" + hours : hours) + ":" +
                (minutes < 10 ? "0" + minutes : minutes) + ":" +
                (seconds < 10 ? "0" + seconds : seconds);

        }, 1000);
    }
});

</script>

<script>
    function Delete_doc(id, files) {
        console.log(id)
        console.log(files)
        $('#doc_id').val(id)
        $('#doc_name').val(files)
        $('#DeleteModal').modal('show');
    }
</script>


{{-- task complete --}}


<script>
    // document.addEventListener("DOMContentLoaded", function() {
    //     const checkboxes = document.querySelectorAll('.customme');
    //     const selectAllCheckbox = document.getElementById('modalcheck');
    //     const completeOption = document.getElementById('completeOption');

    //     checkboxes.forEach(function(checkbox) {
    //         checkbox.addEventListener('change', function() {
    //             const allChecked = Array.from(checkboxes).every(function(checkbox) {
    //                 return checkbox.checked;
    //             });

    //             if (allChecked) {
    //                 completeOption.classList.add('highlight');
    //             } else {
    //                 completeOption.classList.remove('highlight');
    //             }
    //         });
    //     });

    // Event listener for "Select All" checkbox
    //     selectAllCheckbox.addEventListener('change', function() {
    //         if (this.checked) {
    //             checkboxes.forEach(function(checkbox) {
    //                 checkbox.checked = true;
    //             });
    //             completeOption.classList.add('highlight');
    //         } else {
    //             checkboxes.forEach(function(checkbox) {
    //                 checkbox.checked = false;
    //             });
    //             completeOption.classList.remove('highlight');
    //         }
    //     });
    // });


    function Task_complete(id) {
        console.log(id)
        $.ajax({
            url: "{{ route('groupmanager.task_complete') }}",
            type: "POST",
            data: {
                task_id: id,
                status: 'Completed',
                _token: "{{ csrf_token() }}"
            },
            success: function(res) {
                console.log(res);
                location.reload()
                toastr.success(res.success);
            }
        })
    }
</script>


{{-- group chat --}}

{{-- chat script --}}
<script>
    let group_id = $('#recgroupId').val();
    setInterval(() => {
        Show_chat(group_id)
    }, 500);

    function Show_chat(group_id) {
        $('#reciever_typed_id').val(group_id);
        $.ajax({
            url: "{{ route('groupmanager.show_group_chat') }}",
            type: "POST",
            data: {
                group_id: group_id,
                _token: "{{ csrf_token() }}"
            },
            success: function(res) {
                console.log(res);
                $('.apndChats').html(res.view);

            }
        });
    }

    function sendMessage(event) {
    if (event && event.keyCode !== 13) {
        return; 
    }
            if ($('#sender_typed_msg').val() !== '') {
                console.log($('#sender_typed_msg').val())
                let sender_msg = $('#sender_typed_msg').val();
                let reciever_typed_id = $('#recgroupId').val();

                $.ajax({
                    url: "{{ route('groupmanager.send_grp_Msg') }}",
                    type: "POST",
                    data: {
                        sender_msg: sender_msg,
                        reciever_id: reciever_typed_id,
                        _token: "{{ csrf_token() }}"
                    },
                    success: function(res) {
                        console.log(res);
                        // Refresh chat section
                        Show_chat(group_id);
                        // Clear input field
                        $('#sender_typed_msg').val('');
                    }
                });
            } else {
                return false;
            }
        }

</script>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        const selectAllCheckbox = document.getElementById('modalcheck');

        const otherCheckboxes = document.querySelectorAll('.customme');

        selectAllCheckbox.addEventListener('change', function() {
            otherCheckboxes.forEach(function(checkbox) {
                checkbox.checked = selectAllCheckbox.checked;
            });
        });
    });
</script>

<!--DOCUMENT MODALEND-->
@include('group_manager.footer')
