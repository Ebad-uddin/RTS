<?php
$activebar = "index";
?>

@include('group_manager.header')

    <div class="iq-top-navbar py-2 rtl-iq-top-navbar ">
        <div class="iq-navbar-custom">
            <nav class="navbar navbar-expand-lg navbar-light p-0 toSetNavBarAll w-100">
                <div class="iq-navbar-logo d-flex align-items-center justify-content-between">
                    <i class="ri-menu-line wrapper-menu"></i>
                    <!-- Mobile Logo -->
                </div>
                <div class="iq-search-bar device-search">
                    <h4 class="main_content_title ps-3">Dashboard</h4>
                </div>
                @include('group_manager.tooltip')

                <div class="d-xxl-none d-xl-none d-lg-none d-md-block d-sm-block d-block">
                    <ul class="align-items-center d-flex gap-4 list-unstyled text-decoration-none m-0">
                        <li>
                            <button class="btn" type="button" data-bs-toggle="modal"
                                    data-bs-target="#exampleModal">Create Task
                            </button>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
    </div>


    <div class="content-page rtl-page">
        <div class="container-fluid mt-4">
            <div class="row">
                <div class="col-12">
                    <div class="row">
                        <div class="col-12 indexpageSetting">
                            <nav>
                                <div class="nav nav-tabs" id="nav-tab" role="tablist">
                                    <div class="row w-100">
                                        <div class="col-xl col-xxl col-lg-12 col-md-12 col-sm-12 mt-3">
                                            <button class="nav-link active w-100" id="nav-home-tab" data-bs-toggle="tab"
                                                    data-bs-target="#nav-home" type="button" role="tab"
                                                    aria-controls="nav-home" aria-selected="true">
                                                <div class="Dashboard-Card">
                                                    <div class="d-flex align-items-center justify-content-between">
                                                        <div>
                                                            <div>
                                                                <p class="p-0 m-0 card-Status">All Tasks</p>
                                                            </div>
                                                            <div>
                                                                <h1 class="p-0 m-0 Card-Number">456</h1>
                                                            </div>
                                                        </div>
                                                        <div
                                                            class="Dashboard-Card-Icon d-flex align-items-center justify-content-center"
                                                        >
                                                            <svg
                                                                width="24"
                                                                height="24"
                                                                viewBox="0 0 24 24"
                                                                fill="none"
                                                                xmlns="http://www.w3.org/2000/svg"
                                                            >
                                                                <path
                                                                    d="M16.3135 8.0625L20.25 12L16.3135 15.9375M9.75 12H20.2472M9.75 20.25H4.5C4.30109 20.25 4.11032 20.171 3.96967 20.0303C3.82902 19.8897 3.75 19.6989 3.75 19.5V4.5C3.75 4.30109 3.82902 4.11032 3.96967 3.96967C4.11032 3.82902 4.30109 3.75 4.5 3.75H9.75"

                                                                    stroke-width="1.5"
                                                                    stroke-linecap="round"
                                                                    stroke-linejoin="round"
                                                                />
                                                            </svg>
                                                        </div>
                                                    </div>
                                                    <div class="mt-2">
                                                        <p class="card-Pargraph p-0 m-0 text-start">
        <span class="PercentageSetting"
        ><svg
                width="14"
                height="8"
                class="dashboardper"
                viewBox="0 0 14 8"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
            >
            <path
                d="M9.86654 0L11.3932 1.52667L8.13987 4.78L5.4732 2.11333L0.533203 7.06L1.4732 8L5.4732 4L8.13987 6.66667L12.3399 2.47333L13.8665 4V0H9.86654Z"
            />
          </svg>
          8.5%</span
        >
                                                            Up from yesterday
                                                        </p>
                                                    </div>
                                                </div>
                                            </button>

                                        </div>
                                        <div class="col-xl col-xxl col-lg-12 col-md-12 col-sm-12 mt-3">
                                            <button class="nav-link w-100" id="nav-profile-tab" data-bs-toggle="tab"
                                                    data-bs-target="#nav-profile" type="button" role="tab"
                                                    aria-controls="nav-profile" aria-selected="false">
                                                <div class="Dashboard-Card">
                                                    <div class="d-flex align-items-center justify-content-between">
                                                        <div>
                                                            <div>
                                                                <p class="p-0 m-0 card-Status text-start">Task
                                                                    Submitted</p>
                                                            </div>
                                                            <div>
                                                                <h1 class="p-0 m-0 Card-Number text-start">456</h1>
                                                            </div>
                                                        </div>
                                                        <div
                                                            class="Dashboard-Card-Icon d-flex align-items-center justify-content-center"
                                                        >
                                                            <svg
                                                                width="24"
                                                                height="24"
                                                                viewBox="0 0 24 24"
                                                                fill="none"
                                                                xmlns="http://www.w3.org/2000/svg"
                                                            >
                                                                <path
                                                                    d="M16.3135 8.0625L20.25 12L16.3135 15.9375M9.75 12H20.2472M9.75 20.25H4.5C4.30109 20.25 4.11032 20.171 3.96967 20.0303C3.82902 19.8897 3.75 19.6989 3.75 19.5V4.5C3.75 4.30109 3.82902 4.11032 3.96967 3.96967C4.11032 3.82902 4.30109 3.75 4.5 3.75H9.75"

                                                                    stroke-width="1.5"
                                                                    stroke-linecap="round"
                                                                    stroke-linejoin="round"
                                                                />
                                                            </svg>
                                                        </div>
                                                    </div>
                                                    <div class="mt-2">
                                                        <p class="card-Pargraph p-0 m-0 text-start">
        <span class="PercentageSetting"
        ><svg
                width="14"
                height="8"
                class="dashboardper"
                viewBox="0 0 14 8"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
            >
            <path
                d="M9.86654 0L11.3932 1.52667L8.13987 4.78L5.4732 2.11333L0.533203 7.06L1.4732 8L5.4732 4L8.13987 6.66667L12.3399 2.47333L13.8665 4V0H9.86654Z"
            />
          </svg>
          8.5%</span
        >
                                                            Up from yesterday
                                                        </p>
                                                    </div>
                                                </div>
                                            </button>
                                        </div>
                                        <div class="col-xl col-xxl col-lg-12 col-md-12 col-sm-12 mt-3">
                                            <button class="nav-link w-100" id="nav-contact-tab" data-bs-toggle="tab"
                                                    data-bs-target="#nav-contact" type="button" role="tab"
                                                    aria-controls="nav-contact" aria-selected="false">
                                                <div class="Dashboard-Card">
                                                    <div class="d-flex align-items-center justify-content-between">
                                                        <div>
                                                            <div>
                                                                <p class="p-0 m-0 card-Status text-start">Tasks
                                                                    Approved</p>
                                                            </div>
                                                            <div>
                                                                <h1 class="p-0 m-0 Card-Number text-start">456</h1>
                                                            </div>
                                                        </div>
                                                        <div
                                                            class="Dashboard-Card-Icon d-flex align-items-center justify-content-center"
                                                        >
                                                            <svg
                                                                width="24"
                                                                height="24"
                                                                viewBox="0 0 24 24"
                                                                fill="none"
                                                                xmlns="http://www.w3.org/2000/svg"
                                                            >
                                                                <path
                                                                    d="M16.3135 8.0625L20.25 12L16.3135 15.9375M9.75 12H20.2472M9.75 20.25H4.5C4.30109 20.25 4.11032 20.171 3.96967 20.0303C3.82902 19.8897 3.75 19.6989 3.75 19.5V4.5C3.75 4.30109 3.82902 4.11032 3.96967 3.96967C4.11032 3.82902 4.30109 3.75 4.5 3.75H9.75"

                                                                    stroke-width="1.5"
                                                                    stroke-linecap="round"
                                                                    stroke-linejoin="round"
                                                                />
                                                            </svg>
                                                        </div>
                                                    </div>
                                                    <div class="mt-2">
                                                        <p class="card-Pargraph p-0 m-0 text-start">
        <span class="PercentageSetting"
        ><svg
                width="14"
                height="8"
                class="dashboardper"
                viewBox="0 0 14 8"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
            >
            <path
                d="M9.86654 0L11.3932 1.52667L8.13987 4.78L5.4732 2.11333L0.533203 7.06L1.4732 8L5.4732 4L8.13987 6.66667L12.3399 2.47333L13.8665 4V0H9.86654Z"
            />
          </svg>
          8.5%</span
        >
                                                            Up from yesterday
                                                        </p>
                                                    </div>
                                                </div>
                                            </button>

                                        </div>
                                        <div class="col-xl col-xxl col-lg-12 col-md-12 col-sm-12 mt-3">
                                            <button class="nav-link w-100" id="nav-contact2-tab" data-bs-toggle="tab"
                                                    data-bs-target="#nav-contact2" type="button" role="tab"
                                                    aria-controls="nav-contact" aria-selected="false">
                                                <div class="Dashboard-Card">
                                                    <div class="d-flex align-items-center justify-content-between">
                                                        <div>
                                                            <div>
                                                                <p class="p-0 m-0 card-Status text-start">Tasks
                                                                    Active</p>
                                                            </div>
                                                            <div>
                                                                <h1 class="p-0 m-0 Card-Number text-start">456</h1>
                                                            </div>
                                                        </div>
                                                        <div
                                                            class="Dashboard-Card-Icon d-flex align-items-center justify-content-center"
                                                        >
                                                            <svg
                                                                width="24"
                                                                height="24"
                                                                viewBox="0 0 24 24"
                                                                fill="none"
                                                                xmlns="http://www.w3.org/2000/svg"
                                                            >
                                                                <path
                                                                    d="M16.3135 8.0625L20.25 12L16.3135 15.9375M9.75 12H20.2472M9.75 20.25H4.5C4.30109 20.25 4.11032 20.171 3.96967 20.0303C3.82902 19.8897 3.75 19.6989 3.75 19.5V4.5C3.75 4.30109 3.82902 4.11032 3.96967 3.96967C4.11032 3.82902 4.30109 3.75 4.5 3.75H9.75"
                                                                    stroke-width="1.5"
                                                                    stroke-linecap="round"
                                                                    stroke-linejoin="round"
                                                                />
                                                            </svg>
                                                        </div>
                                                    </div>
                                                    <div class="mt-2">
                                                        <p class="card-Pargraph p-0 m-0 text-start">
        <span class="PercentageSetting"
        ><svg
                width="14"
                height="8"
                class="dashboardper"
                viewBox="0 0 14 8"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
            >
            <path
                d="M9.86654 0L11.3932 1.52667L8.13987 4.78L5.4732 2.11333L0.533203 7.06L1.4732 8L5.4732 4L8.13987 6.66667L12.3399 2.47333L13.8665 4V0H9.86654Z"
            />
          </svg>
          8.5%</span
        >
                                                            Up from yesterday
                                                        </p>
                                                    </div>
                                                </div>
                                            </button>

                                        </div>
                                        <div class="col-xl col-xxl col-lg-12 col-md-12 col-sm-12 mt-3">
                                            <button class="nav-link w-100" id="nav-contact3-tab" data-bs-toggle="tab"
                                                    data-bs-target="#nav-contact3" type="button" role="tab"
                                                    aria-controls="nav-contact" aria-selected="false">
                                                <div class="Dashboard-Card">
                                                    <div class="d-flex align-items-center justify-content-between">
                                                        <div>
                                                            <div>
                                                                <p class="p-0 m-0 card-Status text-start">Tasks
                                                                    Expired</p>
                                                            </div>
                                                            <div>
                                                                <h1 class="p-0 m-0 Card-Number text-start">456</h1>
                                                            </div>
                                                        </div>
                                                        <div
                                                            class="Dashboard-Card-Icon d-flex align-items-center justify-content-center"
                                                        >
                                                            <svg
                                                                width="24"
                                                                height="24"
                                                                viewBox="0 0 24 24"
                                                                fill="none"
                                                                xmlns="http://www.w3.org/2000/svg"
                                                            >
                                                                <path
                                                                    d="M16.3135 8.0625L20.25 12L16.3135 15.9375M9.75 12H20.2472M9.75 20.25H4.5C4.30109 20.25 4.11032 20.171 3.96967 20.0303C3.82902 19.8897 3.75 19.6989 3.75 19.5V4.5C3.75 4.30109 3.82902 4.11032 3.96967 3.96967C4.11032 3.82902 4.30109 3.75 4.5 3.75H9.75"
                                                                    stroke-width="1.5"
                                                                    stroke-linecap="round"
                                                                    stroke-linejoin="round"
                                                                />
                                                            </svg>
                                                        </div>
                                                    </div>
                                                    <div class="mt-2">
                                                        <p class="card-Pargraph p-0 m-0 text-start">
        <span class="PercentageSetting"
        ><svg
                width="14"
                height="8"
                class="dashboardper"
                viewBox="0 0 14 8"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
            >
            <path
                d="M9.86654 0L11.3932 1.52667L8.13987 4.78L5.4732 2.11333L0.533203 7.06L1.4732 8L5.4732 4L8.13987 6.66667L12.3399 2.47333L13.8665 4V0H9.86654Z"
            />
          </svg>
          8.5%</span
        >
                                                            Up from yesterday
                                                        </p>
                                                    </div>
                                                </div>
                                            </button>

                                        </div>
                                    </div>
                                </div>
                            </nav>
                        </div>
                    </div>
                    <div class="row mt-4">
                        <div class="col-12 ">
                            <div class="bg-white p-3 index-TablePage">

                                <div class="tab-content" id="nav-tabContent">
                                    <div class="tab-pane fade show active" id="nav-home" role="tabpanel"
                                         aria-labelledby="nav-home-tab">
                                        <div class="mb-3">
                                            <div class="align-items-center d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column justify-content-between toSetFilterIcon">
                                                <h4 class="file-Heading">
                                                    All Tasks
                                                </h4>
                                                <div class="mt-xxl-0 mt-xl-0 mt-lg-0 mt-md-0 mt-sm-3 mt-3 d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column gap-2">
                                                    <button class="FilterButtonSetting btn btn-secondary d-flex gap-2 align-items-center">
                                                        Sort by
                                                        <svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                                                             xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M3.375 13.4995H7.3125M10.125 11.812L12.9375 14.6245M12.9375 14.6245L15.7499 11.8125M12.9375 14.6245L12.9375 7.87451M3.375 8.99951H8.43743M3.375 4.49951H12.9374"
                                                                  stroke-width="1.5" stroke-linecap="round"
                                                                  stroke-linejoin="round"/>
                                                        </svg>
                                                    </button>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="table-responsive">
                                            <table id="" class="dataTable table-responsive stripe w-100 ">
                                                <thead>
                                                <tr>
                                                    <th>
                                                        <div class="custom-Radio-Button">
                                                            <label class="custom-radio m-0" for="ex_bth">
                                                                <input type="checkbox" class="customme"
                                                                       name="customRadio" id="ex_bth">
                                                                <span class="radio-btn"></span>

                                                            </label>
                                                        </div>
                                                    </th>
                                                    <th>Date Created</th>
                                                    <th class="text-start">Task Id</th>
                                                    <th>Task Tittle</th>
                                                    <th>Assigned To</th>
                                                    <th>Start on</th>
                                                    <th>End on</th>
                                                    <th>Status</th>
                                                    <th></th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <tr>
                                                    <td>
                                                        <div class="custom-Radio-Button">
                                                            <label class="custom-radio m-0" for="tablec1">
                                                                <input type="checkbox" class="customme"
                                                                       name="customRadio" id="tablec1">
                                                                <span class="radio-btn"></span>

                                                            </label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            03:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            5045
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Check-up Assignment
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            <span class="badge badge-inactive">Greg</span>
                                                            <span class="badge badge-inactive">Gladys</span>
                                                            
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <select name="" class="js-select2" onchange="checkTertiary(event)">
                                                            <option value="Select Option" selected disabled>Select Option</option>
                                                            <option value="Approved">Approved</option>
                                                            <option value="Submitted">Submitted</option>
                                                            <option value="Active">Active</option>
                                                            <option value="Expired">Expired</option>
                                                        </select>
                                                    </td>
                                                    <td>
                                                        <div class="tableButtonSetting">
                                                            <div class="btn-group dropstart">
                                                                <a href="#" class="dropdown-toggle" type="button"
                                                                   data-bs-toggle="dropdown" aria-expanded="false">
                                                                    <img src="assets/icons/DotsThreeOutline.svg" alt="">
                                                                </a>
                                                                <ul class="dropdown-menu tosetWidh-Dropdown">
                                                                    <li><a class="dropdown-item  togivepaddingLeft" href="taskView.php">View</a></li>
                                                                    <li><a class="dropdown-item  togivepaddingLeft"  data-bs-toggle="modal" data-bs-target="#DeleteModal" type="button" href="#">Delete</a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <div class="custom-Radio-Button">
                                                            <label class="custom-radio m-0" for="tablec2">
                                                                <input type="checkbox" class="customme"
                                                                       name="customRadio" id="tablec2">
                                                                <span class="radio-btn"></span>

                                                            </label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            6065
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Check-up Assignment
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            <span class="badge badge-inactive">Angel</span>
                                                            <span class="badge badge-inactive">Aubrey</span>
                                                            
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <select name="" class="js-select2" onchange="checkTertiary(event)">
                                                            <option value="Select Option" selected disabled>Select Option</option>
                                                            <option value="Approved">Approved</option>
                                                            <option value="Submitted">Submitted</option>
                                                            <option value="Active">Active</option>
                                                            <option value="Expired">Expired</option>
                                                        </select>
                                                    </td>
                                                    <td>
                                                        <div class="tableButtonSetting">
                                                            <div class="btn-group dropstart">
                                                                <a href="#" class="dropdown-toggle" type="button"
                                                                   data-bs-toggle="dropdown" aria-expanded="false">
                                                                    <img src="assets/icons/DotsThreeOutline.svg" alt="">
                                                                </a>
                                                                <ul class="dropdown-menu tosetWidh-Dropdown">
                                                                    <li><a class="dropdown-item  togivepaddingLeft" href="taskView.php">View</a></li>
                                                                    <li><a class="dropdown-item  togivepaddingLeft" href="#"  data-bs-toggle="modal" data-bs-target="#DeleteModal" type="button">Delete</a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <div class="custom-Radio-Button">
                                                            <label class="custom-radio m-0" for="tablec3">
                                                                <input type="checkbox" class="customme"
                                                                       name="customRadio" id="tablec3">
                                                                <span class="radio-btn"></span>

                                                            </label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            6690
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Check-up Assignment
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            <span class="badge badge-inactive">Arlene</span>
                                                            <span class="badge badge-inactive">Darrell</span>
                                                            
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <select name="" class="js-select2" onchange="checkTertiary(event)">
                                                            <option value="Select Option" selected disabled>Select Option</option>
                                                            <option value="Approved">Approved</option>
                                                            <option value="Submitted">Submitted</option>
                                                            <option value="Active">Active</option>
                                                            <option value="Expired">Expired</option>
                                                        </select>
                                                    </td>
                                                    <td>
                                                        <div class="tableButtonSetting">
                                                            <div class="btn-group dropstart">
                                                                <a href="#" class="dropdown-toggle" type="button"
                                                                   data-bs-toggle="dropdown" aria-expanded="false">
                                                                    <img src="assets/icons/DotsThreeOutline.svg" alt="">
                                                                </a>
                                                                <ul class="dropdown-menu tosetWidh-Dropdown">
                                                                    <li><a class="dropdown-item  togivepaddingLeft" href="taskView.php">View</a></li>
                                                                    <li><a class="dropdown-item  togivepaddingLeft" href="#" data-bs-toggle="modal" data-bs-target="#DeleteModal" type="button">Delete</a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <div class="custom-Radio-Button">
                                                            <label class="custom-radio m-0" for="tablec4">
                                                                <input type="checkbox" class="customme"
                                                                       name="customRadio" id="tablec4">
                                                                <span class="radio-btn"></span>

                                                            </label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            5560
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Check-up Assignment
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            <span class="badge badge-inactive">Philip</span>
                                                            <span class="badge badge-inactive">Esther</span>
                                                            
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <select name="" class="js-select2" onchange="checkTertiary(event)">
                                                            <option value="Select Option" selected disabled>Select Option</option>
                                                            <option value="Approved">Approved</option>
                                                            <option value="Submitted">Submitted</option>
                                                            <option value="Active">Active</option>
                                                            <option value="Expired">Expired</option>
                                                        </select>
                                                    </td>
                                                    <td>
                                                        <div class="tableButtonSetting">
                                                            <div class="btn-group dropstart">
                                                                <a href="#" class="dropdown-toggle" type="button"
                                                                   data-bs-toggle="dropdown" aria-expanded="false">
                                                                    <img src="assets/icons/DotsThreeOutline.svg" alt="">
                                                                </a>
                                                                <ul class="dropdown-menu tosetWidh-Dropdown">
                                                                    <li><a class="dropdown-item  togivepaddingLeft" href="taskView.php">View</a></li>
                                                                    <li><a class="dropdown-item  togivepaddingLeft" href="#" data-bs-toggle="modal" data-bs-target="#DeleteModal" type="buton">Delete</a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                                </tbody>

                                            </table>

                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="nav-profile" role="tabpanel"
                                         aria-labelledby="nav-profile-tab">
                                        <div class="mb-3">
                                            <div class="align-items-center d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column justify-content-between toSetFilterIcon">
                                                <h4 class="file-Heading">
                                                    Task Submitted
                                                </h4>
                                                <div class="mt-xxl-0 mt-xl-0 mt-lg-0 mt-md-0 mt-sm-3 mt-3 d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column gap-2">
                                                    <button class="FilterButtonSetting btn btn-secondary d-flex gap-2 align-items-center">
                                                        Sort by
                                                        <svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                                                             xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M3.375 13.4995H7.3125M10.125 11.812L12.9375 14.6245M12.9375 14.6245L15.7499 11.8125M12.9375 14.6245L12.9375 7.87451M3.375 8.99951H8.43743M3.375 4.49951H12.9374"
                                                                  stroke-width="1.5" stroke-linecap="round"
                                                                  stroke-linejoin="round"/>
                                                        </svg>
                                                    </button>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="table-responsive">
                                            <table id="" class="dataTable table-responsive stripe w-100 ">
                                                <thead>
                                                <tr>
                                                    <th>
                                                        <div class="custom-Radio-Button">
                                                            <label class="custom-radio m-0" for="ex_bth">
                                                                <input type="checkbox" class="customme"
                                                                       name="customRadio" id="ex_bth">
                                                                <span class="radio-btn"></span>

                                                            </label>
                                                        </div>
                                                    </th>
                                                    <th>Date Created</th>
                                                    <th class="text-start">Task Id</th>
                                                    <th>Task Tittle</th>
                                                    <th>Assigned To</th>
                                                    <th>Start on</th>
                                                    <th>End on</th>
                                                    <th>Status</th>
                                                    <th></th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <tr>
                                                    <td>
                                                        <div class="custom-Radio-Button">
                                                            <label class="custom-radio m-0" for="tablec1">
                                                                <input type="checkbox" class="customme"
                                                                       name="customRadio" id="tablec1">
                                                                <span class="radio-btn"></span>

                                                            </label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            03:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            5045
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Check-up Assignment
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            <span class="badge badge-inactive">Greg</span>
                                                            <span class="badge badge-inactive">Gladys</span>
                                                            
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <select name="" class="js-select2">
                                                            <option value="Approved">Approved</option>
                                                            <option value="">Submitted</option>
                                                            <option value="">Active</option>
                                                            <option value="">Expired</option>
                                                        </select>
                                                    </td>
                                                    <td>
                                                        <div class="tableButtonSetting">
                                                            <div class="btn-group dropstart">
                                                                <a href="#" class="dropdown-toggle" type="button"
                                                                   data-bs-toggle="dropdown" aria-expanded="false">
                                                                    <img src="assets/icons/DotsThreeOutline.svg" alt="">
                                                                </a>
                                                                <ul class="dropdown-menu tosetWidh-Dropdown">
                                                                    <li><a class="dropdown-item  togivepaddingLeft" href="taskView.php">View</a></li>
                                                                    <li><a class="dropdown-item  togivepaddingLeft" href="#" data-bs-toggle="modal" data-bs-target="#DeleteModal" type="button">Delete</a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <div class="custom-Radio-Button">
                                                            <label class="custom-radio m-0" for="tablec2">
                                                                <input type="checkbox" class="customme"
                                                                       name="customRadio" id="tablec2">
                                                                <span class="radio-btn"></span>

                                                            </label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            6065
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Check-up Assignment
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            <span class="badge badge-inactive">Angel</span>
                                                            <span class="badge badge-inactive">Aubrey</span>
                                                            
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <select name="" class="js-select2">
                                                            <option value="Approved">Approved</option>
                                                            <option value="">Submitted</option>
                                                            <option value="">Active</option>
                                                            <option value="">Expired</option>
                                                        </select>
                                                    </td>
                                                    <td>
                                                        <div class="tableButtonSetting">
                                                            <div class="btn-group dropstart">
                                                                <a href="#" class="dropdown-toggle" type="button"
                                                                   data-bs-toggle="dropdown" aria-expanded="false">
                                                                    <img src="assets/icons/DotsThreeOutline.svg" alt="">
                                                                </a>
                                                                <ul class="dropdown-menu tosetWidh-Dropdown">
                                                                    <li><a class="dropdown-item  togivepaddingLeft" href="taskView.php">View</a></li>
                                                                    <li><a class="dropdown-item  togivepaddingLeft" href="#" data-bs-toggle="modal" data-bs-target="#DeleteModal" type="button">Delete</a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <div class="custom-Radio-Button">
                                                            <label class="custom-radio m-0" for="tablec3">
                                                                <input type="checkbox" class="customme"
                                                                       name="customRadio" id="tablec3">
                                                                <span class="radio-btn"></span>

                                                            </label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            6690
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Check-up Assignment
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            <span class="badge badge-inactive">Arlene</span>
                                                            <span class="badge badge-inactive">Darrell</span>
                                                            
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <select name="" class="js-select2">
                                                            <option value="Approved">Approved</option>
                                                            <option value="">Submitted</option>
                                                            <option value="">Active</option>
                                                            <option value="">Expired</option>
                                                        </select>
                                                    </td>
                                                    <td>
                                                        <div class="tableButtonSetting">
                                                            <div class="btn-group dropstart">
                                                                <a href="#" class="dropdown-toggle" type="button"
                                                                   data-bs-toggle="dropdown" aria-expanded="false">
                                                                    <img src="assets/icons/DotsThreeOutline.svg" alt="">
                                                                </a>
                                                                <ul class="dropdown-menu tosetWidh-Dropdown">
                                                                    <li><a class="dropdown-item  togivepaddingLeft" href="taskView.php">View</a></li>
                                                                    <li><a class="dropdown-item  togivepaddingLeft" href="#" data-bs-toggle="modal" data-bs-target="#DeleteModal" type="button">Delete</a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <div class="custom-Radio-Button">
                                                            <label class="custom-radio m-0" for="tablec4">
                                                                <input type="checkbox" class="customme"
                                                                       name="customRadio" id="tablec4">
                                                                <span class="radio-btn"></span>

                                                            </label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            5560
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Check-up Assignment
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            <span class="badge badge-inactive">Philip</span>
                                                            <span class="badge badge-inactive">Esther</span>
                                                            
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <select name="" class="js-select2">
                                                            <option value="Approved">Approved</option>
                                                            <option value="">Submitted</option>
                                                            <option value="">Active</option>
                                                            <option value="">Expired</option>
                                                        </select>
                                                    </td>
                                                    <td>
                                                        <div class="tableButtonSetting">
                                                            <div class="btn-group dropstart">
                                                                <a href="#" class="dropdown-toggle" type="button"
                                                                   data-bs-toggle="dropdown" aria-expanded="false">
                                                                    <img src="assets/icons/DotsThreeOutline.svg" alt="">
                                                                </a>
                                                                <ul class="dropdown-menu tosetWidh-Dropdown">
                                                                    <li><a class="dropdown-item  togivepaddingLeft" href="taskView.php">View</a></li>
                                                                    <li><a class="dropdown-item  togivepaddingLeft" href="#" data-bs-toggle="modal" data-bs-target="#DeleteModal" type="button">Delete</a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                                </tbody>

                                            </table>

                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="nav-contact" role="tabpanel"
                                         aria-labelledby="nav-contact-tab">
                                        <div class="mb-3">
                                            <div class="align-items-center d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column justify-content-between toSetFilterIcon">
                                                <h4 class="file-Heading">
                                                    Tasks Approved
                                                </h4>
                                                <div class="mt-xxl-0 mt-xl-0 mt-lg-0 mt-md-0 mt-sm-3 mt-3 d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column gap-2">
                                                    <button class="FilterButtonSetting btn btn-secondary d-flex gap-2 align-items-center">
                                                        Sort by
                                                        <svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                                                             xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M3.375 13.4995H7.3125M10.125 11.812L12.9375 14.6245M12.9375 14.6245L15.7499 11.8125M12.9375 14.6245L12.9375 7.87451M3.375 8.99951H8.43743M3.375 4.49951H12.9374"
                                                                  stroke-width="1.5" stroke-linecap="round"
                                                                  stroke-linejoin="round"/>
                                                        </svg>
                                                    </button>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="table-responsive">
                                            <table id="" class="dataTable table-responsive stripe w-100 ">
                                                <thead>
                                                <tr>
                                                    <th>
                                                        <div class="custom-Radio-Button">
                                                            <label class="custom-radio m-0" for="ex_bth">
                                                                <input type="checkbox" class="customme"
                                                                       name="customRadio" id="ex_bth">
                                                                <span class="radio-btn"></span>

                                                            </label>
                                                        </div>
                                                    </th>
                                                    <th>Date Created</th>
                                                    <th class="text-start">Task Id</th>
                                                    <th>Task Tittle</th>
                                                    <th>Assigned To</th>
                                                    <th>Start on</th>
                                                    <th>End on</th>
                                                    <th>Status</th>
                                                    <th></th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <tr>
                                                    <td>
                                                        <div class="custom-Radio-Button">
                                                            <label class="custom-radio m-0" for="tablec1">
                                                                <input type="checkbox" class="customme"
                                                                       name="customRadio" id="tablec1">
                                                                <span class="radio-btn"></span>

                                                            </label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            03:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            5045
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Check-up Assignment
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            <span class="badge badge-inactive">Greg</span>
                                                            <span class="badge badge-inactive">Gladys</span>
                                                            
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <select name="" class="js-select2">
                                                            <option value="Approved">Approved</option>
                                                            <option value="">Submitted</option>
                                                            <option value="">Active</option>
                                                            <option value="">Expired</option>
                                                        </select>
                                                    </td>
                                                    <td>
                                                        <div class="tableButtonSetting">
                                                            <div class="btn-group dropstart">
                                                                <a href="#" class="dropdown-toggle" type="button"
                                                                   data-bs-toggle="dropdown" aria-expanded="false">
                                                                    <img src="assets/icons/DotsThreeOutline.svg" alt="">
                                                                </a>
                                                                <ul class="dropdown-menu tosetWidh-Dropdown">
                                                                    <li><a class="dropdown-item  togivepaddingLeft" href="taskView.php">View</a></li>
                                                                    <li><a class="dropdown-item  togivepaddingLeft" href="#" data-bs-toggle="modal" data-bs-target="#DeleteModal" type="button">Delete</a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <div class="custom-Radio-Button">
                                                            <label class="custom-radio m-0" for="tablec2">
                                                                <input type="checkbox" class="customme"
                                                                       name="customRadio" id="tablec2">
                                                                <span class="radio-btn"></span>

                                                            </label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            6065
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Check-up Assignment
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            <span class="badge badge-inactive">Angel</span>
                                                            <span class="badge badge-inactive">Aubrey</span>
                                                            
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <select name="" class="js-select2">
                                                            <option value="Approved">Approved</option>
                                                            <option value="">Submitted</option>
                                                            <option value="">Active</option>
                                                            <option value="">Expired</option>
                                                        </select>
                                                    </td>
                                                    <td>
                                                        <div class="tableButtonSetting">
                                                            <div class="btn-group dropstart">
                                                                <a href="#" class="dropdown-toggle" type="button"
                                                                   data-bs-toggle="dropdown" aria-expanded="false">
                                                                    <img src="assets/icons/DotsThreeOutline.svg" alt="">
                                                                </a>
                                                                <ul class="dropdown-menu tosetWidh-Dropdown">
                                                                    <li><a class="dropdown-item  togivepaddingLeft" href="taskView.php">View</a></li>
                                                                    <li><a class="dropdown-item  togivepaddingLeft" href="#" type="button" data-bs-toggle="modal" data-bs-target="#DeleteModal">Delete</a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <div class="custom-Radio-Button">
                                                            <label class="custom-radio m-0" for="tablec3">
                                                                <input type="checkbox" class="customme"
                                                                       name="customRadio" id="tablec3">
                                                                <span class="radio-btn"></span>

                                                            </label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            6690
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Check-up Assignment
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            <span class="badge badge-inactive">Arlene</span>
                                                            <span class="badge badge-inactive">Darrell</span>
                                                            
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <select name="" class="js-select2">
                                                            <option value="Approved">Approved</option>
                                                            <option value="">Submitted</option>
                                                            <option value="">Active</option>
                                                            <option value="">Expired</option>
                                                        </select>
                                                    </td>
                                                    <td>
                                                        <div class="tableButtonSetting">
                                                            <div class="btn-group dropstart">
                                                                <a href="#" class="dropdown-toggle" type="button"
                                                                   data-bs-toggle="dropdown" aria-expanded="false">
                                                                    <img src="assets/icons/DotsThreeOutline.svg" alt="">
                                                                </a>
                                                                <ul class="dropdown-menu tosetWidh-Dropdown">
                                                                    <li><a class="dropdown-item  togivepaddingLeft" href="taskView.php">View</a></li>
                                                                    <li><a class="dropdown-item  togivepaddingLeft" href="#" data-bs-toggle="modal" data-bs-target="#DeleteModal" type="button">Delete</a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <div class="custom-Radio-Button">
                                                            <label class="custom-radio m-0" for="tablec4">
                                                                <input type="checkbox" class="customme"
                                                                       name="customRadio" id="tablec4">
                                                                <span class="radio-btn"></span>

                                                            </label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            5560
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Check-up Assignment
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            <span class="badge badge-inactive">Philip</span>
                                                            <span class="badge badge-inactive">Esther</span>
                                                            
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <select name="" class="js-select2">
                                                            <option value="Approved">Approved</option>
                                                            <option value="">Submitted</option>
                                                            <option value="">Active</option>
                                                            <option value="">Expired</option>
                                                        </select>
                                                    </td>
                                                    <td>
                                                        <div class="tableButtonSetting">
                                                            <div class="btn-group dropstart">
                                                                <a href="#" class="dropdown-toggle" type="button"
                                                                   data-bs-toggle="dropdown" aria-expanded="false">
                                                                    <img src="assets/icons/DotsThreeOutline.svg" alt="">
                                                                </a>
                                                                <ul class="dropdown-menu tosetWidh-Dropdown">
                                                                    <li><a class="dropdown-item  togivepaddingLeft" href="taskView.php">View</a></li>
                                                                    <li><a class="dropdown-item  togivepaddingLeft" href="#" data-bs-toggle="modal" data-bs-target="#DeleteModal" type="button">Delete</a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                                </tbody>

                                            </table>

                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="nav-contact2" role="tabpanel"
                                         aria-labelledby="nav-contact2-tab">
                                        <div class="mb-3">
                                            <div class="align-items-center d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column justify-content-between toSetFilterIcon">
                                                <h4 class="file-Heading">
                                                    Tasks Active
                                                </h4>
                                                <div class="mt-xxl-0 mt-xl-0 mt-lg-0 mt-md-0 mt-sm-3 mt-3 d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column gap-2">
                                                    <button class="FilterButtonSetting btn btn-secondary d-flex gap-2 align-items-center">
                                                        Sort by
                                                        <svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                                                             xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M3.375 13.4995H7.3125M10.125 11.812L12.9375 14.6245M12.9375 14.6245L15.7499 11.8125M12.9375 14.6245L12.9375 7.87451M3.375 8.99951H8.43743M3.375 4.49951H12.9374"
                                                                  stroke-width="1.5" stroke-linecap="round"
                                                                  stroke-linejoin="round"/>
                                                        </svg>
                                                    </button>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="table-responsive">
                                            <table id="" class="dataTable table-responsive stripe w-100 ">
                                                <thead>
                                                <tr>
                                                    <th>
                                                        <div class="custom-Radio-Button">
                                                            <label class="custom-radio m-0" for="ex_bth">
                                                                <input type="checkbox" class="customme"
                                                                       name="customRadio" id="ex_bth">
                                                                <span class="radio-btn"></span>

                                                            </label>
                                                        </div>
                                                    </th>
                                                    <th>Date Created</th>
                                                    <th class="text-start">Task Id</th>
                                                    <th>Task Tittle</th>
                                                    <th>Assigned To</th>
                                                    <th>Start on</th>
                                                    <th>End on</th>
                                                    <th>Status</th>
                                                    <th></th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <tr>
                                                    <td>
                                                        <div class="custom-Radio-Button">
                                                            <label class="custom-radio m-0" for="tablec1">
                                                                <input type="checkbox" class="customme"
                                                                       name="customRadio" id="tablec1">
                                                                <span class="radio-btn"></span>

                                                            </label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            03:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            5045
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Check-up Assignment
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            <span class="badge badge-inactive">Greg</span>
                                                            <span class="badge badge-inactive">Gladys</span>
                                                            
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <select name="" class="js-select2">
                                                            <option value="Approved">Approved</option>
                                                            <option value="">Submitted</option>
                                                            <option value="">Active</option>
                                                            <option value="">Expired</option>
                                                        </select>
                                                    </td>
                                                    <td>
                                                        <div class="tableButtonSetting">
                                                            <div class="btn-group dropstart">
                                                                <a href="#" class="dropdown-toggle" type="button"
                                                                   data-bs-toggle="dropdown" aria-expanded="false">
                                                                    <img src="assets/icons/DotsThreeOutline.svg" alt="">
                                                                </a>
                                                                <ul class="dropdown-menu tosetWidh-Dropdown">
                                                                    <li><a class="dropdown-item  togivepaddingLeft" href="taskView.php">View</a></li>
                                                                    <li><a class="dropdown-item  togivepaddingLeft" href="#" type="button" data-bs-toggle="modal" data-bs-target="#DeleteModal">Delete</a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <div class="custom-Radio-Button">
                                                            <label class="custom-radio m-0" for="tablec2">
                                                                <input type="checkbox" class="customme"
                                                                       name="customRadio" id="tablec2">
                                                                <span class="radio-btn"></span>

                                                            </label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            6065
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Check-up Assignment
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            <span class="badge badge-inactive">Angel</span>
                                                            <span class="badge badge-inactive">Aubrey</span>
                                                            
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <select name="" class="js-select2">
                                                            <option value="Approved">Approved</option>
                                                            <option value="">Submitted</option>
                                                            <option value="">Active</option>
                                                            <option value="">Expired</option>
                                                        </select>
                                                    </td>
                                                    <td>
                                                        <div class="tableButtonSetting">
                                                            <div class="btn-group dropstart">
                                                                <a href="#" class="dropdown-toggle" type="button"
                                                                   data-bs-toggle="dropdown" aria-expanded="false">
                                                                    <img src="assets/icons/DotsThreeOutline.svg" alt="">
                                                                </a>
                                                                <ul class="dropdown-menu tosetWidh-Dropdown">
                                                                    <li><a class="dropdown-item  togivepaddingLeft" href="taskView.php">View</a></li>
                                                                    <li><a class="dropdown-item  togivepaddingLeft" href="#" data-bs-toggle="modal" data-bs-target="#DeleteModal" type="button">Delete</a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <div class="custom-Radio-Button">
                                                            <label class="custom-radio m-0" for="tablec3">
                                                                <input type="checkbox" class="customme"
                                                                       name="customRadio" id="tablec3">
                                                                <span class="radio-btn"></span>

                                                            </label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            6690
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Check-up Assignment
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            <span class="badge badge-inactive">Arlene</span>
                                                            <span class="badge badge-inactive">Darrell</span>
                                                            
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <select name="" class="js-select2">
                                                            <option value="Approved">Approved</option>
                                                            <option value="">Submitted</option>
                                                            <option value="">Active</option>
                                                            <option value="">Expired</option>
                                                        </select>
                                                    </td>
                                                    <td>
                                                        <div class="tableButtonSetting">
                                                            <div class="btn-group dropstart">
                                                                <a href="#" class="dropdown-toggle" type="button"
                                                                   data-bs-toggle="dropdown" aria-expanded="false">
                                                                    <img src="assets/icons/DotsThreeOutline.svg" alt="">
                                                                </a>
                                                                <ul class="dropdown-menu tosetWidh-Dropdown">
                                                                    <li><a class="dropdown-item  togivepaddingLeft" href="taskView.php">View</a></li>
                                                                    <li><a class="dropdown-item  togivepaddingLeft" href="#" data-bs-toggle="modal" data-bs-target="#DeleteModal" type="button">Delete</a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <div class="custom-Radio-Button">
                                                            <label class="custom-radio m-0" for="tablec4">
                                                                <input type="checkbox" class="customme"
                                                                       name="customRadio" id="tablec4">
                                                                <span class="radio-btn"></span>

                                                            </label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            5560
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Check-up Assignment
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            <span class="badge badge-inactive">Philip</span>
                                                            <span class="badge badge-inactive">Esther</span>
                                                            
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <select name="" class="js-select2">
                                                            <option value="Approved">Approved</option>
                                                            <option value="">Submitted</option>
                                                            <option value="">Active</option>
                                                            <option value="">Expired</option>
                                                        </select>
                                                    </td>
                                                    <td>
                                                        <div class="tableButtonSetting">
                                                            <div class="btn-group dropstart">
                                                                <a href="#" class="dropdown-toggle" type="button"
                                                                   data-bs-toggle="dropdown" aria-expanded="false">
                                                                    <img src="assets/icons/DotsThreeOutline.svg" alt="">
                                                                </a>
                                                                <ul class="dropdown-menu tosetWidh-Dropdown">
                                                                    <li><a class="dropdown-item  togivepaddingLeft" href="taskView.php">View</a></li>
                                                                    <li><a class="dropdown-item  togivepaddingLeft" href="#" type="button" data-bs-toggle="modal" data-bs-target="#DeleteModal">Delete</a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                                </tbody>

                                            </table>

                                        </div>
                                    </div>
                                    <div class="tab-pane fade" id="nav-contact3" role="tabpanel"
                                         aria-labelledby="nav-contact3-tab">
                                        <div class="mb-3">
                                            <div class="align-items-center d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column justify-content-between toSetFilterIcon">
                                                <h4 class="file-Heading">
                                                    Task Expired
                                                </h4>
                                                <div class="mt-xxl-0 mt-xl-0 mt-lg-0 mt-md-0 mt-sm-3 mt-3 d-flex flex-xxl-row flex-xl-row flex-lg-row flex-md-row flex-sm-column flex-column gap-2">
                                                    <button class="FilterButtonSetting btn btn-secondary d-flex gap-2 align-items-center">
                                                        Sort by
                                                        <svg width="18" height="18" viewBox="0 0 18 18" fill="none"
                                                             xmlns="http://www.w3.org/2000/svg">
                                                            <path d="M3.375 13.4995H7.3125M10.125 11.812L12.9375 14.6245M12.9375 14.6245L15.7499 11.8125M12.9375 14.6245L12.9375 7.87451M3.375 8.99951H8.43743M3.375 4.49951H12.9374"
                                                                  stroke-width="1.5" stroke-linecap="round"
                                                                  stroke-linejoin="round"/>
                                                        </svg>
                                                    </button>

                                                </div>
                                            </div>
                                        </div>
                                        <div class="table-responsive">
                                            <table id="" class="dataTable table-responsive stripe w-100 ">
                                                <thead>
                                                <tr>
                                                    <th>
                                                        <div class="custom-Radio-Button">
                                                            <label class="custom-radio m-0" for="ex_bth">
                                                                <input type="checkbox" class="customme"
                                                                       name="customRadio" id="ex_bth">
                                                                <span class="radio-btn"></span>

                                                            </label>
                                                        </div>
                                                    </th>
                                                    <th>Date Created</th>
                                                    <th class="text-start">Task Id</th>
                                                    <th>Task Tittle</th>
                                                    <th>Assigned To</th>
                                                    <th>Start on</th>
                                                    <th>End on</th>
                                                    <th>Status</th>
                                                    <th></th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <tr>
                                                    <td>
                                                        <div class="custom-Radio-Button">
                                                            <label class="custom-radio m-0" for="tablec1">
                                                                <input type="checkbox" class="customme"
                                                                       name="customRadio" id="tablec1">
                                                                <span class="radio-btn"></span>

                                                            </label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            03:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            5045
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Check-up Assignment
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            <span class="badge badge-inactive">Greg</span>
                                                            <span class="badge badge-inactive">Gladys</span>
                                                            
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <select name="" class="js-select2">
                                                            <option value="Approved">Approved</option>
                                                            <option value="">Submitted</option>
                                                            <option value="">Active</option>
                                                            <option value="">Expired</option>
                                                        </select>
                                                    </td>
                                                    <td>
                                                        <div class="tableButtonSetting">
                                                            <div class="btn-group dropstart">
                                                                <a href="#" class="dropdown-toggle" type="button"
                                                                   data-bs-toggle="dropdown" aria-expanded="false">
                                                                    <img src="assets/icons/DotsThreeOutline.svg" alt="">
                                                                </a>
                                                                <ul class="dropdown-menu tosetWidh-Dropdown">
                                                                    <li><a class="dropdown-item  togivepaddingLeft" href="taskView.php">View</a></li>
                                                                    <li><a class="dropdown-item  togivepaddingLeft" href="#" type="button" data-bs-toggle="modal" data-bs-target="#DeleteModal">Delete</a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <div class="custom-Radio-Button">
                                                            <label class="custom-radio m-0" for="tablec2">
                                                                <input type="checkbox" class="customme"
                                                                       name="customRadio" id="tablec2">
                                                                <span class="radio-btn"></span>

                                                            </label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            6065
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Check-up Assignment
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            <span class="badge badge-inactive">Angel</span>
                                                            <span class="badge badge-inactive">Aubrey</span>
                                                            
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <select name="" class="js-select2">
                                                            <option value="Approved">Approved</option>
                                                            <option value="">Submitted</option>
                                                            <option value="">Active</option>
                                                            <option value="">Expired</option>
                                                        </select>
                                                    </td>
                                                    <td>
                                                        <div class="tableButtonSetting">
                                                            <div class="btn-group dropstart">
                                                                <a href="#" class="dropdown-toggle" type="button"
                                                                   data-bs-toggle="dropdown" aria-expanded="false">
                                                                    <img src="assets/icons/DotsThreeOutline.svg" alt="">
                                                                </a>
                                                                <ul class="dropdown-menu tosetWidh-Dropdown">
                                                                    <li><a class="dropdown-item  togivepaddingLeft" href="taskView.php">View</a></li>
                                                                    <li><a class="dropdown-item  togivepaddingLeft" href="#" data-bs-toggle="modal" data-bs-target="#DeleteModal" type="button">Delete</a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <div class="custom-Radio-Button">
                                                            <label class="custom-radio m-0" for="tablec3">
                                                                <input type="checkbox" class="customme"
                                                                       name="customRadio" id="tablec3">
                                                                <span class="radio-btn"></span>

                                                            </label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            6690
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Check-up Assignment
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            <span class="badge badge-inactive">Arlene</span>
                                                            <span class="badge badge-inactive">Darrell</span>
                                                            
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <select name="" class="js-select2">
                                                            <option value="Approved">Approved</option>
                                                            <option value="">Submitted</option>
                                                            <option value="">Active</option>
                                                            <option value="">Expired</option>
                                                        </select>
                                                    </td>
                                                    <td>
                                                        <div class="tableButtonSetting">
                                                            <div class="btn-group dropstart">
                                                                <a href="#" class="dropdown-toggle" type="button"
                                                                   data-bs-toggle="dropdown" aria-expanded="false">
                                                                    <img src="assets/icons/DotsThreeOutline.svg" alt="">
                                                                </a>
                                                                <ul class="dropdown-menu tosetWidh-Dropdown">
                                                                    <li><a class="dropdown-item  togivepaddingLeft" href="taskView.php">View</a></li>
                                                                    <li><a class="dropdown-item  togivepaddingLeft" href="#" type="button" data-bs-toggle="modal" data-bs-target="#DeleteModal">Delete</a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <div class="custom-Radio-Button">
                                                            <label class="custom-radio m-0" for="tablec4">
                                                                <input type="checkbox" class="customme"
                                                                       name="customRadio" id="tablec4">
                                                                <span class="radio-btn"></span>

                                                            </label>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            5560
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Check-up Assignment
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            <span class="badge badge-inactive">Philip</span>
                                                            <span class="badge badge-inactive">Esther</span>
                                                            
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <p class="p-0 m-0 table-MainHeading">
                                                            Jan 19, 2022
                                                        </p>
                                                        <p class="p-0 m-0 table-SubHeading">
                                                            3:45 pm
                                                        </p>
                                                    </td>
                                                    <td>
                                                        <select name="" class="js-select2">
                                                            <option value="Approved">Approved</option>
                                                            <option value="">Submitted</option>
                                                            <option value="">Active</option>
                                                            <option value="">Expired</option>
                                                        </select>
                                                    </td>
                                                    <td>
                                                        <div class="tableButtonSetting">
                                                            <div class="btn-group dropstart">
                                                                <a href="#" class="dropdown-toggle" type="button"
                                                                   data-bs-toggle="dropdown" aria-expanded="false">
                                                                    <img src="assets/icons/DotsThreeOutline.svg" alt="">
                                                                </a>
                                                                <ul class="dropdown-menu tosetWidh-Dropdown">
                                                                    <li><a class="dropdown-item  togivepaddingLeft" href="taskView.php">View</a></li>
                                                                    <li><a class="dropdown-item  togivepaddingLeft" href="#" data-bs-toggle="modal" data-bs-target="#DeleteModal" type="button">Delete</a></li>
                                                                </ul>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                                </tbody>

                                            </table>

                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>

@include('group_manager.footer')