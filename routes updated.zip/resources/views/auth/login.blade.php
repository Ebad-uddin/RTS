{{-- @extends('layouts.app')


    <style>
        .content-page, .rtl-page {
            padding-bottom:0 !important;
        }
    </style>
@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">{{ __('Login') }}</div>

                <div class="card-body">
                    <form method="POST" action="{{ route('login') }}">
                        @csrf

                        <div class="row mb-3">
                            <label for="email" class="col-md-4 col-form-label text-md-end">{{ __('Email Address') }}</label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email" autofocus>

                                @error('email')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="row mb-3">
                            <label for="password" class="col-md-4 col-form-label text-md-end">{{ __('Password') }}</label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" required autocomplete="current-password">

                                @error('password')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="row mb-3">
                            <div class="col-md-6 offset-md-4">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="remember" id="remember" {{ old('remember') ? 'checked' : '' }}>

                                    <label class="form-check-label" for="remember">
                                        {{ __('Remember Me') }}
                                    </label>
                                </div>
                            </div>
                        </div>

                        <div class="row mb-0">
                            <div class="col-md-8 offset-md-4">
                                <button type="submit" class="btn btn-primary">
                                    {{ __('Login') }}
                                </button>

                                @if (Route::has('password.request'))
                                    <a class="btn btn-link" href="{{ route('password.request') }}">
                                        {{ __('Forgot Your Password?') }}
                                    </a>
                                @endif
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection --}}

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Remote Tracking System | Login</title>
    <link rel="stylesheet" href="{{ asset('public/assets/vendor/bootstrap/bootstrap-dist.min.css') }}">
    <link rel="stylesheet" href="{{ asset('public/assets/scss/admin.css') }}">
    <link rel="stylesheet" href="{{ asset('public/assets/vendor/%40fortawesome/fontawesome-free/css/all.min.css') }}">
</head>

<body>
    <div class="content-page pb-0">
        <div class="login-page">
            <div class="login-page-inner h-100 w-100 overflow-y-hidden">
                <div class="container h-100">
                    <div class="h-100 d-flex justify-content-center align-items-center">
                        <div class="card login-card">
                            <div class="card-body login-card-body">
                                <div class="d-flex justify-content-center mb-3">
                                    <div class="d-flex justify-content-center align-items-center login-page-logo">
                                        <img src="{{ asset('public/assets/images/main_logo.png') }}"
                                            class="signin_logo">
                                    </div>
                                </div>
                                <div class="mb-3 d-flex justify-content-center align-items-center flex-column">
                                    <h1 class="login-head1 mb-0">Welcome!</h1>
                                    <!-- <label class="login-label">Looking excited to catch all your tasks.</label> -->
                                </div>
                                <div>
                                    <form class="login_form" method="POST" action="{{ route('login') }}">
                                        @csrf
                                        <div class="position-relative login_field">
                                            <label class="login_form_label mb-1">Email</label>
                                            <input id="email"
                                                class="form-control form_input w-100 @error('email') is-invalid @enderror"
                                                type="email" name="email" value="{{ old('email') }}"
                                                placeholder="Please enter your email" required autocomplete="email"
                                                autofocus><img class="lock_svg position-absolute"
                                                src="{{ asset('public/assets/icons/user_login icon.svg') }}"
                                                alt="">

                                            @error('email')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>

                                        <div class="position-relative login_field">
                                            <label class="login_form_label mb-1">Password</label>
                                            <input id="password" type="password"
                                                class="form-control w-100 form_input @error('password') is-invalid @enderror"
                                                placeholder="Please enter your password" name="password" required
                                                autocomplete="current-password"><img class="lock_svg position-absolute"
                                                src="{{ asset('public/assets/icons/lock icon.svg') }}" alt="">

                                            @error('password')
                                                <span class="invalid-feedback" role="alert">
                                                    <strong>{{ $message }}</strong>
                                                </span>
                                            @enderror
                                        </div>




                                        <div class="row mb-0">
                                            <div class="d-flex justify-content-center align-items-center mt-4">
                                                <button type="submit" class="btn btn-primary signin_btn">
                                                    {{ __('Sign In') }}
                                                </button>

                                                {{-- @if (Route::has('password.request'))
                                                    <a class="btn btn-link" href="{{ route('password.request') }}">
                                                        {{ __('Forgot Your Password?') }}
                                                    </a>
                                                @endif --}}
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="{{ asset('public/assets/js/all.min.js') }}"></script>
    <script>
        function password_show_hide() {
            var x = document.getElementById("password");
            var show_eye = document.getElementById("show_eye");
            var hide_eye = document.getElementById("hide_eye");
            hide_eye.classList.remove("d-none");
            if (x.type === "password") {
                x.type = "text";
                show_eye.style.display = "none";
                hide_eye.style.display = "block";
            } else {
                x.type = "password";
                show_eye.style.display = "block";
                hide_eye.style.display = "none";
            }
        }
    </script>

</body>
