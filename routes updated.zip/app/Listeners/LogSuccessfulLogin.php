<?php

namespace App\Listeners;
use App\Models\User;
use Illuminate\Auth\Events\Authenticated;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;

class LogSuccessfulLogin
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    public function handle(Authenticated $event)
    {
        $event->user->updateStatus(1); // Set status to 1 (or any other value to indicate logged in)
    }

    /**
     * Handle the event.
     *
     * @param  object  $event
     * @return void
     */
}
