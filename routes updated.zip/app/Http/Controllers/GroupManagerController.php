<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\TaskModel;
use App\Models\User;
use App\Models\Group;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Models\Tasklist;
use App\Models\Chat;
use App\Models\TaskStatus;
use Illuminate\Queue\worker;
use PhpParser\Node\Expr\Empty_;


class GroupManagerController extends Controller
{
    public function index()
    {

        $workers = Group::whereJsonContains('group_manager', [(string)Auth::id()])->get();

        $workers->each(function ($group) {
            $group->users = $group->users();
            // dd($group->users);
        });

        $group_data = Group::whereJsonContains('group_manager', [(string)Auth::id()])->first();
        // total tasks
        $all_tasks_data = [];
        $count_all_tasks = 0;
        if (!empty($group_data)) {

            $all_tasks_data = [];
            if (!empty($group_data)) {
                // foreach (json_decode($group_data->group_members) as $member) {
                    $all_tasks_data = TaskModel::orderBy('created_at' , 'desc')->where('grp_creator_id', Auth::id())->get();
                    if($all_tasks_data){
                        foreach($all_tasks_data as $key=>$v){
                            if(!empty($v->workers)){
                                // var_dump([json_decode($v['workers'],true)]);
                                $all_tasks_data[$key]['members'] = User::wherein('id',json_decode($v['workers'],true))->get();
                            }
                        }
                    }
                }

            // task submitted
            $submitted_task = [];
            $count_submitted_task = null;
            if (!empty($group_data)) {
                // foreach (json_decode($group_data->group_members) as $member) {
                    $submitted_task = TaskModel::orderBy('created_at' , 'desc')->where('grp_creator_id', Auth::id())->where('status', 'Submitted')->get();
                    if($all_tasks_data){
                        foreach($submitted_task as $key=>$v){
                            if(!empty($v->workers)){
                                // var_dump([json_decode($v['workers'],true)]);
                                $submitted_task[$key]['members'] = User::wherein('id',json_decode($v['workers'],true))->get();
                            }
                        }
                    }
                }
            // dd($submitted_task);
            // task approved
            $approved_task = [];
            if (!empty($group_data)) {
                // foreach (json_decode($group_data->group_members) as $member) {
                    $approved_task = TaskModel::orderBy('created_at' , 'desc')->where('grp_creator_id', Auth::id())->where('status', 'Approved')->get();
                    if($approved_task){
                        foreach($approved_task as $key=>$v){
                            if(!empty($v->workers)){
                                // var_dump([json_decode($v['workers'],true)]);
                                $approved_task[$key]['members'] = User::wherein('id',json_decode($v['workers'],true))->get();
                            }
                        }
                    }
                }
            // dd($approved_task);
            $active_task = [];
            $count_active_task = null;
            if (!empty($group_data)) {
                // foreach (json_decode($group_data->group_members) as $member) {
                    $active_task = TaskModel::orderBy('created_at' , 'desc')->where('grp_creator_id', Auth::id())->where('status', 'Active')->get();
                    if($active_task){
                        foreach($active_task as $key=>$v){
                            if(!empty($v->workers)){
                                // var_dump([json_decode($v['workers'],true)]);
                                $active_task[$key]['members'] = User::wherein('id',json_decode($v['workers'],true))->get();
                            }
                        }
                    }
                }
            // dd($active_task);
            $expired_task = [];
            $count_expired_task = null;
            if (!empty($group_data)) {
                // foreach (json_decode($group_data->group_members) as $member) {
                    $expired_task = TaskModel::orderBy('created_at' , 'desc')->where('grp_creator_id', Auth::id())->where('status', 'Expired')->get();
                    if($expired_task){
                        foreach($expired_task as $key=>$v){
                            if(!empty($v->workers)){
                                // var_dump([json_decode($v['workers'],true)]);
                                $expired_task[$key]['members'] = User::wherein('id',json_decode($v['workers'],true))->get();
                            }
                        }
                    }
                }
        } else {
            $count_expired_task = null;
            $count_active_task = null;
            $count_approve_task = null;
            $count_submitted_task = null;
            $all_tasks_data = [];
            $submitted_task = [];
            $approved_task = [];
            $active_task = [];
            $expired_task = [];
        }
        // dd($all_tasks_data);

        return view('group_manager.index')->with(compact('workers', 'all_tasks_data', 'submitted_task', 'approved_task', 'active_task', 'expired_task'));
    }


    public function Chat()
    {
        $all_tasks = Tasklist::all()->pluck('task_abbreviation');

        $workers = Group::whereJsonContains('group_manager', [(string)Auth::id()])->get();
        $workers->each(function ($group) {
            $group->users = $group->users();
            // dd($group->users[0]->chats);
        });
        $unread_chats = [];
        $group_data = Group::whereJsonContains('group_manager', [(string)Auth::id()])->get();
        // $group_data->each(function ($group) {
        //     $group->users = $group->users();
        //     // foreach($group->users as $k => $members){
        //     //     $group_data[$k]['members'] = chat::where('reciever_Id' , $members->id)->where('status', 0)->get();
        //     //     // dd($group_data[$k]['members']);
        //     //     $unread_chats[] = $group_data[$k]['members'];
        //     // }
        //     // dd($unread_chats);
        // });
        $group_data = Group::whereJsonContains('group_manager', [(string)Auth::id()])->get();
        // dd($group_data);
        if (!empty($group_data)) {
            foreach ($group_data as $k => $d) {
                if(!empty($d->group_members && !empty($d->group_manager))){
                    $group_data[$k]['users']=User::whereIn('id', array_map('intval', json_decode($d->group_members)))
                    ->orwhere('role', 'sitemanager')->orwhere('role' , 'superadmin')
                    ->get();
                }else{
                    $group_data[$k]['users'] = [];
                }
            }
        }
        return view('group_manager.chat')->with(compact('workers', 'all_tasks', 'group_data'));
    }
    // public function group_view(){
    //     $all_tasks = Tasklist::all()->pluck('task_abbreviation');
    //     $workers = User::orderBy('created_at', 'desc')->where('role', 'worker')->get();
    //     return view('group_manager.group-view')->with(compact('workers','all_tasks'));
    // }
    public function invoices()
    {
        $workers = Group::whereJsonContains('group_manager', [(string)Auth::id()])->get();
        $workers->each(function ($group) {
            $group->users = $group->users();
            // dd($group->users);
        });

        return view('group_manager.invoices')->with(compact('workers'));
    }
    public function reports()
    {
        $all_tasks = Tasklist::all()->pluck('task_abbreviation');
        $workers = Group::whereJsonContains('group_manager', [(string)Auth::id()])->get();
        $workers->each(function ($group) {
            $group->users = $group->users();
            // dd($group->users);
        });

        return view('group_manager.reports')->with(compact('workers', 'all_tasks'));
    }
    public function settings()
    {
        $user_data = User::orderBy('created_at', 'desc')->where('id', Auth::id())->first();
        $workers = Group::whereJsonContains('group_manager', [(string)Auth::id()])->get();
        $workers->each(function ($group) {
            $group->users = $group->users();
            // dd($group->users);
        });

        $all_tasks = Tasklist::all()->pluck('task_abbreviation');
        return view('group_manager.settings')->with(compact('workers', 'all_tasks', 'user_data'));
    }
    public function TaskManagement()
    {
        $all_tasks = Tasklist::all()->pluck('task_abbreviation');

        $workers = Group::whereJsonContains('group_manager', [(string)Auth::id()])->get();
        $workers->each(function ($group) {
            $group->users = $group->users();

        });

        // total tasks
        $group_data = Group::whereJsonContains('group_manager', [(string)Auth::id()])->first();

        $all_tasks_data = [];
        if (!empty($group_data)) {
            // foreach (json_decode($group_data->group_members) as $member) {
                $all_tasks_data = TaskModel::with('chats')->orderBy('created_at' , 'desc')->where('grp_creator_id', Auth::id())->get();
                if($all_tasks_data){
                    foreach($all_tasks_data as $key=>$v){
                        if(!empty($v->workers)){
                            // var_dump([json_decode($v['workers'],true)]);
                            $all_tasks_data[$key]['members'] = User::wherein('id',json_decode($v['workers'],true))->get();
                        }
                    }
                }

        }

        // print_r($all_tasks_data);
        return view('group_manager.Taskmanagement')->with(compact('workers', 'all_tasks', 'all_tasks_data'));
    }

    public function user_view($id)
    {
        $all_tasks = Tasklist::all()->pluck('task_abbreviation');

        $workers = Group::whereJsonContains('group_manager', [(string)Auth::id()])->get();
        $workers->each(function ($group) {
            $group->users = $group->users();
            // dd($group->users);
        });

        $workers = User::orderBy('created_at', 'desc')->where('role', 'worker')->get();
        $user_data = '';
        $user_data =  User::find($id);
        $all_tasks = Tasklist::all()->pluck('task_abbreviation');
        if($user_data === null){
            $user_data = 'No data Available';
        }else{
            $user_data;
        }
        $documents = [];
        $allFiles = json_decode($user_data->images);

        if(!empty($user_data->images)){
            $allFiles['files'] = json_decode($user_data->images);
            $allFiles['id'] = $user_data->id;

        }else{
            $allFiles['files'] = [];
            $allFiles['id'] = '';
        }
        // $all_tasks = Tasklist::all()->pluck('task_abbreviation');
        return view('group_manager.user-view')->with(compact('workers', 'all_tasks','user_data', 'workers','allFiles','all_tasks'));
        // return view('group_manager.user-view')->with(compact('workers', 'all_tasks'));
    }



     // update user documents
     public function update_documents_user(Request $request)
     {
         $user_data = User::find($request['user_id']);
         $allFiles = [];

         if ($request->hasFile('images')) {
             foreach ($request->file('images') as $file) {
                 $imageName = $file->getClientOriginalName();
                 $file->storeAs('uploads', $imageName);
                 $allFiles[] = $imageName;
             }

             $db_files = json_decode($user_data->images);
             $updated_files = ($db_files) ? array_merge($db_files, $allFiles) : $allFiles;
         } else {
             $db_files = json_decode($user_data->images);
             if ($db_files && is_array($db_files)) {
                 $updated_files = $db_files;
             }
         }

         // dd($updated_files);
         $db_files = json_encode($updated_files);
         $user_data->update(['images' => $db_files]);

         return back()->with('status', 'Documents updated Successfully');
     }


     public function UpdateEmployee(Request $request){
        $user_data = User::find($request->user_id);
        $imageName = '';
        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $imageName = $image->getClientOriginalName();
            $image->storeAs('/uploads', $imageName);
        }
        else{
            $imageName = $user_data['image'];
        }
        $employee_details = $request->except('image');
        $employee_details['image'] = $imageName;
        $user_data->update($employee_details);
        return back()->with('success', 'Employee Successfully Updated');


    }



    public function user()
    {


        $all_tasks = Tasklist::all()->pluck('task_abbreviation');

        $workers = Group::whereJsonContains('group_manager', [(string)Auth::id()])->get();
        $workers->each(function ($group) {
            $group->users = $group->users();
            // dd($group->users);
        });

        $user_data = User::where('creator_id', Auth::id())->get();
        if (!empty($user_data)) {
            foreach ($user_data as $k => $d) {
                // if(!empty($d->id)){
                    $user_data[$k]['tasks']  =TaskModel::whereJsonContains('workers', (string)$d->id)->get()->count();

                // }else{
                //     $users_data[$k]['tasks'] = 0;
                // }
            }
        }
        // dd($user_data);
        return view('group_manager.user')->with(compact('workers', 'all_tasks','user_data'));
    }



    public function workgroups()
    {
        $all_tasks = Tasklist::all()->pluck('task_abbreviation');

        $workers = Group::whereJsonContains('group_manager', [(string)Auth::id()])->get();
        // dd($workers);

        $workers->each(function ($group) {
            $group->users = $group->users();
            // dd($group->users);
        });

        $memberz = User::where('creator_id',Auth::id())->get();



        $group_data = Group::whereJsonContains('group_manager', [(string)Auth::id()])->get();
        // dd($group_data);
        // array_map('intval', json_decode($d['group_members']));
        // var_dump($group_data);die;
        if (!empty($group_data)) {
            foreach ($group_data as $k => $d) {

                if(!empty($d->group_members)){
                    $group_data[$k]['members']=User::whereIn('id', array_map('intval', json_decode($d->group_members)))->get();
                    $group_data[$k]['group_members']=User::whereNotIn('id', array_map('intval', json_decode($d->group_members)))->where('creator_id', Auth::id())->get();
                }else{
                    $group_data[$k]['members'] = [];
                }
            }
        }
        // dd($group_data[$k]['group_members']);

        return view('group_manager.group-view')->with(compact('workers', 'memberz','all_tasks', 'group_data'));
    }

    // create task
    public function create_task(Request $request)
    {

        $task_images = [];
        if ($request->hasFile('images')) {
            foreach ($request->file('images') as $image) {
                $file_name = $image->getClientOriginalName();
                $image->storeAs('/uploads', $file_name);
                $task_images[] = $file_name;
            }
        }
        $post_data = $request->except('images');
        $post_data['grp_creator_id'] = Auth::id();
        $workers = $request['workers'];
        $task_abbreviation = $request['task_abbreviation'];
        $post_data['task_id'] = rand(10, 1000);
        $post_data['images'] =  json_encode($task_images);
        $post_data['workers'] = json_encode($workers);
        $post_data['task_abbreviation'] = json_encode($task_abbreviation);
        $post_data['status'] = 'Submitted';
        // dd($post_data);
        TaskModel::create($post_data);
        return back()->with('success', 'Task Created Successfully');
    }

    public function delete_task(Request $request)
    {
        $task_data = TaskModel::find($request->task_id);
        if (!is_null($task_data)) {
            $task_data->delete();
            return back()->with('success', 'Task Deleted Succssfully');
        } else {
            return back()->with('error', 'Task not found');
        }
    }


    // worker create
    public function creat_worker(Request $request)
    {
      $imageName = '';
        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $imageName = $image->getClientOriginalName();
            $image->storeAs('/uploads', $imageName);
        }
        $worker_details = $request->except('image');
        $worker_details['image'] = $imageName;

        $rand_pass = Str::random(12);
        $worker_details['password'] = Hash::make($rand_pass);
        $worker_details['creator_id'] = $request['creator_id'];

        $suc = User::create($worker_details);
        if($suc) {
            $email = new Mailer;
            $data = [
                'name' => $request->f_name . ' ' . $request->l_name,
                'email' => $request->email,
                'pass' => $rand_pass,
                'role' => $request->role,
            ];
            $view = view('includes.emailtemp', compact('data'))->render();
            $email->email($request->email,'Account Creation at Remote Tracking System',$view);

            // $message = "Email: $request->email <br> <br> Password: $rand_pass <br> <br> Role $request->role";
            // $email->email($request->email,'Account Creation', $message);
        }


        return back()->with('success', 'User created Successfully');
    }

    public function update_setting(Request $request)
    {
        // dd($request->all());
        $user_details = User::find($request->user_id);
        $imageName = '';
        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $imageName = $image->getClientOriginalName();
            $image->storeAs('/uploads', $imageName);
        } else {
            $imageName = $user_details['image'];
        }
        $form_data = $request->except('image');
        $form_data['image'] = $imageName;
        $user_details->update($form_data);
        return back()->with('status', 'details updated successfully');
    }

    // update password work
    public function updatePassword(Request $request)
    {
        // dd($request->all());
        $user_data = User::find(Auth::id());
        $password_verify = password_verify($request->CurrentPassword, $user_data->password);

        if ($password_verify) {
            if ($request['NewPassword'] == $request['ConfirmPassword']) {
                $new_pass = Hash::make($request['NewPassword']);
                User::where('id', Auth::id())->first()->update(['password' => $new_pass]);
                return back()->with('success', 'Password updated Successfully');
            } else {
                return back()->with('error', 'Password Does not match');
            }
        } else {
            return back()->with('error', 'Invalid Password');
        }
    }

    // group edit

    public function edit_group(Request $request)
    {
        $group_data = Group::find($request->group_id);
        // print_r($group_data); die;
        $all_group_members = [];
        $group_data->each(function ($group) {
            $group->users = $group->users();
            $all_group_members[] = $group->users;
        });
        print_r($all_group_members);
        // return response()->json($all_group_info);
    }


    public function taskView($id)
    {
        $all_tasks = Tasklist::all()->pluck('task_abbreviation');
        $workers = Group::whereJsonContains('group_manager', [(string)Auth::id()])->get();
        $workers->each(function ($group) {
            $group->users = $group->users();
            // dd($group->users);
        });

        $group_data = Group::whereJsonContains('group_manager', Auth::id())->get();
        $group_data->each(function ($group) {
            $group->users = $group->users();
            // dd($group->users);
        });
        $Task = TaskModel::where('id' , $id)->get();

        if (!empty($Task)) {
            foreach ($Task as $k => $d) {
                if(!empty($d->workers)){
                    $Task[$k]['members']=User::whereIn('id', array_map('intval', json_decode($d->workers)))->get();
                    $Task[$k]['online']=User::whereIn('id', array_map('intval', json_decode($d->workers)))
                    ->orwhere('role' , 'superadmin')
                    ->orWhere('role', 'sitemanager')
                    ->where('status' , 1)
                    ->get();
                }else{
                    $Task[$k]['members'] = [];
                }
            }
            // dd($Task);
            foreach ($Task as $k => $d) {
                if(!empty($d->task_abbreviation)){
                    $Task[$k]['abbr'] = TaskList::whereIn('id', array_map('intval', json_decode($d->task_abbreviation)))->get();
                }else{
                    $Task[$k]['abbr'] = [];
                }
            }
        }
        // dd($task[$k]['abbr']);
        if(!empty($Task[$k]['online'])){
            $count_online = count($Task[$k]['online']);
        }else{
            $count_online = [];
        }

        $Task->each(function ($task) {
            $task->users = $task->users();
            // dd($task->users);
        });
        if(!empty($Task[0]->images)){
            $allFiles['files'] = json_decode($Task[0]->images);
            $allFiles['id'] = $Task[0]->id;

        }else{
            $allFiles['files'] = [];
            $allFiles['id'] = '';
        }

        if(!empty($Task[0]['task_abbreviation'])){
            $task_list = Tasklist::orderBy('id', 'desc')->whereIn('id' , json_decode($Task[0]['task_abbreviation'],true))->get();
            // dd($task_list);
        }

        // var_dump(json_decode($Task[0]['task_abbreviation'],true)); die;
        $task_status = TaskStatus::orderBy('tasklist_id', 'desc')->select('tasklist_id','status')->where(['task_id'=>$id,'worker_id'=>Auth::user()->id])->get()->toArray();
        // dd($task_status);
        // var_dump($task_list->toArray());die;
        // dd($allFiles);
        // dd(json_decode($Task->task_abbreviation));
        return view('group_manager.taskView')->with(compact('workers','count_online','task_status', 'task_list', 'Task', 'allFiles', 'all_tasks', 'group_data'));
    }

    public function update_documents_task(Request $request)
    {
        $task_data = TaskModel::find($request['task_id']);
        $allFiles = [];

        if ($request->hasFile('images')) {
            foreach ($request->file('images') as $file) {
                $imageName = $file->getClientOriginalName();
                $file->storeAs('uploads', $imageName);
                $allFiles[] = $imageName;
            }
            $db_files = json_decode($task_data->images);
            $updated_files = array_merge($db_files, $allFiles);
        } else {
            $db_files = json_decode($task_data->images);
            if ($db_files && is_array($db_files)) {
                $updated_files = $db_files;
            }
        }

        $db_files = json_encode($updated_files);
        // dd($db_files);
        $task_data->update(['images' => $db_files]);

        return back()->with('success', 'Documents updated Successfully');
    }

    // document delete function
    public function delete_task_doc(Request $request)
    {
        $task_data = TaskModel::find($request->doc_id);
        $task_docs = json_decode($task_data->images, true);
        $pos = array_search($request->doc_name, $task_docs);
        if ($pos !== false) {
            echo "Position found: " . $pos;
            array_splice($task_docs, $pos, 1);
            $task_data->update(['images' => json_encode($task_docs)]);
            return back()->with('success', 'Document deleted Successfully');
        } else {
            return back()->with('error', 'Document not found');
        }
    }


    public function delete_user_data(Request $request){
        // dd($request->all());
        $user_data = User::find($request->del_user_id);
        if(!is_null($user_data)){
            $user_data->delete();
            return back()->with('success', 'User Deleted Successfully');
        }else{
            return back()->with('error', 'User not found');

        }
    }


    public function delete_user_doc(Request $request){
        $task_data = User::find($request->doc_id);
        $task_docs = json_decode($task_data->images, true);
        $pos = array_search($request->doc_name, $task_docs);
        if ($pos !== false) {
            echo "Position found: " . $pos;
            array_splice($task_docs, $pos, 1);
            $task_data->update(['images' => json_encode($task_docs)]);
            return back()->with('success', 'Document deleted Successfully');
        } else {
            return back()->with('error', 'Document not found');
        }
    }


    public function delete_user(Request $request){

        $group = Group::find($request->group_id);
        $existing_members = json_decode($group->group_members, true) ?? [];
        // dd($existing_members);

        $del_user_id = $request->del_user_id ?? [];

        $index = array_search($del_user_id, $existing_members);
        if ($index !== false) {
            unset($existing_members[$index]);
            $existing_members = array_values($existing_members);
        } else {
            return back()->with('status', 'User not found in the group');
        }

        $group->group_members = json_encode($existing_members);
        $group->save();


        return back()->with('status', 'Employee Deleted Succssfully');

    }



    // delete user from users table as well as groups

    public function delete_worker(Request $request){
        $worker_data = User::find($request->worker_id);

        if(!is_null($worker_data)){
            $groups = Group::all();

            foreach($groups as $group) {
                $group_manager = json_decode($group->group_manager, true);
                $group_members = json_decode($group->group_members, true);

                if(($key = array_search($request->worker_id, $group_manager)) !== false) {
                    unset($group_manager[$key]);
                }

                if(($key = array_search($request->worker_id, $group_members)) !== false) {
                    unset($group_members[$key]);
                }

                $group->group_manager = json_encode(array_values($group_manager));
                $group->group_members = json_encode(array_values($group_members));
                $group->save();
            }

            // Delete the user
            $worker_data->delete();

            return back()->with('success', 'Employee Deleted Successfully');
        } else {
            return back()->with('error', 'Employee not found');
        }
    }

    // update complete task

    public function task_complete(Request $request){
        $task_data = TaskModel::find($request->task_id);
        // print_r($task_data); die;
        $task_data->update(['status' => $request->status]);
        return response()->json(['success' => 'Task Completed Successfully']);
    }





    public function update_group(Request $request)
    {
        // print_r($request->all()); die;
        $group = Group::find($request->group_id);
        $existing_members = json_decode($group->group_members, true) ?? [];

        $selected_members = $request->group_members ?? [];
        $deselected_members = $request->deselected_workers ?? [];

        // foreach ($deselected_members as $deselected_member) {
        //     $index = array_search($deselected_member, $existing_members);
        //     if ($index !== false) {
        //         unset($existing_members[$index]);
        //     }
        // }

        $merged_members = array_unique(array_merge($existing_members, $selected_members));

        $group->group_members = json_encode($merged_members);

        $group->save();

        return back()->with('success', 'Group Members changed successfully');
    }

    public function search_member(Request $request){
        // print_r($request->all()); die;
        $users = User::where('f_name' , 'LIKE' , '%'.$request->text.'%')->get();
        return response()->json($users);
    }


    // check email validation
    public function checkEmail(Request $request){
        // print_r($request->all()); die;
        $check_user = User::where('email',$request->email)->exists();
       return $check_user;
    }




    public function del_group(Request $request)
    {
        $group_data = Group::find($request->del_group_id);
        if (!is_null($group_data)) {
            $group_data->delete();
            return back()->with('success', 'Group Successfully deleted');
        } else {
            return back()->with('error', 'Group not found');
        }
    }

    // chat working
    public function showchat(Request $request)
    {

        $chats = Chat::where(function ($query) use ($request) {
            $query->where('sender_Id', Auth::id())
                ->where('reciever_Id', $request->reciever_typed_id);
        })
            ->orWhere(function ($query) use ($request) {
                $query->where('sender_Id', $request->reciever_typed_id)
                    ->where('reciever_Id', Auth::id());
            })
            ->get();


        $user = User::where('id', $request->reciever_typed_id)->first();
        $view = view('includes.chat', compact('chats', 'user'))->render();
        return ['view' => $view];
    }

    public function sendMsg(Request $request)
    {
        Chat::create([
            'sender_Id' => Auth::id(),
            'reciever_Id' => $request['reciever_id'],
            'msg' => $request['sender_msg'],
            'type' => 'singleChat'
        ]);
    }

    // group chat working
    public function show_group_chat(Request $request)
    {
        // print_r($request->all()); die;

        $chats = Chat::where('group_id', $request->group_id)->get();
        // $tasks = TaskModel::where('id' ,$chats[0]->reciever_Id)->get();
        foreach($chats as $k => $chat){
            $chats[$k]['user_details'] = User::where('id' ,$chat->sender_Id)->first();
        }
        $view = view('includes.groupchat', compact('chats'))->render();
        return ['view' => $view];
    }

    public function send_grp_Msg(Request $request)
    {
        Chat::create([
            'sender_Id' => Auth::id(),
            'reciever_Id' => $request['reciever_id'],
            'type' => 'groupChat',
            'group_id' => $request['reciever_id'],
            'msg' => $request['sender_msg']
        ]);
    }

    function mark_as_complete(Request $request){
        // print_r($request->all()); die;
        $data = ['worker_id'=>Auth::user()->id,'tasklist_id'=>$request->task_list_id,'task_id'=>$request->task_id];
        $check = TaskStatus::where($data)->get();
        if(!$check->isEmpty()){
            echo "IF";
            TaskStatus::where('id',$check[0]->id)->delete();
        }else{
            $data['status'] = $request['status'];
            // var_dump($data);die;
            TaskStatus::create($data);

        }
    }


    function changeTaskStatus(Request $request){

        TaskModel::where('id',$request['task_id'])->update(["status"=>$request['status']]);
        return with('success', 'Group successfully updated');
    }


    public function task_active(Request $request){
        // print_r($request->all()); die;
        $task = TaskModel::find($request->id);
        // print_r($task); die;
        $task->update(['status' => $request->status]);
        return response()->json(['success' => 'Task is active now']);
    }


    public function task_expired(Request $request){
        $task = TaskModel::find($request->id);
        $task->update(['status' => $request->status]);
        return response()->json('success', 'Task is Epired now');
    }

    public function read_msg(Request $request){
        $change_status = Chat::where('reciever_Id', Auth::id())->where('sender_Id' , $request->read_id)->get();
        // print_r($change_status); die;
        foreach($change_status as $status){
            $status->update(['status' => 1]);
        }
        return response()->json(['success' => 'msg read']);

    }

    // counter function in sidebar

    public function msg_counter(){
        $chat_data = Chat::where('status' , 0)->where('reciever_Id' , Auth::id())->get();
        // print_r($chat_data); die;
        return response()->json($chat_data);
    }


    public function assignedWorkers(Request $request){
        $task_data = TaskModel::find($request->task_id);
        $workers = User::whereIn('id',array_map('intval', json_decode($task_data->workers)))->get();
        // print_r($workers); die;
        return response()->json($workers);
    }


    public function task_msg_counter(){
        $chat_data = TaskModel::with('chats')->where('grp_creator_id', Auth::id())->get();
        foreach($chat_data as $k => $d) {
            $chat_data[$k]['chat'] = Chat::where('type', 'groupChat')
            ->where('group_id', $d->id)
            ->where('sender_id', '!=', Auth::id())
            ->where(function($query) {
                $userId = Auth::id();
                $query->whereNull('seen')
                        ->orWhere(function($query) use ($userId) {
                            $query->whereNotNull('seen')
                                ->whereRaw('JSON_CONTAINS(seen, \'[' . $userId . ']\') = 0');
                        });
            })
            ->get();
        }

        // print_r($chat_data[$k]['chat']); die;
        return response()->json($chat_data);
    }

    public function read_group_msg(Request $request){
        $userId = auth()->user()->id;

        $chatMessages = Chat::where('group_id', $request->read_id)->where('sender_Id' , '!=' , Auth::id())->get();
        foreach ($chatMessages as $message) {
            $seenArray = json_decode($message->seen, true);
            if (!is_array($seenArray)) {
                $seenArray = [];
            }
            if (!in_array($userId, $seenArray)) {
                $seenArray[] = $userId;
                $seen_json = json_encode($seenArray);

                $message->update(['seen' => json_encode($seenArray)]);
            }
        }
        return response()->json(['success' => 'msg read']);
    }

    public function get_tasks(Request $request)
{

    $group_data = Group::whereJsonContains('group_manager', [(string)Auth::id()])->first();
    // total tasks
    $all_tasks_count = [];
    $all_tasks_count = 0;
    if (!empty($group_data)) {

        $all_tasks_count = [];
        if (!empty($group_data)) {
            // foreach (json_decode($group_data->group_members) as $member) {
                $all_tasks_count = TaskModel::orderBy('created_at' , 'desc')->where('check_status' , 'true')->count();
                if($all_tasks_count > 0){
                    $all_tasks_count = TaskModel::with('chats')->orderBy('created_at' , 'desc')->where('grp_creator_id', Auth::id())->get();
                    foreach($all_tasks_count as $key=>$v){
                        if(!empty($v->workers)){
                            $v->check_status = 'false';
                            $v->save();
                            $all_tasks_count[$key]['users'] = User::wherein('id',json_decode($v['workers'],true))->get();
                        }
                    }
                $tasks = view('includes.tasks',compact('all_tasks_count'))->render();
                return ['data' => $tasks];
                }
            }
    }
}


}
