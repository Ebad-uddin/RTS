<?php

namespace App\Http\Controllers;
use App\Models\TaskModel;
use App\Models\User;
use App\Models\Group;
use App\Models\Tasklist;
use App\Models\TaskStatus;
use App\Models\Chat;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;


use Illuminate\Http\Request;

class WorkerController extends Controller
{
    public function index(){

       // $task_data = TaskModel::whereJsonContains('workers', [(string)Auth::id()])->('status' , 'Approved')->orwhere('status', 'Complete')->orwhere('status', 'Expired')->get();

        $task_data = TaskModel::orderBy('created_at' , 'desc')->whereJsonContains('workers', [(string)Auth::id()])
    ->where(function($query) {
        $query->where('status', 'Approved')
              ->orWhere('status', 'Completed')
              ->orWhere('status', 'Expired')
              ->orWhere('status', 'Active');
    })
    ->get();
    // dd($task_data);

        //    dd(count($task_data));
           // total tasks
           $task_data->each(function ($workers) {
            $workers->users = $workers->users();
            // dd($workers->users);
        });
        $active_tasks = TaskModel::orderBy('created_at' , 'desc')->whereJsonContains('workers', [(string)Auth::id()])->where('status', 'Active')->get();
        //    dd($task_data);

           // total tasks
           $active_tasks->each(function ($workers) {
            $workers->users = $workers->users();
            // dd($workers->users);
        });
        $expired_tasks = TaskModel::orderBy('created_at' , 'desc')->whereJsonContains('workers', [(string)Auth::id()])->where('status', 'Expired')->get();
        //    dd($task_data);
           // total tasks
           $expired_tasks->each(function ($workers) {
            $workers->users = $workers->users();
            // dd($workers->users);
        });

        return view('worker.index')->with(compact('task_data','active_tasks','expired_tasks'));
    }
            public function Chat(){
                // $group_data->each(function ($group) {
                //     $group->users = $group->users();
                //     dd($group->users[0]->chats);
                // });

                $group_data = Group::whereJsonContains('group_members', [(string)Auth::id()])->get();
                // dd($group_data);
                if (!empty($group_data)) {
                    foreach ($group_data as $k => $d) {
                        if(!empty($d->group_members && !empty($d->group_manager))){
                            $group_data[$k]['user']=User::whereIn('id', array_map('intval', json_decode($d->group_members)))
                            ->orwhereIn('id', array_map('intval', json_decode($d->group_manager)))
                            ->orwhere('role', 'sitemanager')->orwhere('role' , 'superadmin')
                            ->get();
                        }else{
                            $group_data[$k]['user'] = [];
                        }
                    }
                }
                // dd($group_data[$k]['user']);


                $group_data->each(function ($group) {
                    $group->group_managers = $group->group_managers();
                    // dd($group->group_managers);
                });

                return view('worker.chat')->with(compact('group_data'));
            }
                public function group_view(){
                    return view('worker.group-view');
                }
                public function invlices(){
                    return view('worker.invoices');
                }
                public function reports(){
                    return view('worker.reports');
                }
                public function settings(){
                    $workers = User::orderBy('created_at', 'desc')->where('role', 'worker')->get();
                    $user_data = User::orderBy('created_at', 'desc')->where('id', Auth::id())->first();
                    if(!Empty($user_data->images)){
                        $allFiles['files'] = json_decode($user_data->images);
                        $allFiles['id'] = Auth::id();

                    }else{
                        $allFiles['files'] = [];
                        $allFiles['id'] = '';
                    }
                    return view('worker.settings')->with(compact('user_data','workers','allFiles'));
                }
    public function TaskManagement(){
       // $task_data = TaskModel::whereJsonContains('workers', [(string)Auth::id()])->get();




       $task_data = TaskModel::with('chats')->orderBy('created_at' , 'desc')->whereJsonContains('workers', [(string)Auth::id()])
       ->where(function($query) {
           $query->where('status', 'Approved')
                 ->orWhere('status', 'Completed')
                 ->orWhere('status', 'Expired')
                 ->orWhere('status', 'Active');
       })
       ->get();
    //    dd($task_data);

           //    dd(count($task_data));
              // total tasks
              $task_data->each(function ($workers) {
               $workers->users = $workers->users();
               // dd($workers->users);
           });
        return view('worker.Taskmanagement')->with(compact('task_data'));
    }
    public function taskView($id){
        $group_data = Group::whereJsonContains('group_members', (string)Auth::id())->get();
        $group_data->each(function ($group) {
            $group->users = $group->users();
            // dd($group->users);
        });

        $Task = TaskModel::where('id' , $id)->get();

        if (!empty($Task)) {
            foreach ($Task as $k => $d) {
                if(!empty($d->workers)){
                    $Task[$k]['members']=User::whereIn('id', array_map('intval', json_decode($d->workers)))->get();
                    $Task[$k]['online']=User::whereIn('id', array_map('intval', json_decode($d->workers)))
                    ->orwhere('role' , 'superadmin')
                    ->orWhere('role', 'sitemanager')
                    ->where('status' , 1)
                    ->get();
                }else{
                    $Task[$k]['members'] = [];
                }
            }
        }
        $count_online = count($Task[$k]['online']);


          if(!empty($Task[0]->images)){
            $allFiles['files'] = json_decode($Task[0]->images);
            $allFiles['id'] = $Task[0]->id;

        }else{
            $allFiles['files'] = [];
            $allFiles['id'] = '';
        }

        $task_status = TaskStatus::select('tasklist_id','status')->where(['task_id'=>$id,'worker_id'=>Auth::user()->id])->get()->toArray();
        $task_list = Tasklist::whereIn('id' , json_decode($Task[0]['task_abbreviation'],true))->get();

        return view('worker.taskView')->with(compact('Task','count_online','allFiles','group_data','task_status','task_list'));
        }




        public function user_view(){
            return view('worker.user-view');
        }
        public function user(){
            return view('worker.user');
        }
        public function workgroups(){
            return view('worker.workGroups');
        }

        public function task_complete(Request $request){
            $task_data = TaskModel::find($request->task_id);
            // print_r($task_data); die;
            $task_data->update(['status' => $request->status]);
            return response()->json(['success' => 'Task Completed Successfully']);
        }

    public function update_setting(Request $request){
        $user_details = User::find($request->user_id);
        $imageName = '';
        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $imageName = $image->getClientOriginalName();
            $image->storeAs('/uploads', $imageName);
        }
        else{
            $imageName = $user_details['image'];
        }
        $form_data = $request->except('image');
        $form_data['image'] = $imageName;
        $user_details->update($form_data);
        return back()->with('success', 'details updated successfully');

    }
    // update password work
public function updatePassword(Request $request){
    // dd($request->all());
    $user_data = User::find(Auth::id());
    $password_verify = password_verify($request->CurrentPassword, $user_data->password);

    if($password_verify){
        if($request['NewPassword'] == $request['ConfirmPassword']){
            $new_pass = Hash::make($request['NewPassword']);
            User::where('id', Auth::id())->first()->update(['password' => $new_pass]);
            return back()->with('success' , 'Password updated Successfully');
        }else{
            return back()->with('error', 'Password Does not match');
        }
    }else{
        return back()->with('error' , 'Invalid Password');
    }
}

 // document delete function
 public function delete_task_doc(Request $request){
    $task_data = TaskModel::find($request->doc_id);
    $task_docs = json_decode($task_data->images, true);
    $pos = array_search($request->doc_name, $task_docs);
    if ($pos !== false) {
        echo "Position found: " . $pos;
        array_splice($task_docs, $pos, 1);
        $task_data->update(['images' => json_encode($task_docs)]);
        return back()->with('success', 'Document deleted Successfully');

    }else{
        return back()->with('error', 'Document not found');
    }
}
 public function delete_user_doc(Request $request){
    // dd($request->all());
    $user_data = User::find($request->doc_id);
    $user_docs = json_decode($user_data->images, true);
    // dd($user_data);
    $pos = array_search($request->doc_name, $user_docs);
    if ($pos !== false) {
        echo "Position found: " . $pos;
        array_splice($user_docs, $pos, 1);
        $user_data->update(['images' => json_encode($user_docs)]);
        return back()->with('success', 'Document deleted Successfully');

    }else{
        return back()->with('error', 'Document not found');
    }
}


    // update Tasks documents

    public function update_documents_task(Request $request)
    {
        // dd($request->all());
        $task_data = TaskModel::find($request['task_id']);
        $allFiles = [];

        if ($request->hasFile('images')) {
            foreach ($request->file('images') as $file) {
                $imageName = $file->getClientOriginalName();
                $file->storeAs('uploads', $imageName);
                $allFiles[] = $imageName;
            }
            $db_files = json_decode($task_data->images);
            $updated_files = array_merge($db_files, $allFiles);
        } else {
            $db_files = json_decode($task_data->images);
            if ($db_files && is_array($db_files)) {
                $updated_files = $db_files;
            }
        }

        $db_files = json_encode($updated_files);
        // dd($db_files);
        $task_data->update(['images' => $db_files]);

        return back()->with('success', 'Documents updated Successfully');
    }



     // update user documents
     public function update_documents_user(Request $request)
     {
         $user_data = User::find($request['user_id']);
         $allFiles = [];

        //  dd($request->all());
         if ($request->hasFile('images')) {
             foreach ($request->file('images') as $file) {
                 $imageName = $file->getClientOriginalName();
                 $file->storeAs('uploads', $imageName);
                 $allFiles[] = $imageName;
             }if(!empty(json_decode($user_data->images))){

                 $db_files = json_decode($user_data->images);
                }else{
                    $db_files = [];
                }

             $updated_files = array_merge($db_files, $allFiles);
         } else {
             $db_files = json_decode($user_data->images);
             if ($db_files && is_array($db_files)) {
                 $updated_files = $db_files;
             }
         }

         // dd($updated_files);
         $db_files = json_encode($updated_files);
         $user_data->update(['images' => $db_files]);

         return back()->with('status', 'Documents updated Successfully');
     }

     // change task status to active

     public function task_active(Request $request){
        // print_r($request->all()); die;
        $task = TaskModel::find($request->id);
        // print_r($task); die;
        $task->update(['status' => $request->status]);
        return response()->json(['success'=> 'Task is active now']);
    }



   // chat working
   public function showchat(Request $request){

    $chats = Chat::where(function($query) use ($request) {
        $query->where('sender_Id', Auth::id())
              ->where('reciever_Id', $request->reciever_typed_id);
    })
    ->orWhere(function($query) use ($request) {
        $query->where('sender_Id', $request->reciever_typed_id)
              ->where('reciever_Id', Auth::id());
    })
    ->get();


    $user = User::where('id',$request->reciever_typed_id)->first();
    $view = view('includes.chat',compact('chats','user'))->render();
    return ['view' => $view];
}

// search memeber in chat

public function search_member(Request $request){
    // print_r($request->all()); die;
    $group_data = Group::where('id' , $request->roup_id)->get();
    $users = User::where('f_name' , 'LIKE' , '%'.$request->text.'%')->get();
    return response()->json($users);
}

public function sendMsg(Request $request){
    Chat::create([
        'sender_Id' => Auth::id(),
        'reciever_Id' => $request['reciever_id'],
        'msg' => $request['sender_msg']
    ]);
}

  // group chat working
  public function show_group_chat(Request $request){
    $chats = Chat::where('group_id',$request->group_id)->get();
    foreach($chats as $k => $chat){
        $chats[$k]['user_details'] = User::where('id' ,$chat->sender_Id)->first();
    }
    $view = view('includes.groupchat',compact('chats'))->render();
    return ['view' => $view];
}

public function send_grp_Msg(Request $request){
    Chat::create([
        'sender_Id' => Auth::id(),
        'reciever_Id' => $request['reciever_id'],
        'type' => 'groupChat',
        'group_id' => $request['reciever_id'],
        'msg' => $request['sender_msg']
    ]);
}

public function read_msg(Request $request){
    $change_status = Chat::where('reciever_Id', Auth::id())->where('sender_Id' , $request->read_id)->get();
    // print_r($change_status); die;
    foreach($change_status as $status){
        $status->update(['status' => 1]);
    }
    return response()->json(['success' => 'msg read']);

}

// counter function in sidebar

public function msg_counter(){
    $chat_data = Chat::where('status' , 0)->where('reciever_Id' , Auth::id())->get();
    // print_r($chat_data); die;
    return response()->json($chat_data);
}

public function task_msg_counter(){
    $chat_data = TaskModel::with('chats')->whereJsonContains('workers', [(string)Auth::id()])
    ->where(function($query) {
        $query->where('status', 'Approved')
              ->orWhere('status', 'Completed')
              ->orWhere('status', 'Expired')
              ->orWhere('status', 'Active');
    })
    ->get();
    foreach($chat_data as $k => $d) {
        $chat_data[$k]['chat'] = Chat::where('type', 'groupChat')
        ->where('group_id', $d->id)
        ->where('sender_id', '!=', Auth::id())
        ->where(function($query) {
            $userId = Auth::id();
            $query->whereNull('seen')
                ->orWhere(function($query) use ($userId) {
                    $query->whereNotNull('seen')
                            ->whereRaw('JSON_CONTAINS(seen, \'[' . $userId . ']\') = 0');
                });
        })
        ->get();
    }

    // print_r($chat_data[$k]['chat']); die;
    return response()->json($chat_data);
}

public function read_group_msg(Request $request){
    $userId = auth()->user()->id;
    $chatMessages = Chat::where('group_id', $request->read_id)->where('sender_Id' , '!=' , Auth::id())->get();
    foreach ($chatMessages as $message) {
        $seenArray = json_decode($message->seen, true);
        if (!is_array($seenArray)) {
            $seenArray = [];
        }
        if (!in_array($userId, $seenArray)) {
            $seenArray[] = $userId;
            $seen_json = json_encode($seenArray);

            $message->update(['seen' => json_encode($seenArray)]);
        }
    }
    return response()->json(['success' => 'msg read']);
}

public function get_tasks(Request $request)
{

    $all_tasks_count = TaskModel::orderBy('created_at' , 'desc')->whereJsonContains('workers', [(string)Auth::id()])
    ->where(function($query) {
        $query->where('status', 'Approved')
              ->orWhere('status', 'Completed')
              ->orWhere('status', 'Expired')
              ->orWhere('status', 'Active');
    })
    ->count();
    if($all_tasks_count > 0) {
        $all_tasks_count = TaskModel::with('chats')->orderBy('created_at' , 'desc')->whereJsonContains('workers', [(string)Auth::id()])
        ->where(function($query) {
            $query->where('status', 'Approved')
                  ->orWhere('status', 'Completed')
                  ->orWhere('status', 'Expired')
                  ->orWhere('status', 'Active');
        })
        ->get();
            $all_tasks_count->each(function ($workers, $count) {
                if($count == 2) {
                    $workers->check_status = 'false';
                    $workers->save();
                }
            $workers->users = $workers->users();
        });
        $active_tasks_count = TaskModel::orderBy('created_at' , 'desc')->whereJsonContains('workers', [(string)Auth::id()])->where('status', 'Active')->count();
        $expired_tasks_count = TaskModel::orderBy('created_at' , 'desc')->whereJsonContains('workers', [(string)Auth::id()])->where('status', 'Expired')->count();
        $tasks = view('includes.tasks',compact('all_tasks_count'))->render();
        return ['data' => $tasks,'active_tasks_count' => $active_tasks_count,'expired_tasks_count' => $expired_tasks_count];
    }
}

}
