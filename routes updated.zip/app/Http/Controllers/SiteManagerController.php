<?php

namespace App\Http\Controllers;

use App\Models\Chat;
use App\Models\TaskModel;
use App\Models\User;
use App\Models\Tasklist;
use App\Models\TaskStatus;
use App\Models\Group;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;


use Illuminate\Http\Request;
use Laravel\Ui\Presets\React;

class SiteManagerController extends Controller
{
    public function index(){

        $workers = User::orderBy('created_at', 'desc')->where('role', 'worker')->get();
        $grp_manager = User::orderBy('created_at', 'desc')->where('role', 'groupmanager')->get();

        $all_tasks_count = TaskModel::orderBy('created_at', 'desc')->get();
        $all_tasks_count->each(function ($workers) {
            $workers->users = $workers->users();
            // dd($workers->users);
        });
        // dd($all_tasks_count);

        $tasks_submitted = TaskModel::orderBy('created_at', 'desc')->where('status' , 'Submitted')->get();
        $tasks_submitted->each(function ($workers) {
            $workers->users = $workers->users();
            // dd($workers->users);
        });

        $tasks_approved = TaskModel::orderBy('created_at', 'desc')->where('status' , 'Approved')->get();
        $tasks_approved->each(function ($workers) {
            $workers->users = $workers->users();
            // dd($workers->users);
        });
        // dd($tasks_approved);
        // dd($tasks_approved);
        $tasks_active = TaskModel::orderBy('created_at', 'desc')->where('status' , 'Active')->get();
        $tasks_active->each(function ($workers) {
            $workers->users = $workers->users();
            // dd($workers->users);
        });
        $tasks_expired = TaskModel::orderBy('created_at', 'desc')->where('status' , 'Expired')->get();
        $tasks_expired->each(function ($workers) {
            $workers->users = $workers->users();
            // dd($workers->users);
        });
        $all_tasks = Tasklist::all()->pluck('task_abbreviation');
        return view('sitemanager.index')->with(compact('workers','grp_manager', 'all_tasks','all_tasks_count','tasks_submitted','tasks_approved', 'tasks_active','tasks_expired'));
    }

    public function Chat(){
        $workers = User::orderBy('created_at', 'desc')->where('role', 'worker')->get();
        $all_tasks = Tasklist::all()->pluck('task_abbreviation');
        $grp_manager = User::orderBy('created_at', 'desc')->where('role', 'groupmanager')->get();

        $all_members = User::with('chats')->where('role', '!=' , 'sitemanager')->get();
        // dd($all_members);
        return view('sitemanager.chat')->with(compact('all_tasks','workers','grp_manager','all_members'));
    }
    public function group_view(){
        $workers = User::orderBy('created_at', 'desc')->where('role', 'worker')->get();
        $all_tasks = Tasklist::all()->pluck('task_abbreviation');
        $grp_manager = User::orderBy('created_at', 'desc')->where('role', 'groupmanager')->get();
        return view('sitemanager.group-view')->with(compact('workers','all_tasks','grp_manager'));
    }
    public function invoices(){
        $workers = User::orderBy('created_at', 'desc')->where('role', 'worker')->get();
        $all_tasks = Tasklist::all()->pluck('task_abbreviation');
        $grp_manager = User::orderBy('created_at', 'desc')->where('role', 'groupmanager')->get();
        return view('sitemanager.invoices')->with(compact('workers','all_tasks','grp_manager'));
    }
    public function reports(){
        $workers = User::orderBy('created_at', 'desc')->where('role', 'worker')->get();
        $all_tasks = Tasklist::all()->pluck('task_abbreviation');
        $grp_manager = User::orderBy('created_at', 'desc')->where('role', 'groupmanager')->get();
        return view('sitemanager.reports')->with(compact('workers','all_tasks','grp_manager'));
    }
    public function settings(){
        $user_data = User::orderBy('created_at', 'desc')->where('id', Auth::id())->first();
        $workers = User::orderBy('created_at', 'desc')->where('role', 'worker')->get();
        $all_employees = User::orderBy('created_at', 'desc')->where('role', '!=' , 'superadmin')->get();
        $grp_manager = User::orderBy('created_at', 'desc')->where('role', 'groupmanager')->get();
        $tasks = Tasklist::orderBy('created_at' , 'desc')->get();
        $all_tasks = Tasklist::all()->pluck('task_abbreviation');
        return view('sitemanager.settings')->with(compact('workers','grp_manager','user_data', 'all_employees','tasks','all_tasks'));
    }

    public function TaskManagement(){
        $tasks = TaskModel::with('chats')->orderBy('created_at' , 'desc')->get();
        // dd($tasks);

        $tasks->each(function ($workers) {
            $workers->users = $workers->users();
            // dd($workers->users);
        });
        $all_workers_id = [];
        $grp_manager = User::orderBy('created_at', 'desc')->where('role', 'groupmanager')->get();
        // for workers in footer task management modal dropdown
        $workers = User::orderBy('created_at', 'desc')->where('role', 'worker')->get();
        $all_tasks = Tasklist::all()->pluck('task_abbreviation');

        return view('sitemanager.Taskmanagement')->with(compact('workers','tasks','all_tasks','grp_manager'));
    }
    public function user_view(){
        return view('sitemanager.user-view');
    }
    // public function user(){
        //     $all_tasks = Tasklist::all()->pluck('task_abbreviation');
        //     $workers = User::orderBy('created_at', 'desc')->where('role', 'worker')->get();
        //     $grp_manager = User::orderBy('created_at', 'desc')->where('role', 'groupmanager')->get();
        //     return view('sitemanager.user')->with(compact('workers','all_tasks', 'grp_manager'));
        // }
        public function workgroups(){
            // all workers data for task modal
            $workers = User::orderBy('created_at', 'desc')->where('role', 'worker')->get();

            // task_abbreviation data for task modal
            $all_tasks = Tasklist::all()->pluck('task_abbreviation');


            // retrieve all group managers which are not in group
            $group_managers = Group::pluck('group_manager')->map(function ($item) {
                return json_decode($item, true);
            })->flatten()->unique()->values()->toArray();
        $grp_manager = User::whereNotIn('id', $group_managers)
        ->where('role', 'groupmanager')
        ->get();

        // json ids for group members
        $group_members = [];
        $all_group = Group::orderBy('created_at', 'desc')->get();
        foreach($all_group as $k => $d){
            if(!empty($d->group_members)){
                $all_group[$k]['users'] = User::whereIn('id', array_map('intval', json_decode($d->group_members)))->get();
            }else{
                $all_group[$k]['users'] = [];
            }
        }

        // dd($all_group[$k]['users']);

        return view('sitemanager.workGroups')->with(compact('workers','all_tasks', 'grp_manager','all_group'));
    }


    function mark_as_complete(Request $request){
        $data = ['worker_id'=>Auth::user()->id,'tasklist_id'=>$request->task_list_id,'task_id'=>$request->task_id];
        $check = TaskStatus::where($data)->get();
        if(!$check->isEmpty()){
            TaskStatus::where($data)->update(['status'=>$request->status]);
        }else{
            $data['status'] = $request['status'];
            TaskStatus::create($data);
        }
    }


    function changeTaskStatus(Request $request){

        TaskModel::where('id',$request['task_id'])->update(["status"=>$request['status'],"check_status"=>true]);
        return with('success', 'Group successfully updated');
    }

    public function groupView($id){
        // all workers data for task modal
        $workers = User::orderBy('created_at', 'desc')->where('role', 'worker')->get();

        $grp_manager = User::orderBy('created_at', 'desc')->where('role', 'groupmanager')->get();
        // task_abbreviation data for task modal
        $all_tasks = Tasklist::all()->pluck('task_abbreviation');

        $group_data = Group::where('id', $id)->get();
        // dd($group_data);

        if (!empty($group_data)) {
            foreach ($group_data as $k => $d) {
                if(!empty($d->group_members)){
                    $group_data[$k]['members']=User::whereIn('id', array_map('intval', json_decode($d->group_members)))->get();
                    $group_data[$k]['other_members']=User::whereNotIn('id', array_map('intval', json_decode($d->group_members)))->where('role', 'worker')->get();
                }else{
                    $group_data[$k]['members'] = [];
                }
            }
        }
        if (!empty($group_data)) {
            foreach ($group_data as $k => $d) {
                if(!empty($d->group_manager)){
                    $group_data[$k]['managers']=User::whereIn('id', array_map('intval', json_decode($d->group_manager)))->get();
                }else{
                    $group_data[$k]['managers'] = [];
                }
            }
        }

        $group_managers = Group::all()->pluck('group_manager');

        $group_managers = $group_managers->filter(function($manager) {
            return !empty($manager);
        });

        $manager_ids = $group_managers->map(function($manager) {
            return json_decode($manager);
        })->flatten()->unique()->toArray();

        $group_managers = User::whereNotIn('id', $manager_ids)
                            ->where('role', 'groupmanager')
                            ->get();
        // dd($group_data[$k]['managers']);


        return view('sitemanager.group-view')->with(compact('workers','all_tasks','grp_manager','group_managers','group_data'));
    }



    public function group_info_update(Request $request){
        $group_data = Group::find($request->group_id);
        $inserted_data = $request->except('group_id');
        // dd($inserted_data);
        $group_data->update($inserted_data);
        return back()->with('success', 'Group successfully updated');
    }


    // search memeber in chat

    public function search_member(Request $request){
        // print_r($request->all()); die;
        $users = User::where('f_name' , 'LIKE' , '%'.$request->text.'%')->get();
        return response()->json($users);
    }

    // workers update in the group

    public function update_group_workers(Request $request)
    {
        $group = Group::find($request->group_id);
        $existing_members = json_decode($group->group_members, true) ?? [];

        $selected_members = $request->group_members ?? [];
        $deselected_members = $request->deselected_workers ?? [];

        foreach ($deselected_members as $deselected_member) {
            $index = array_search($deselected_member, $existing_members);
            if ($index !== false) {
                unset($existing_members[$index]);
            }
        }

        $merged_members = array_unique(array_merge($existing_members, $selected_members));

        $group->group_members = json_encode($merged_members);
        // print_r($group->group_members); die;

        $group->save();

        return back()->with('success', 'Group Members changed successfully');
    }


    public function Edit_task(Request $request)
    {
        $task_id = $request->task_id;
        $task_data = TaskModel::where('id' , $task_id)->get();
        $all_tasks = [];
        if(!empty($task_data[0]['task_abbreviation'])){
            $all_tasks = Tasklist::whereIn('id' , json_decode($task_data[0]['task_abbreviation'],true))->get();
        }

        if($all_tasks){
            $all_tasks = Tasklist::whereIn('id' , json_decode($task_data[0]['task_abbreviation']))->get();
        }else{
            $all_tasks = [];
        }
        $task_workers = User::where('role','worker')->whereIn('id' , json_decode($task_data[0]['workers'],true))->get();
        if (!empty($task_data)) {
            foreach ($task_data as $k => $d) {
                if(!empty($d->workers)){
                    $task_data[$k]['members']=User::whereIn('id', array_map('intval', json_decode($d->workers)))->get();
                }else{
                    $task_data[$k]['members'] = [];
                }
            }
            $view =  view('includes.siteedit_task',compact('task_data','all_tasks','task_workers'))->render();
        }

        return $view;
        //  response()->json($task_data);
    }

    public function Update_task(Request $request){
        // dd($request->all());
        $task_data = TaskModel::find($request->task_id);
        // $post_data = $request->except('images');
        $task_images = [];
        if($request->hasFile('images')){
            foreach($request->file('images') as $image){
                $file_name = $image->getClientOriginalName();
                $image->storeAs('/uploads', $file_name);
                $task_images[] = $file_name;
            }
        }
        $post_data = $request->except('images');
        $post_data['grp_creator_id'] = Auth::id();
        $workers = $request['workers'];
        $task_abbreviation = (!empty($request['task_abbreviation'])) ? $request['task_abbreviation'] : [];
        $post_data['task_id'] = rand(10,1000);
        $post_data['images'] =  json_encode($task_images);
        $post_data['workers'] = json_encode($workers);
        $post_data['task_abbreviation'] = json_encode($task_abbreviation);
        $task_data->update($post_data);
        return back()->with('success', 'Task updated Successfully');

    }

    public function create_group(Request $request){
        $request['grp_creator_id'] = Auth::id();
        $group_data = $request->except(['group_members','group_manager']);
        $group_data['group_manager'] = json_encode($request['group_manager']);
        $group_data['group_members'] = $request['group_members'] ? json_encode($request['group_members']) : '';
        Group::create($group_data);
        return back()->with('status' , 'Group created Successfully');
    }


     //task create
     public function create_task(Request $request){

        $task_images = [];
        if($request->hasFile('images')){
            foreach($request->file('images') as $image){
                $file_name = $image->getClientOriginalName();
                $image->storeAs('/uploads', $file_name);
                $task_images[] = $file_name;
            }
        }

        $post_data = $request->except('images');
        $post_data['task_id'] = rand(10,1000);
        $post_data['grp_creator_id'] = Auth::id();
        $workers = $request['workers'];
        $task_abbreviation = $request['task_abbreviation'];
        $post_data['images'] =  json_encode($task_images);
        $post_data['workers'] = json_encode($workers);
        $post_data['task_abbreviation'] = json_encode($task_abbreviation);
        TaskModel::create($post_data);
        return back()->with('success', 'Task Created Successfully');

    }

    // view task
    public function taskView($id){
        $grp_manager = User::orderBy('created_at', 'desc')->where('role', 'groupmanager')->get();
        $Task = TaskModel::where('id' , $id)->get();

        $task_workers = TaskModel::where('id', $id)->get();
        $task_workers->each(function ($task) {
            $task->users = $task->users();
            // dd($task->users);
        });

        if (!empty($Task)) {
            foreach ($Task as $k => $d) {
                if(!empty($d->workers)){
                    $Task[$k]['members']=User::whereIn('id', array_map('intval', json_decode($d->workers)))->get();
                    $Task[$k]['online']=User::whereIn('id', array_map('intval', json_decode($d->workers)))
                    ->orwhere('role' , 'superadmin')
                    ->orWhere('role', 'sitemanager')
                    ->where('status' , 1)
                    ->get();
                }else{
                    $Task[$k]['members'] = [];
                }
            }
        }
        $count_online = count($Task[$k]['online']);
        // dd($Task[0]->images);
        // dd($Task[$k]['members']);

        $workers = User::orderBy('created_at', 'desc')->where('role', 'worker')->get();
        $all_tasks = Tasklist::all()->pluck('task_abbreviation');
        $group_data = Group::all();
        $group_data->each(function ($group) {
            $group->users = $group->users();
            // dd($group->users);
        });

        if(!empty($Task[0]->images)){
            $allFiles['files'] = json_decode($Task[0]->images);
            $allFiles['id'] = $Task[0]->id;

        }else{
            $allFiles['files'] = [];
            $allFiles['id'] = '';
        }

        // if(!is_null($Task[0]['task_abbreviation'])){
        // }else{
        //     $task_list = null;
        // }
        $task_list=[];
        if(!empty($Task[0]['task_abbreviation'])){
            $task_list = Tasklist::orderBy('id', 'desc')->whereIn('id' , json_decode($Task[0]['task_abbreviation'],true))->get();
            // dd($task_list);
        }

        // var_dump(json_decode($Task[0]['task_abbreviation'],true)); die;
        $task_status = TaskStatus::orderBy('tasklist_id', 'desc')->select('tasklist_id','status')->where(['task_id'=>$id,'worker_id'=>$task_workers[0]->grp_creator_id])->get()->toArray();
        // dd($task_status);

        // dd($allFiles['files']);
        return view('sitemanager.taskView')->with(compact('workers','count_online','Task','task_status','grp_manager','allFiles','task_list','all_tasks','group_data','task_workers'));
    }

    // data extend for task
    public function task_date_extend(Request $request){
        // print_r($request->all());
        $task_data = TaskModel::find($request->task_id);
        // print_r($task_data);
        return response()->json($task_data);
    }
    public function task_date_update(Request $request){
        $task_data = TaskModel::find($request->task_id);
        // dd($task_data);
        $start_end_date = $request->except('task_id');
        $task_data->update($start_end_date);
        // dd('date updated');
        return back()->with('status', 'Date Extended Successfully');
    }

    // retrieve users
    public function retrieve_user(){

        $users_data = User::orderBy('created_at', 'desc')->where('role','!=','superadmin')->get();
        $grp_manager = User::orderBy('created_at', 'desc')->where('role', 'groupmanager')->get();
        if (!empty($users_data)) {
            foreach ($users_data as $k => $d) {
                    $users_data[$k]['tasks']  =TaskModel::whereJsonContains('workers', (string)$d->id)->get()->count();

            }
        }
        // dd($users_data[$k]['tasks']);
        // dd($count_tasks);
        $all_tasks = Tasklist::all()->pluck('task_abbreviation');
        $workers = User::orderBy('created_at', 'desc')->where('role', 'worker')->get();
        return view('sitemanager.user')->with(compact('users_data','workers','all_tasks', 'grp_manager'));

    }

    public function task_complete(Request $request){
        $task_data = TaskModel::find($request->task_id);
        // print_r($task_data); die;
        $task_data->update(['status' => $request->status]);
        return response()->json(['success' => 'Task Completed Successfully']);
    }

    // role based retrieve users
    public function filter_user(Request $request){
        if($request->input('user_role') == 'all'){
            $users = User::where('role' , '!=' , 'superadmin')->get();
        }else{
            $role = $request->input('user_role');
            $users = User::where('role', $role)->get();
        }
        if (!empty($users)) {
            foreach ($users as $k => $d) {
                    $users[$k]['tasks']  = TaskModel::whereJsonContains('workers', (string)$d->id)->get()->count();
            }
        }
        return response()->json(['users' => $users , 'tasks' => $users[$k]['tasks']]);
    }

    // Add worker
    public function creat_worker(Request $request){
        // print_r($request->all()); die();

          $imageName = '';
          if ($request->hasFile('image')) {
              $image = $request->file('image');
              $imageName = $image->getClientOriginalName();
              $image->storeAs('/uploads', $imageName);
          }
          $worker_details = $request->except('image');
          $worker_details['image'] = $imageName;
        //   $worker_details['password'] = null;

          $rand_pass = Str::random(12);
        $worker_details['password'] = Hash::make($rand_pass);

        $suc = User::create($worker_details);
        if($suc) {
            $email = new Mailer;
            $data = [
                'name' => $request->f_name . ' ' . $request->l_name,
                'email' => $request->email,
                'pass' => $rand_pass,
                'role' => $request->role,
            ];
            $view = view('includes.emailtemp', compact('data'))->render();
            $email->email($request->email,'Account Creation at Remote Tracking System',$view);

            // $message = "Email: $request->email <br> <br> Password: $rand_pass <br> <br> Role $request->role";
            // $email->email($request->email,'Account Creation', $message);
        }

        // $userData = [
        //     'email' => $request['email'],
        //     'password' => $request['password']
        // ];
        //     $email = new Mailer();
        //     $email->email($request['email'],$userData);
        //     User::create($worker_details);
          return back()->with('success', 'User created Successfully');

        }


        // check email validation
        public function checkEmail(Request $request){
            // print_r($request->all()); die;
            $check_user = User::where('email',$request->email)->exists();
           return $check_user;
        }

    // update settings
    public function update_setting(Request $request){
        $user_details = User::find($request->user_id);
        $imageName = '';
        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $imageName = $image->getClientOriginalName();
            $image->storeAs('/uploads', $imageName);
        }
        else{
            $imageName = $user_details['image'];
        }
        $form_data = $request->except('image');
        $form_data['image'] = $imageName;
        $user_details->update($form_data);
        return back()->with('status', 'details updated successfully');

    }

     // update password work
     public function updatePassword(Request $request){
        $user_data = User::find(Auth::id());
        $password_verify = password_verify($request->CurrentPassword, $user_data->password);

        if($password_verify){
            if($request['NewPassword'] == $request['ConfirmPassword']){
                $new_pass = Hash::make($request['NewPassword']);
                User::where('id', Auth::id())->first()->update(['password' => $new_pass]);
                return back()->with('success' , 'Password updated Successfully');
            }else{
                return back()->with('error', 'Password Does not match');
            }
        }else{
            return back()->with('error' , 'Invalid Password');
        }
    }

     // update user documents
     public function update_documents_user(Request $request)
     {
         $user_data = User::find($request['user_id']);
         $allFiles = [];

        //  dd($request->all());
         if ($request->hasFile('images')) {
             foreach ($request->file('images') as $file) {
                 $imageName = $file->getClientOriginalName();
                 $file->storeAs('uploads', $imageName);
                 $allFiles[] = $imageName;
             }if(!empty(json_decode($user_data->images))){

                 $db_files = json_decode($user_data->images);
                }else{
                    $db_files = [];
                }

             $updated_files = array_merge($db_files, $allFiles);
         } else {
             $db_files = json_decode($user_data->images);
             if ($db_files && is_array($db_files)) {
                 $updated_files = $db_files;
             }
         }

         // dd($updated_files);
         $db_files = json_encode($updated_files);
         $user_data->update(['images' => $db_files]);

         return back()->with('status', 'Documents updated Successfully');
     }

    public function EditEmployee($id){
        $workers = User::orderBy('created_at', 'desc')->where('role', 'worker')->get();
        $user_data = '';
        $user_data =  User::find($id);
        $all_tasks = Tasklist::all()->pluck('task_abbreviation');
        if($user_data === null){
            $user_data = 'No data Available';
        }else{
            $user_data;
        }
        $documents = [];
        $grp_manager = User::orderBy('created_at', 'desc')->where('role', 'groupmanager')->get();
        if(!empty($user_data->images)){
            $allFiles['files'] = json_decode($user_data->images);
            $allFiles['id'] = $user_data->id;

        }else{
            $allFiles['files'] = [];
            $allFiles['id'] = '';
        }
        // dd($allFiles);
        // $all_tasks = Tasklist::all()->pluck('task_abbreviation');
        return view('sitemanager.user-view')->with(compact('user_data','grp_manager', 'workers','allFiles','all_tasks'));
    }

    public function delete_user_doc(Request $request){
        $task_data = User::find($request->doc_id);
        $task_docs = json_decode($task_data->images, true);
        $pos = array_search($request->doc_name, $task_docs);
        if ($pos !== false) {
            echo "Position found: " . $pos;
            array_splice($task_docs, $pos, 1);
            $task_data->update(['images' => json_encode($task_docs)]);
            return back()->with('success', 'Document deleted Successfully');
        } else {
            return back()->with('error', 'Document not found');
        }
    }


    public function delete_user(Request $request){

        $group = Group::find($request->group_id);
        $existing_members = json_decode($group->group_members, true) ?? [];
        // dd($existing_members);

        $del_user_id = $request->del_user_id ?? [];

        $index = array_search($del_user_id, $existing_members);
        if ($index !== false) {
            unset($existing_members[$index]);
            $existing_members = array_values($existing_members);
        } else {
            return back()->with('status', 'User not found in the group');
        }

        $group->group_members = json_encode($existing_members);
        $group->save();


        return back()->with('status', 'Employee Deleted Succssfully');

    }

        // delete manager
        public function delete_manager(Request $request){
            // dd($request->all());
            $group = Group::find($request->group_id);
            $existing_members = json_decode($group->group_manager, true) ?? [];
            // dd($existing_members);

            $del_user_id = $request->del_manager_id ?? [];

            $index = array_search($del_user_id, $existing_members);
            if ($index !== false) {
                unset($existing_members[$index]);
                $existing_members = array_values($existing_members);
            } else {
                return back()->with('status', 'User not found in the group');
            }

            $group->group_manager = json_encode($existing_members);
            $group->save();


            return back()->with('status', 'Employee Deleted Succssfully');

        }

 // group managers
 public function update_group_managers(Request $request)
 {

     $group = Group::find($request->group_id);
     $existing_members = json_decode($group->group_manager, true) ?? [];

     $selected_members = $request->group_managers ?? [];


     $merged_members = array_unique(array_merge($existing_members, $selected_members));

     $group->group_manager = json_encode($merged_members);
     // print_r(json_encode($merged_members)); die();
     // print_r($group->group_members); die;

     $group->save();

     return back()->with('success', 'Group Members changed successfully');
 }


    public function UpdateEmployee(Request $request){
        $user_data = User::find($request->user_id);
        $imageName = '';
        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $imageName = $image->getClientOriginalName();
            $image->storeAs('/uploads', $imageName);
        }
        else{
            $imageName = $user_data['image'];
        }
        $employee_details = $request->except('image');
        $employee_details['image'] = $imageName;
        $user_data->update($employee_details);
        return back()->with('status', 'Employee Successfully Updated');


    }

      // create task list

      public function addTaskList(Request $request){
        Tasklist::create($request->all());
        return back()->with('status', 'Task list created successfully');
    }

     // Task list edit
     public function taskListEdit(Request $request){
        $taskListData = Tasklist::find($request->TaskListId);
        return response()->json($taskListData);
    }

    // update task list
    public function TaskListUpdate(Request $request){
        $TaskListData = Tasklist::find($request->id);
        if ($TaskListData) {
            $TaskListData->update($request->all());
            return back()->with('status', 'Task Updated Successfully');
        } else {
            return back()->with('error','Task not found');
        }
    }

     // document delete function
     public function delete_task_doc(Request $request){
        $task_data = TaskModel::find($request->doc_id);
        $task_docs = json_decode($task_data->images, true);
        $pos = array_search($request->doc_name, $task_docs);
        if ($pos !== false) {
            echo "Position found: " . $pos;
            array_splice($task_docs, $pos, 1);
            $task_data->update(['images' => json_encode($task_docs)]);
            return back()->with('success', 'Document deleted Successfully');

        }else{
            return back()->with('error ', 'Document not found');
        }
    }

    public function edit_group(Request $request){
        $group_data = Group::find($request->group_id);
       $workers = User::where('role' , 'worker')->get();
        $group_managers = User::where('role' , 'groupmanager')->get();
        return response()->json(['group_data' => $group_data, 'worker' => $workers, 'group_managers' => $group_managers]);
    }

    public function del_group(Request $request){
        $group_data = Group::find($request->del_group_id);
        if(!is_null($group_data)){
            $group_data->delete();
            return back()->with('success', 'Group Successfully deleted');
        }else{
            return back()->with('error', 'Group not found');

        }
    }

    function update_group(Request $request){

        $group_data = Group::find($request->group_id);
        $update_group = $request->except('group_id');
        $existing_workers = json_decode($group_data->group_members, true) ?? [];
        $new_members = $request->group_members ?? [];
        $merged_members = array_unique(array_merge($existing_workers, $new_members));
        $update_group['group_members'] = $merged_members;
        $group_data->group_members = json_encode($merged_members);
        $group_data->update($update_group);
        return back()->with('success', 'Group Successfully updated');

    }

    public function delete_task(Request $request){
        $task_data = TaskModel::find($request->task_id);
        if(!is_null($task_data)){
            $task_data->delete();
            return back()->with('status', 'Task Deleted Succssfully');
        }else{
            return back()->with('status', 'Task not found');
        }

    }
    // public function delete_worker(Request $request){
    //     $worker_data = User::find($request->worker_id);
    //     print_r($worker_data);
    //     if(!is_null($worker_data)){
    //         $worker_data->delete();
    //         return back()->with('status', 'Employee Deleted Succssfully');
    //     }else{
    //         return back()->with('status', 'Employee not found');
    //     }

    // }

    public function delete_worker(Request $request){
        $worker_data = User::find($request->worker_id);

        if(!is_null($worker_data)){
            $groups = Group::all();
            if(!is_null($groups)){
            foreach($groups as $group) {
                $group_manager = json_decode($group->group_manager, true);
                $group_members = json_decode($group->group_members, true);
                if(!is_null($group_manager)){

                    if(($key = array_search($request->worker_id, $group_manager)) !== false) {
                        unset($group_manager[$key]);
                        $group->group_manager = json_encode(array_values($group_manager));
                    }
                }

                if(!is_null($group_members)){
                    if(($key = array_search($request->worker_id, $group_members)) !== false) {
                        unset($group_members[$key]);
                    }

                    $group->group_members = json_encode(array_values($group_members));
                }
                $group->save();

            }
        }

            $worker_data->delete();

            return back()->with('success', 'Employee Deleted Successfully');
        } else {
            return back()->with('error', 'Employee not found');
        }
    }


    public function del_task_list(Request $request){
        $task_list = Tasklist::find($request->task_list);
        if(!is_null($task_list)){
            $task_list->delete();
            return back()->with('status', 'Task Deleted Succssfully');
        }else{
            return back()->with('status', 'Task not found');
        }
    }

    function updateStatus(Request $request){
        $task_data = TaskModel::find($request->task_id);
        $task_data->update(['status' => $request->status, "check_status" => 'true']);
        return response()->json(['success' => 'Status updated successfully', "check_status" => 'true']);
    }

    public function update_documents_task(Request $request)
    {
        // dd($request->all());
        $task_data = TaskModel::find($request['task_id']);
        $allFiles = [];

        if ($request->hasFile('images')) {
            foreach ($request->file('images') as $file) {
                $imageName = $file->getClientOriginalName();
                $file->storeAs('uploads', $imageName);
                $allFiles[] = $imageName;
            }
            $db_files = json_decode($task_data->images);
            $updated_files = array_merge($db_files, $allFiles);
        } else {
            $db_files = json_decode($task_data->images);
            if ($db_files && is_array($db_files)) {
                $updated_files = $db_files;
            }
        }

        $db_files = json_encode($updated_files);
        // dd($db_files);
        $task_data->update(['images' => $db_files]);

        return back()->with('success', 'Documents updated Successfully');
    }

    // chat working
    public function showchat(Request $request){

        $chats = Chat::where(function($query) use ($request) {
            $query->where('sender_Id', Auth::id())
                  ->where('reciever_Id', $request->reciever_typed_id);
        })
        ->orWhere(function($query) use ($request) {
            $query->where('sender_Id', $request->reciever_typed_id)
                  ->where('reciever_Id', Auth::id());
        })
        ->get();


        $user = User::where('id',$request->reciever_typed_id)->first();
        $view = view('includes.chat',compact('chats','user'))->render();
        return ['view' => $view];
    }

    public function sendMsg(Request $request){
        Chat::create([
            'sender_Id' => Auth::id(),
            'reciever_Id' => $request['reciever_id'],
            'msg' => $request['sender_msg']
        ]);
    }


    // group chat working
    public function show_group_chat(Request $request){
    // print_r($request->all()); die;
    $chats = Chat::where('group_id',$request->group_id)->get();
    foreach($chats as $k => $chat){
        $chats[$k]['user_details'] = User::where('id' ,$chat->sender_Id)->first();
    }
    $view = view('includes.groupchat',compact('chats'))->render();
    return ['view' => $view];
}

public function send_grp_Msg(Request $request){
    Chat::create([
        'sender_Id' => Auth::id(),
        'reciever_Id' => $request['reciever_id'],
        'type' => 'groupChat',
        'group_id' => $request['reciever_id'],
        'msg' => $request['sender_msg']
    ]);
}

public function task_active(Request $request){
    // print_r($request->all()); die;
    $task = TaskModel::find($request->id);
    // print_r($task); die;
    $task->update(['status' => $request->status]);
    return response()->json(['success' => 'Task is active now']);
}


public function task_expired(Request $request){
    $task = TaskModel::find($request->id);
    $task->update(['status' => $request->status]);
    return response()->json('success', 'Task is Epired now');
}


public function read_msg(Request $request){
    $change_status = Chat::where('reciever_Id', Auth::id())->where('sender_Id' , $request->read_id)->get();
    // print_r($change_status); die;
    foreach($change_status as $status){
        $status->update(['status' => 1]);
    }
    return response()->json(['success' => 'msg read']);

}
public function read_group_msg(Request $request){
    $userId = auth()->user()->id;

    $chatMessages = Chat::where('group_id', $request->read_id)->where('sender_Id' , '!=' , Auth::id())->get();
    foreach ($chatMessages as $message) {
        $seenArray = json_decode($message->seen, true);
        if (!is_array($seenArray)) {
            $seenArray = [];
        }
        if (!in_array($userId, $seenArray)) {
            $seenArray[] = $userId;
            $seen_json = json_encode($seenArray);

            $message->update(['seen' => json_encode($seenArray)]);
        }
    }
    return response()->json(['success' => 'msg read']);
}



// counter function in sidebar

public function msg_counter(){
    $chat_data = Chat::where('status' , 0)->where('reciever_Id' , Auth::id())->get();
    // print_r($chat_data); die;
    return response()->json($chat_data);
}

public function task_msg_counter(){
    $chat_data = Chat::where('status', 0)
        ->where('type', 'groupChat')
        ->where('sender_id', '!=', Auth::id())
        ->where(function($query) {
            $userId = Auth::id();
            $query->whereNull('seen')
                    ->orWhere(function($query) use ($userId) {
                        $query->whereNotNull('seen')
                            ->whereRaw('JSON_CONTAINS(seen, \'[' . $userId . ']\') = 0');
                    });
        })
        ->get();
    // print_r($chat_data); die;
    return response()->json($chat_data);
}


// assigned workers in task

public function assignedWorkers(Request $request){
    $task_data = TaskModel::find($request->task_id);
    $workers = User::whereIn('id',array_map('intval', json_decode($task_data->workers)))->get();
    $managers = User::where('id',$task_data->grp_creator_id)->get();
    // print_r($workers); die;
    return response()->json(['workers' => $workers , 'managers' => $managers]);
}

public function get_tasks(Request $request)
{

    $all_tasks_count = TaskModel::orderBy('created_at', 'desc')->where('check_status' , 'true')->count();

    if($all_tasks_count > 0) {
        $all_tasks_count = TaskModel::with('chats')->orderBy('created_at', 'desc')->get();
        $tasks_submitted = TaskModel::orderBy('created_at' , 'desc')->where('status' , 'Submitted')->count();
        $tasks_approved = TaskModel::orderBy('created_at' , 'desc')->where('status' , 'Approved')->count();
        $tasks_active = TaskModel::orderBy('created_at' , 'desc')->where('status' , 'Active')->count();
        $tasks_expired = TaskModel::orderBy('created_at' , 'desc')->where('status' , 'Expired')->count();
        $all_tasks_count->each(function ($workers,$count) {

                $workers->check_status = 'false';
                $workers->save();

            $workers->users = $workers->users();
        });
        $tasks = view('includes.tasks',compact('all_tasks_count'))->render();
        return ['data' => $tasks, 'tasks_submitted' => $tasks_submitted, 'tasks_approved' => $tasks_approved , 'tasks_active' => $tasks_active , 'tasks_expired' => $tasks_expired];
    }
}


}
