<?php

namespace App\Http\Controllers;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

use Illuminate\Http\Request;

class Mailer extends Controller
{
    public function email($email = null,$subject = null,$body = null){
        require base_path("vendor/autoload.php");
        $mail = new PHPMailer(true);
        try {
            // Email server settings
            $mail->SMTPDebug = 0;
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';//'mail.jetnetixsolutions.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'rts.remote.access@gmail.com';
            $mail->Password = 'AZrtsrtsAppPW';
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
            $mail->Port = 465;
            $mail->setFrom('rts.remote.access@gmail.com', 'Remote Tracking System');
            $mail->addReplyTo('rts.remote.access@gmail.com', 'Remote Tracking System');
            $mail->addAddress($email);
            $mail->isHTML(true);
            // $mail->addCC($request->emailCc);
            // $mail->addBCC($request->emailBcc);
            $mail->Subject = $subject;
            $mail->Body   = $body;
            if( !$mail->send() ) {
                return back()->with("failed", "Email not sent.")->withErrors($mail->ErrorInfo);
            }
            else {
                return back()->with("success", "Email has been sent.");
            }
        } catch (Exception $e) {
             return back()->with('error','Message could not be sent.');
        }
    }
}
