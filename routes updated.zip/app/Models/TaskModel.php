<?php

namespace App\Models;
use Illuminate\Support\Facades\Auth;


use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TaskModel extends Model
{
    public function workers()
    {
        return $this->hasMany(User::class, 'id', 'workers');
    }
    protected $guarded = [];
    protected $table = 'task';

    public function users()
    {
        $ids = json_decode($this->workers);
        $members = [];
        if(!empty($ids)){

            foreach($ids as $id) {
                $members[] = User::where('id',$id)->first();
            }
        }else{
            $members = [];
        }
        return $members;
    }


    public function chats()
    {
        $userId = Auth::id();

        return $this->hasMany(Chat::class, 'group_id')
                    ->where('sender_id', '!=', $userId)
                    ->where(function($query) use ($userId) {
                        $query->whereNull('seen') // Handle the case where seen is null
                              ->orWhere(function($query) use ($userId) {
                                  $query->whereNotNull('seen')
                                        ->whereRaw('JSON_CONTAINS(seen, \'[' . $userId . ']\') = 0');
                              });
                    });
    }

}
