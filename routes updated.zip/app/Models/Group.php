<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Group extends Model
{
    public function user()
{
   return $this->hasOne(User::class, 'grp_creator_id', 'id');
}
    protected $guarded = [];
    protected $table = 'group';

    protected $casts = [
        'user_ids' => 'array',
    ];
    public function users()
    {
        // $fetch = $this->hasMany(User::class);
        // $result = $fetch->getQuery()->whereIn('id','group_manager');
        // return $result;
        $ids = json_decode($this->group_members);
        $members = [];
        $chats_members = []; 
        if(!empty($ids)){
            
        foreach($ids as $id) {
            $members[] = User::where('id',$id)->first();
            $chats_members[] = Chat::where('reciever_Id' , $id)->first();
        }
        return $members;
        }
    }
    public function group_managers()
    {
        $ids = json_decode($this->group_manager);
        $managers = [];
        $chats_managers = [];

        foreach($ids as $id) {
            $managers[] = User::where('id',$id)->first();
            $chats_managers[] = Chat::where('id' , $id)->first();
        }
        return $managers;
    }


}
