<?php

namespace App\Providers;

use Illuminate\Auth\Events\Registered;
use Illuminate\Auth\Events\Authenticated; // Add this line
use Illuminate\Auth\Events\Logout; // Add this line
use App\Listeners\LogSuccessfulLogin; // Add this line
use App\Listeners\LogSuccessfulLogout;
use Illuminate\Auth\Listeners\SendEmailVerificationNotification;
use Illuminate\Foundation\Support\Providers\EventServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\Event;

class EventServiceProvider extends ServiceProvider
{
    /**
     * The event listener mappings for the application.
     *
     * @var array<class-string, array<int, class-string>>
     */
    protected $listen = [
        Registered::class => [
            SendEmailVerificationNotification::class,
        ],
        Authenticated::class => [ // Merge this into the existing $listen array
            LogSuccessfulLogin::class,
        ],
        Logout::class => [ // Merge this into the existing $listen array
            LogSuccessfulLogout::class,
        ],
    ];


    /**
     * Register any events for your application.
     *
     * @return void
     */
    public function boot()
    {
        //
    }
}
