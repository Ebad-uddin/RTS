<?php

namespace App\Providers;

use App\Models\Chat;
use Illuminate\Support\ServiceProvider;
use App\Models\Tasklist;
use Illuminate\Support\Facades\Auth;
use App\Models\TaskModel;
use App\Models\User;
use Illuminate\Support\Facades\View;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        view()->composer('*', function ($view) {
            $all_tasks = Tasklist::all();
            $task_workers = User::where('role', 'worker')->get();
            $unread_msg = Chat::where('status', 0)->where('sender_Id' , Auth::id())->get(); 
            $view->with(['all_tasks' => $all_tasks, 'task_workers' => $task_workers, 'unread_msg' => $unread_msg]);
        });
    }
}
