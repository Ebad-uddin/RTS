<?php

use App\Http\Controllers\GroupManagerController;
use App\Http\Controllers\SiteManagerController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\SuperAdminController;
use App\Http\Controllers\WorkerController;
use Illuminate\Support\Facades\Auth;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


// SUPER ADMIN ROUTES START
Route::prefix('superadmin')->middleware(['auth', 'superadmin'])->group(function () {
    Route::get('/', [SuperAdminController::class, 'index'])->name('admin.index');
    Route::get('/chat', [SuperAdminController::class, 'Chat'])->name('admin.chat');
    Route::get('/group-view', [SuperAdminController::class, 'group_view'])->name('admin.group_view');
    Route::get('/invoices', [SuperAdminController::class, 'invoices'])->name('admin.invoices');
    Route::get('/reports', [SuperAdminController::class, 'reports'])->name('admin.reports');
    Route::get('/settings', [SuperAdminController::class, 'settings'])->name('admin.settings');
    Route::get('/taskManagement', [SuperAdminController::class, 'TaskManagement'])->name('admin.taskmanagement');
    Route::get('/taskView/{id}', [SuperAdminController::class, 'taskView'])->name('admin.taskView');
    Route::get('/users', [SuperAdminController::class, 'retrieve_user'])->name('admin.user');
    Route::get('/EditEmployee/{id}', [SuperAdminController::class, 'EditEmployee'])->name('admin.EditEmployee');
    // Route::get('/user', [SuperAdminController::class, 'user'])->name('admin.user');
    Route::get('/workgroups', [SuperAdminController::class, 'workgroups'])->name('admin.workgroups');
    Route::get('groupView/{id}', [SuperAdminController::class, 'groupView'])->name('admin.groupView');


    // POST Routes
    Route::post('/create_task', [SuperAdminController::class, 'create_task'])->name('admin.create_task');
    Route::post('/create_worker', [SuperAdminController::class, 'creat_worker'])->name('admin.addWorker');
    Route::post('/user', [SuperAdminController::class, 'filter_user'])->name('admin.filter_user');
    Route::post('/create_group', [SuperAdminController::class, 'create_group'])->name('admin.create_group');
    Route::post('/update_setting', [SuperAdminController::class, 'update_setting'])->name('admin.settings_update');
    Route::post('/updatePassword', [SuperAdminController::class, 'updatePassword'])->name('admin.updatePassword');
    Route::post('/UpdateEmployee', [SuperAdminController::class, 'UpdateEmployee'])->name('admin.UpdateEmployee');
    Route::post('/update_documents_user', [SuperAdminController::class, 'update_documents_user'])->name('admin.update_documents_user');
    Route::post('/update_documents_task', [SuperAdminController::class, 'update_documents_task'])->name('admin.update_docments_task');
    Route::post('/addTaskList', [SuperAdminController::class, 'addTaskList'])->name('admin.addTaskList');
    Route::post('/taskListEdit', [SuperAdminController::class, 'taskListEdit'])->name('admin.taskListEdit');
    Route::post('/TaskListUpdate', [SuperAdminController::class, 'TaskListUpdate'])->name('admin.TaskListUpdate');
    Route::post('/delete_task_doc', [SuperAdminController::class, 'delete_task_doc'])->name('admin.delete_task_doc');
    Route::post('/task_date_extend', [SuperAdminController::class, 'task_date_extend'])->name('admin.task_date_extend');
    Route::post('/task_date_update', [SuperAdminController::class, 'task_date_update'])->name('admin.task_date_update');
    Route::post('/Edit_task', [SuperAdminController::class, 'Edit_task'])->name('admin.Edit_task');
    Route::post('/Update_task', [SuperAdminController::class, 'Update_task'])->name('admin.Update_task');
    Route::post('/task_filteration', [SuperAdminController::class, 'task_filteration'])->name('admin.task_filteration');
    Route::post('/edit_group', [SuperAdminController::class, 'edit_group'])->name('admin.edit_group');
    Route::post('/update_group', [SuperAdminController::class, 'update_group'])->name('admin.update_group');
    Route::post('/delete_task', [SuperAdminController::class, 'delete_task'])->name('admin.delete_task');
    Route::post('/delete_worker', [SuperAdminController::class, 'delete_worker'])->name('admin.delete_worker');
    Route::post('/del_task_list', [SuperAdminController::class, 'del_task_list'])->name('admin.del_task_list');
    Route::post('/del_group', [SuperAdminController::class, 'del_group'])->name('admin.del_group');
    Route::post('showchat', [SuperAdminController::class, 'showchat'])->name('admin.showchat');
    Route::post('sendMsg', [SuperAdminController::class, 'sendMsg'])->name('admin.sendMsg');
    Route::post('send_grp_Msg', [SuperAdminController::class, 'send_grp_Msg'])->name('admin.send_grp_Msg');
    Route::post('show_group_chat', [SuperAdminController::class, 'show_group_chat'])->name('admin.show_group_chat');
    Route::post('update_group_workers', [SuperAdminController::class, 'update_group_workers'])->name('admin.update_group_workers');
    Route::post('group_info_update', [SuperAdminController::class, 'group_info_update'])->name('admin.group_info_update');
    Route::post('search_member', [SuperAdminController::class, 'search_member'])->name('admin.search_member');
    Route::post('task_complete', [SuperAdminController::class, 'task_complete'])->name('admin.task_complete');
    Route::post('/delete_user_doc', [SuperAdminController::class, 'delete_user_doc'])->name('admin.delete_user_doc');
    Route::post('/delete_user', [SuperAdminController::class, 'delete_user'])->name('admin.delete_user');
    Route::post('/mark_as_complete', [SuperAdminController::class, 'mark_as_complete'])->name('admin.mark_as_complete');
    Route::post('/changeTaskStatus', [SuperAdminController::class, 'changeTaskStatus'])->name('admin.changeTaskStatus');
    Route::post('/task_active', [SuperAdminController::class, 'task_active'])->name('admin.task_active');
    Route::post('/task_expired', [SuperAdminController::class, 'task_expired'])->name('admin.task_expired');
    Route::post('/updateStatus', [SuperAdminController::class, 'updateStatus'])->name('admin.updateStatus');
    Route::post('/read_msg', [SuperAdminController::class, 'read_msg'])->name('admin.read_msg');
    Route::post('/msg_counter', [SuperAdminController::class, 'msg_counter'])->name('admin.msg_counter');
    Route::post('/assignedWorkers', [SuperAdminController::class, 'assignedWorkers'])->name('admin.assignedWorkers');
    Route::post('/checkEmail', [SuperAdminController::class, 'checkEmail'])->name('admin.checkEmail');
    Route::post('/task_msg_counter', [SuperAdminController::class, 'task_msg_counter'])->name('admin.task_msg_counter');
    Route::post('/read_task_msg', [SuperAdminController::class, 'read_group_msg'])->name('admin.read_tasks_msg');
    Route::post('/update_group_managers', [SuperAdminController::class, 'update_group_managers'])->name('admin.update_group_managers');
    Route::post('/delete_manager', [SuperAdminController::class, 'delete_manager'])->name('admin.delete_manager');
    Route::post('/get_tasks', [SuperAdminController::class, 'get_tasks'])->name('admin.get_tasks');




});
// SUPER ADMIN ROUTES END


// GROUP MANAGER ROUTES START
Route::prefix('groupmanager')->middleware(['auth', 'groupmanager'])->group(function () {

    Route::get('/', [GroupManagerController::class, 'index'])->name('group_manager.index');
    Route::get('chat', [GroupManagerController::class, 'Chat'])->name('group_manager.chat');
    Route::get('group-view', [GroupManagerController::class, 'group_view'])->name('group_manager.group_view');
    Route::get('invoices', [GroupManagerController::class, 'invoices'])->name('group_manager.invoices');
    Route::get('reports', [GroupManagerController::class, 'reports'])->name('group_manager.reports');
    Route::get('settings', [GroupManagerController::class, 'settings'])->name('group_manager.settings');
    Route::get('taskManagement', [GroupManagerController::class, 'TaskManagement'])->name('group_manager.taskmanagement');
    Route::get('/taskView/{id}', [GroupManagerController::class, 'taskView'])->name('groupmanager.taskView');
    Route::get('user-view/{id}', [GroupManagerController::class, 'user_view'])->name('group_manager.user_view');
    Route::get('user', [GroupManagerController::class, 'user'])->name('group_manager.user');
    Route::get('workgroups', [GroupManagerController::class, 'workgroups'])->name('group_manager.workgroups');

    //POST routes
    Route::post('/create_worker', [GroupManagerController::class, 'creat_worker'])->name('groupmanager.addWorker');
    Route::post('/create_task', [GroupManagerController::class, 'create_task'])->name('groupmanager.create_task');
    Route::post('/update_setting', [GroupManagerController::class, 'update_setting'])->name('groupmanager.settings_update');
    Route::post('/updatePassword', [GroupManagerController::class, 'updatePassword'])->name('groupmanager.updatePassword');
    Route::post('/update_group', [GroupManagerController::class, 'update_group'])->name('groupmanager.update_group');
    Route::post('/edit_group', [GroupManagerController::class, 'edit_group'])->name('groupmanager.edit_group');
    Route::post('/update_documents_task', [GroupManagerController::class, 'update_documents_task'])->name('groupmanager.update_docments_task');
    Route::post('/delete_task_doc', [GroupManagerController::class, 'delete_task_doc'])->name('groupmanager.delete_task_doc');
    Route::post('/delete_task', [GroupManagerController::class, 'delete_task'])->name('groupmanager.delete_task');
    Route::post('/del_group', [GroupManagerController::class, 'del_group'])->name('groupmanager.del_group');
    Route::post('showchat', [GroupManagerController::class, 'showchat'])->name('groupmanager.showchat');
    Route::post('sendMsg', [GroupManagerController::class, 'sendMsg'])->name('groupmanager.sendMsg');
    Route::post('send_grp_Msg', [GroupManagerController::class, 'send_grp_Msg'])->name('groupmanager.send_grp_Msg');
    Route::post('show_group_chat', [GroupManagerController::class, 'show_group_chat'])->name('groupmanager.show_group_chat');
    Route::post('search_member', [GroupManagerController::class, 'search_member'])->name('groupmanager.search_member');
    Route::post('task_complete', [GroupManagerController::class, 'task_complete'])->name('groupmanager.task_complete');
    Route::post('/UpdateEmployee', [GroupManagerController::class, 'UpdateEmployee'])->name('groupmanager.UpdateEmployee');
    Route::post('/update_documents_user', [GroupManagerController::class, 'update_documents_user'])->name('groupmanager.update_documents_user');
    Route::post('/delete_user_doc', [GroupManagerController::class, 'delete_user_doc'])->name('groupmanager.delete_user_doc');
    Route::post('/delete_user', [GroupManagerController::class, 'delete_user'])->name('groupmanager.delete_user');
    Route::post('/mark_as_complete', [GroupManagerController::class, 'mark_as_complete'])->name('groupmanager.mark_as_complete');
    Route::post('/changeTaskStatus', [GroupManagerController::class, 'changeTaskStatus'])->name('groupmanager.changeTaskStatus');
    Route::post('/delete_user_data', [GroupManagerController::class, 'delete_user_data'])->name('groupmanager.delete_user_data');
    Route::post('/task_active', [GroupManagerController::class, 'task_active'])->name('groupmanager.task_active');
    Route::post('/task_expired', [GroupManagerController::class, 'task_expired'])->name('groupmanager.task_expired');
    Route::post('/read_msg', [GroupManagerController::class, 'read_msg'])->name('groupmanager.read_msg');
    Route::post('/msg_counter', [GroupManagerController::class, 'msg_counter'])->name('groupmanager.msg_counter');
    Route::post('/assignedWorkers', [GroupManagerController::class, 'assignedWorkers'])->name('groupmanager.assignedWorkers');
    Route::post('/checkEmail', [GroupManagerController::class, 'checkEmail'])->name('groupmanager.checkEmail');
    Route::post('/task_msg_counter', [GroupManagerController::class, 'task_msg_counter'])->name('groupmanager.task_msg_counter');
    Route::post('/read_msg', [GroupManagerController::class, 'read_group_msg'])->name('groupmanager.read_msg');
    Route::post('/get_tasks', [GroupManagerController::class, 'get_tasks'])->name('groupmanager.get_tasks');


});
// GROUP MANAGER ROUTES END



// SITEMANAGER ROUTES START
Route::prefix('sitemanager')->middleware(['auth', 'sitemanager'])->group(function () {

    Route::get('/', [SiteManagerController::class, 'index'])->name('sitemanager.index');
    Route::get('chat', [SiteManagerController::class, 'Chat'])->name('sitemanager.chat');
    Route::get('group-view', [SiteManagerController::class, 'group_view'])->name('sitemanager.group_view');
    Route::get('invoices', [SiteManagerController::class, 'invoices'])->name('sitemanager.invoices');
    Route::get('reports', [SiteManagerController::class, 'reports'])->name('sitemanager.reports');
    Route::get('settings', [SiteManagerController::class, 'settings'])->name('sitemanager.settings');
    Route::get('taskManagement', [SiteManagerController::class, 'TaskManagement'])->name('sitemanager.taskmanagement');
    Route::get('/taskView/{id}', [SiteManagerController::class, 'taskView'])->name('sitemanager.taskView');
    Route::get('user-view', [SiteManagerController::class, 'user_view'])->name('sitemanager.user_view');
    Route::get('/users', [SiteManagerController::class, 'retrieve_user'])->name('sitemanager.user');
    Route::get('workgroups', [SiteManagerController::class, 'workgroups'])->name('sitemanager.workgroups');
    Route::get('groupView/{id}', [SiteManagerController::class, 'groupView'])->name('sitemanager.groupView');

    // POST routes

    Route::post('creategroup', [SiteManagerController::class], 'creategroup')->name('sitemanager.creategroup');
    Route::post('/create_task', [SiteManagerController::class, 'create_task'])->name('sitemanager.create_task');
    Route::post('/task_date_extend', [SiteManagerController::class, 'task_date_extend'])->name('sitemanager.task_date_extend');
    Route::post('/task_date_update', [SiteManagerController::class, 'task_date_update'])->name('sitemanager.task_date_update');
    Route::post('/user', [SiteManagerController::class, 'filter_user'])->name('sitemanager.filter_user');
    Route::post('/create_worker', [SiteManagerController::class, 'creat_worker'])->name('sitemanager.addWorker');
    Route::post('/create_group', [SiteManagerController::class, 'create_group'])->name('sitemanager.create_group');
    Route::post('/update_setting', [SiteManagerController::class, 'update_setting'])->name('sitemanager.settings_update');
    Route::post('/updatePassword', [SiteManagerController::class, 'updatePassword'])->name('sitemanager.updatePassword');
    Route::get('/EditEmployee/{id}', [SiteManagerController::class, 'EditEmployee'])->name('sitemanager.EditEmployee');
    Route::post('/UpdateEmployee', [SiteManagerController::class, 'UpdateEmployee'])->name('sitemanager.UpdateEmployee');
    Route::post('/addTaskList', [SiteManagerController::class, 'addTaskList'])->name('sitemanager.addTaskList');
    Route::post('/TaskListUpdate', [SiteManagerController::class, 'TaskListUpdate'])->name('sitemanager.TaskListUpdate');
    Route::post('/taskListEdit', [SiteManagerController::class, 'taskListEdit'])->name('sitemanager.taskListEdit');
    Route::post('/delete_task_doc', [SiteManagerController::class, 'delete_task_doc'])->name('sitemanager.delete_task_doc');
    Route::post('/edit_group', [SiteManagerController::class, 'edit_group'])->name('sitemanager.edit_group');
    Route::post('/update_group', [SiteManagerController::class, 'update_group'])->name('sitemanager.update_group');
    Route::post('/delete_task', [SiteManagerController::class, 'delete_task'])->name('sitemanager.delete_task');
    Route::post('/delete_worker', [SiteManagerController::class, 'delete_worker'])->name('sitemanager.delete_worker');
    Route::post('/del_task_list', [SiteManagerController::class, 'del_task_list'])->name('sitemanager.del_task_list');
    Route::post('/update_documents_task', [SiteManagerController::class, 'update_documents_task'])->name('sitemanager.update_docments_task');
    Route::post('/updateStatus', [SiteManagerController::class, 'updateStatus'])->name('sitemanager.updateStatus');
    Route::post('/del_group', [SiteManagerController::class, 'del_group'])->name('sitemanager.del_group');
    Route::post('showchat', [SiteManagerController::class, 'showchat'])->name('sitemanager.showchat');
    Route::post('sendMsg', [SiteManagerController::class, 'sendMsg'])->name('sitemanager.sendMsg');
    Route::post('send_grp_Msg', [SiteManagerController::class, 'send_grp_Msg'])->name('sitemanager.send_grp_Msg');
    Route::post('show_group_chat', [SiteManagerController::class, 'show_group_chat'])->name('sitemanager.show_group_chat');
    Route::post('group_info_update', [SiteManagerController::class, 'group_info_update'])->name('sitemanager.group_info_update');
    Route::post('update_group_workers', [SiteManagerController::class, 'update_group_workers'])->name('sitemanager.update_group_workers');
    Route::post('search_member', [SiteManagerController::class, 'search_member'])->name('sitemanager.search_member');
    Route::post('/update_documents_user', [SiteManagerController::class, 'update_documents_user'])->name('sitemanager.update_documents_user');
    Route::post('/Edit_task', [SiteManagerController::class, 'Edit_task'])->name('sitemanager.Edit_task');
    Route::post('/Update_task', [SiteManagerController::class, 'Update_task'])->name('sitemanager.Update_task');
    Route::post('task_complete', [SiteManagerController::class, 'task_complete'])->name('sitemanager.task_complete');
    Route::post('/delete_user_doc', [SiteManagerController::class, 'delete_user_doc'])->name('sitemanager.delete_user_doc');
    Route::post('/delete_user', [SiteManagerController::class, 'delete_user'])->name('sitemanager.delete_user');
    Route::post('/mark_as_complete', [SiteManagerController::class, 'mark_as_complete'])->name('sitemanager.mark_as_complete');
    Route::post('/changeTaskStatus', [SiteManagerController::class, 'changeTaskStatus'])->name('sitemanager.changeTaskStatus');
    Route::post('/task_active', [SiteManagerController::class, 'task_active'])->name('sitemanager.task_active');
    Route::post('/task_expired', [SiteManagerController::class, 'task_expired'])->name('sitemanager.task_expired');
    Route::post('/read_msg', [SiteManagerController::class, 'read_msg'])->name('sitemanager.read_msg');
    Route::post('/msg_counter', [SiteManagerController::class, 'msg_counter'])->name('sitemanager.msg_counter');
    Route::post('/assignedWorkers', [SiteManagerController::class, 'assignedWorkers'])->name('sitemanager.assignedWorkers');
    Route::post('/checkEmail', [SiteManagerController::class, 'checkEmail'])->name('sitemanager.checkEmail');
    Route::post('/task_msg_counter', [SiteManagerController::class, 'task_msg_counter'])->name('sitemanager.task_msg_counter');
    Route::post('/read_msg', [SiteManagerController::class, 'read_group_msg'])->name('sitemanager.read_msg');
    Route::post('/update_group_managers', [SiteManagerController::class, 'update_group_managers'])->name('sitemanager.update_group_managers');
    Route::post('/delete_manager', [SiteManagerController::class, 'delete_manager'])->name('sitemanager.delete_manager');
    Route::post('/get_tasks', [SiteManagerController::class, 'get_tasks'])->name('sitemanager.get_tasks');




});
// SITEMANAGER ROUTES END



// // WORKERS ROUTES START
Route::prefix('worker')->middleware(['auth', 'worker'])->group(function () {

    Route::get('/', [WorkerController::class, 'index'])->name('worker.index');
    Route::get('worker/chat', [WorkerController::class, 'Chat'])->name('worker.chat');
    Route::get('worker/group-view', [WorkerController::class, 'group_view'])->name('worker.group_view');
    Route::get('worker/invoices', [WorkerController::class, 'invoices'])->name('worker.invoices');
    Route::get('worker/reports', [WorkerController::class, 'reports'])->name('worker.reports');
    Route::get('worker/settings', [WorkerController::class, 'settings'])->name('worker.settings');
    Route::get('worker/taskManagement', [WorkerController::class, 'TaskManagement'])->name('worker.taskmanagement');
    Route::get('/taskView/{id}', [WorkerController::class, 'taskView'])->name('worker.taskView');
    Route::get('worker/user-view', [WorkerController::class, 'user_view'])->name('worker.user_view');
    Route::get('worker/user', [WorkerController::class, 'user'])->name('worker.user');
    Route::get('worker/workgroups', [WorkerController::class, 'workgroups'])->name('worker.workgroups');

    // POST Routes
    Route::post('/update_setting', [WorkerController::class, 'update_setting'])->name('worker.settings_update');
    Route::post('/updatePassword', [WorkerController::class, 'updatePassword'])->name('worker.updatePassword');
    Route::post('/delete_task_doc', [WorkerController::class, 'delete_task_doc'])->name('worker.delete_task_doc');
    Route::post('/delete_user_doc', [WorkerController::class, 'delete_user_doc'])->name('worker.delete_user_doc');
    Route::post('/update_documents_task', [WorkerController::class, 'update_documents_task'])->name('worker.update_docments_task');
    Route::post('showchat', [WorkerController::class, 'showchat'])->name('worker.showchat');
    Route::post('sendMsg', [WorkerController::class, 'sendMsg'])->name('worker.sendMsg');
    Route::post('send_grp_Msg', [WorkerController::class, 'send_grp_Msg'])->name('worker.send_grp_Msg');
    Route::post('show_group_chat', [WorkerController::class, 'show_group_chat'])->name('worker.show_group_chat');
    Route::post('search_member', [WorkerController::class, 'search_member'])->name('worker.search_member');
    Route::post('task_complete', [WorkerController::class, 'task_complete'])->name('worker.task_complete');
    Route::post('/update_documents_user', [WorkerController::class, 'update_documents_user'])->name('worker.update_documents_user');
    Route::post('/task_active', [WorkerController::class, 'task_active'])->name('worker.task_active');
    Route::post('/task_expired', [WorkerController::class, 'task_expired'])->name('worker.task_expired');
    Route::post('/read_msg', [WorkerController::class, 'read_msg'])->name('worker.read_msg');
    Route::post('/msg_counter', [WorkerController::class, 'msg_counter'])->name('worker.msg_counter');
    Route::post('/task_msg_counter', [WorkerController::class, 'task_msg_counter'])->name('worker.task_msg_counter');
    Route::post('/read_msg', [WorkerController::class, 'read_group_msg'])->name('worker.read_msg');
    Route::post('/get_tasks', [WorkerController::class, 'get_tasks'])->name('worker.get_tasks');

});
// WORKERS ROUTES START

Auth::routes();
